#!/bin/sh
set -eu
cd "$(dirname "$0")"
for source in 01-v3-recovery-paths.dot 02-v4-business-vm.dot 03-blind-evaluation-isolation.dot 04-v4-dynamic-recovery.dot; do
  dot -Tsvg "$source" -o "${source%.dot}.svg"
done

# The measured table is generated only when its published JSON is present.
if [ -f before-after-metrics.json ]; then
  python3 before_after_table.py --data before-after-metrics.json --output 05-before-after-benchmark.svg
  if command -v rsvg-convert >/dev/null 2>&1; then
    rsvg-convert -w 1560 05-before-after-benchmark.svg -o 05-before-after-benchmark.png
  fi
fi
