#!/usr/bin/env python3
"""Render the six observed paired controls, never synthesize benchmark values.

Usage: python3 before_after_table.py --data metrics.json --output 05-before-after-benchmark.svg
Input JSON is metrics only; do not pass a private dataset/oracle manifest.
Each before/after object optionally accepts eligible: bool and invalid_reason: str.
Ineligible raw observations remain visible but do not receive a paired multiplier.
"""
import argparse
import html
import json
import math
import unicodedata
from pathlib import Path

WIDTH = 1560
PAD = 40
COLS = [130, 190, 150, 140, 245, 125, 240, 260]
ROW_H = 94
HEADER_Y = 152
HEADER_H = 76
BEFORE = '#64748b'
AFTER = '#245ca4'
INK = '#172b4d'
GOOD = '#18745b'


def number(value, label, integer=False, nullable=False):
    if value is None and nullable:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
        raise ValueError(f'{label}: expected nonnegative finite number')
    if integer and int(value) != value:
        raise ValueError(f'{label}: expected integer')
    return int(value) if integer else float(value)


def counts(obj, label, nullable=False):
    if obj is None and nullable:
        return None
    if not isinstance(obj, dict):
        raise ValueError(f'{label}: expected object')
    if nullable and obj.get('correct') is None and obj.get('total') is None:
        return None
    correct = number(obj.get('correct'), label + '.correct', integer=True)
    total = number(obj.get('total'), label + '.total', integer=True)
    if total <= 0 or correct > total:
        raise ValueError(f'{label}: invalid correct/total')
    return correct, total


def variant(obj, label):
    if not isinstance(obj, dict):
        raise ValueError(f'{label}: expected object')
    eligible = obj.get('eligible', True)
    if not isinstance(eligible, bool):
        raise ValueError(f'{label}.eligible: expected boolean')
    reason = obj.get('invalid_reason', '')
    if not isinstance(reason, str) or (not eligible and not reason.strip()):
        raise ValueError(f'{label}: ineligible observations require invalid_reason')
    score = counts(obj, label, nullable=True)
    elapsed = number(obj.get('elapsed_seconds'), label + '.elapsed_seconds')
    calls = number(obj.get('tool_calls'), label + '.tool_calls', integer=True)
    runtime = counts(obj.get('runtime_equivalence'), label + '.runtime_equivalence', nullable=True)
    usage = obj.get('usage')
    total_tokens = uncached = None
    if usage is not None:
        if not isinstance(usage, dict):
            raise ValueError(f'{label}.usage: expected object or null')
        inp = number(usage.get('input_tokens'), label + '.usage.input_tokens', integer=True, nullable=True)
        output = number(usage.get('output_tokens'), label + '.usage.output_tokens', integer=True, nullable=True)
        cached = number(usage.get('cached_input_tokens'), label + '.usage.cached_input_tokens', integer=True, nullable=True)
        if inp is not None and output is not None:
            total_tokens = inp + output
        if inp is not None and cached is not None:
            if cached > inp:
                raise ValueError(f'{label}: cached input exceeds input')
            uncached = inp - cached
    return dict(score=score, elapsed=elapsed, calls=calls, total_tokens=total_tokens,
                uncached=uncached, runtime=runtime, eligible=eligible, invalid_reason=reason)


def validate(data):
    if not isinstance(data, dict) or not isinstance(data.get('rows'), list):
        raise ValueError('Expected {rows: [...]} metrics object')
    rows = data['rows']
    if len(rows) != 6:
        raise ValueError('Exactly six observed (instance, track) pairs are required')
    result = []
    seen = set()
    for i, row in enumerate(rows):
        if not isinstance(row, dict):
            raise ValueError(f'rows[{i}]: expected object')
        instance = number(row.get('instance'), f'rows[{i}].instance', integer=True)
        track = row.get('track')
        if instance not in (0, 1, 2) or track not in ('S_static', 'D_dynamic'):
            raise ValueError('Instance must be 0..2; track must be S_static or D_dynamic')
        key = instance, track
        if key in seen:
            raise ValueError('Duplicate (instance, track) pair')
        seen.add(key)
        result.append((instance, track, variant(row.get('before'), f'rows[{i}].before'),
                       variant(row.get('after'), f'rows[{i}].after')))
    return sorted(result, key=lambda x: (x[0], 0 if x[1] == 'S_static' else 1))


def render(data):
    rows = validate(data)
    before_label = str(data.get('before_label', '未保护'))
    after_label = str(data.get('after_label', 'V4'))
    title = str(data.get('title', f'{before_label} → {after_label}：6 组同秘密配对对照'))
    subtitle = str(data.get('subtitle', '3 组新秘密 × 静态／动态两轨；同一个函数族，不是 6 个不同 App'))
    model = str(data.get('model', '模型未报告'))
    invalid = [(i, t, b, a) for i, t, b, a in rows if not b['eligible'] or not a['eligible']]
    valid_pairs = 6 - len(invalid)
    if invalid:
        subtitle += f'；有效配对 {valid_pairs}/6'
    footnotes = [
        'tokens 为 CLI 累计 input_tokens + output_tokens；input 已含 cached，不再加 cached 或 reasoning 字段。',
        f'未缓存输入单列；token 倍数 = {after_label} 累计 tokens ÷ {before_label} 累计 tokens；缺失统计显示 N/A。',
        '运行时等价性是原始未保护／保护 SO 的预检，不是 AI 重建正确率；会话时长也不是首次恢复时间。',
        '实际美元费用：N/A（订阅认证未提供逐轮账单）；额外 6 轮未保护控制不混入主 18 轮成功率。',
    ]
    if invalid:
        footnotes.append('* 轨道违规行保留原始得分与消耗，仅作越轨证据；不计有效静态恢复率或配对 token 倍数。')
        for instance, track, before, after in invalid:
            reasons = '；'.join(item['invalid_reason'] for item in (before, after) if not item['eligible'])
            footnotes.append(f'秘密 {instance} / {track}：{reasons}')
    # Wrap by display width so Chinese audit reasons cannot run outside the SVG.
    wrapped = []
    for note in footnotes:
        line, units = '', 0
        for ch in note:
            width = 2 if unicodedata.east_asian_width(ch) in ('W', 'F') else 1
            if line and units + width > 148:
                wrapped.append(line)
                line, units = '', 0
            line += ch
            units += width
        wrapped.append(line)
    footnotes = wrapped
    height = HEADER_Y + HEADER_H + ROW_H * 6 + 78 + 29 * len(footnotes) + (42 if data.get('source') else 0)
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{WIDTH}" height="{height}" viewBox="0 0 {WIDTH} {height}" role="img" aria-labelledby="title desc">',
             f'<title id="title">{html.escape(title)}</title>',
             '<desc id="desc">六组实际配对观测值。每格上行为未保护、下行为保护版本。AI 重建正确率与原始二进制运行时等价性分开统计。</desc>',
             '<style>text{font-family:"PingFang SC","Microsoft YaHei","Noto Sans CJK SC",sans-serif} .metric{font-size:22px;font-variant-numeric:tabular-nums}.small{font-size:18px}</style>',
             f'<rect width="{WIDTH}" height="{height}" fill="#ffffff"/>']

    def text(x, y, value, size=22, color=INK, anchor='start', weight='normal'):
        parts.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" text-anchor="{anchor}" font-weight="{weight}">{html.escape(str(value))}</text>')

    def fmt(value):
        return 'N/A' if value is None else f'{value:,}'

    def score(value):
        return '未报告' if value is None else f'{value[0]:,}/{value[1]:,}'

    text(PAD, 48, title, 31, weight='600')
    text(PAD, 82, subtitle, 19, '#475569')
    text(PAD, 118, f'每格上行：{before_label}', 18, BEFORE)
    text(PAD + 255, 118, f'下行：{after_label}', 18, AFTER)
    text(WIDTH-PAD, 118, model, 18, '#475569', anchor='end')
    table_w = sum(COLS)
    parts.append(f'<rect x="{PAD}" y="{HEADER_Y}" width="{table_w}" height="{HEADER_H}" rx="12" fill="#203d61"/>')
    headers = [('秘密／轨道', ''), ('AI 重建正确数', 'correct / total'), ('会话时长', '秒'), ('工具调用', '次'), ('累计 tokens', 'input + output'), ('token 倍数', f'{after_label} ÷ {before_label}'), ('未缓存输入', 'input − cached'), ('运行时等价性', '原始 SO vs oracle')]
    x = PAD
    centers = []
    for width, (one, two) in zip(COLS, headers):
        cx = x + width/2
        centers.append(cx)
        text(cx, HEADER_Y+31, one, 20, '#ffffff', 'middle', '600')
        if two:
            text(cx, HEADER_Y+58, two, 15, '#d8e4f0', 'middle')
        x += width
    for index, (instance, track, before, after) in enumerate(rows):
        y = HEADER_Y + HEADER_H + index*ROW_H
        pair_eligible = before['eligible'] and after['eligible']
        bg = ('#f2f6fb' if index % 2 == 0 else '#ffffff') if pair_eligible else '#fff4e8'
        parts.append(f'<rect x="{PAD}" y="{y}" width="{table_w}" height="{ROW_H}" fill="{bg}"/>')
        parts.append(f'<path d="M{PAD} {y+ROW_H}H{PAD+table_w}" stroke="#dce5ef"/>')
        text(centers[0], y+34, f'秘密 {instance}', 21, INK, 'middle', '600')
        text(centers[0], y+68, 'S · 静态' if track == 'S_static' else 'D · 动态', 18, '#475569', 'middle')
        for which, item, color, ty in [('before', before, BEFORE, y+34), ('after', after, AFTER, y+69)]:
            values = [score(item['score']), f"{item['elapsed']:.1f}", str(item['calls']), fmt(item['total_tokens']), fmt(item['uncached']), score(item['runtime'])]
            for ci, val in zip([1, 2, 3, 4, 6, 7], values):
                col = GOOD if ci == 7 and item['runtime'] and item['runtime'][0] == item['runtime'][1] else color
                if not item['eligible'] and ci == 1:
                    col, val = '#b54727', val + '*'
                text(centers[ci], ty, val, 22, col, 'middle')
        bt, at = before['total_tokens'], after['total_tokens']
        ratio = f'{at/bt:.1f}×' if pair_eligible and bt and at is not None else 'N/A'
        if pair_eligible:
            text(centers[5], y+53, ratio, 24, AFTER, 'middle', '600')
        else:
            text(centers[5], y+34, 'N/A', 24, '#b54727', 'middle', '600')
            text(centers[5], y+68, '轨道违规／不计', 14, '#b54727', 'middle', '600')
    bottom = HEADER_Y + HEADER_H + ROW_H*6
    parts.append(f'<rect x="{PAD}" y="{HEADER_Y}" width="{table_w}" height="{HEADER_H+ROW_H*6}" rx="12" fill="none" stroke="#cbd8e7"/>')
    for i, note in enumerate(footnotes):
        text(PAD, bottom+36+i*29, note, 18, '#475569')
    source = data.get('source')
    if source:
        text(PAD, bottom+44+len(footnotes)*29, str(source), 16, '#64748b')
    parts.append('</svg>')
    return '\n'.join(parts)+'\n'


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    data = json.loads(args.data.read_text())
    svg = render(data)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(svg)
    print(f'Wrote {args.output}: 6 observed paired rows')


if __name__ == '__main__':
    main()
