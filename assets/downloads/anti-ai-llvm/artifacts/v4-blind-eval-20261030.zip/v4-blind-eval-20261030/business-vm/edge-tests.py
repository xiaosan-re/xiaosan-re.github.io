#!/usr/bin/env python3
import ctypes,pathlib,subprocess,json,random,os,hashlib
H=pathlib.Path(__file__).resolve().parent;O=H/'build';L=pathlib.Path('/opt/homebrew/opt/llvm@21/bin')
annotation='''@s = private constant [18 x i8] c"omvll.business-vm\\00"
@llvm.global.annotations = appending global [1 x {ptr,ptr,ptr,i32,ptr}] [{ptr,ptr,ptr,i32,ptr} {ptr @FN,ptr @s,ptr null,i32 0,ptr null}], section "llvm.metadata"
'''
cycle='''define i32 @cycle(i32 %a,i32 %b,i32 %c,i32 %d) {
e:
 %lim=and i32 %c,15
 br label %loop
loop:
 %x=phi i32 [%a,%e],[%y,%back]
 %y=phi i32 [%b,%e],[%x,%back]
 %i=phi i32 [0,%e],[%next,%back]
 %done=icmp eq i32 %i,%lim
 br i1 %done,label %exit,label %back
back:
 %next=add i32 %i,1
 br label %loop
exit:
 %t=mul i32 %x,31
 %u=xor i32 %t,%y
 %r=add i32 %u,%d
 ret i32 %r
}
'''
narrow='''define i32 @narrow(i32 %a,i32 %b,i32 %c,i32 %d) {
e:
 %aa=trunc i32 %a to i8
 %bb=trunc i32 %b to i8
 %cmp=icmp slt i8 %aa,%bb
 %sd=sdiv i8 %aa,3
 %s=sext i8 %sd to i32
 %ud=udiv i8 %aa,3
 %u=zext i8 %ud to i32
 %v=select i1 %cmp,i32 %s,i32 %u
 %r=xor i32 %v,%d
 ret i32 %r
}
'''
def run(a,okay=True):
 p=subprocess.run(list(map(str,a)),capture_output=True,text=True,env={**os.environ,'OMVLL_VM_SEED':'189589','LLVM_DISABLE_CRASH_REPORT':'1'})
 if okay and p.returncode:raise RuntimeError(p.stderr[-2500:])
 return p
rng=random.Random(85192);report={}
for name,body in [('cycle',cycle),('narrow',narrow)]:
 src=O/f'{name}.ll';src.write_text(annotation.replace('FN',name)+body);bc=O/f'{name}-vm.bc'
 run([L/'opt',f'-load-pass-plugin={H}/BusinessVM.dylib','-passes=v4-virtualize',src,'-o',bc]);run([L/'opt',f'-load-pass-plugin={H}/BusinessVM.dylib','-passes=v4-virtualize',bc,'-o',O/f'{name}-twice.bc'])
 lib=O/f'{name}.dylib';run([L/'clang',bc,'-O2','-dynamiclib','-o',lib]);d=ctypes.CDLL(str(lib));f=getattr(d,name);f.argtypes=[ctypes.c_uint32]*4;f.restype=ctypes.c_uint32
 for i in range(10000):
  a,b,c,z=[rng.getrandbits(32)for _ in range(4)]
  if name=='cycle':
   x,y=(b,a)if c&1 else(a,b);want=(((x*31)&0xffffffff)^y)+z;want&=0xffffffff
  else:
   aa=a&255;bb=b&255;sa=aa-256 if aa&128 else aa;sb=bb-256 if bb&128 else bb
   v=int(sa/3)if sa<sb else aa//3;want=(v^z)&0xffffffff
  assert f(a,b,c,z)==want,(name,a,b,c,z,f(a,b,c,z),want)
 report[name]={'random_cases':10000,'result':'PASS','idempotent':'PASS'}
src=O/'unsupported.ll';src.write_text(annotation.replace('FN','bad')+'@g=global i32 0\ndefine i32 @bad(i32 %a,i32 %b,i32 %c,i32 %d){ %x=load volatile i32,ptr @g\n ret i32 %x\n}\n')
p=run([L/'opt',f'-load-pass-plugin={H}/BusinessVM.dylib','-passes=v4-virtualize',src,'-o',O/'unsupported-out.bc'],False)
assert p.returncode!=0 and 'refusing plaintext fallback'in p.stderr;report['unsupported_memory']={'result':'REJECTED','returncode':p.returncode}
(O/'edge-test-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
