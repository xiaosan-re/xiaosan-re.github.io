#!/usr/bin/env python3
import ctypes,json,pathlib,random,subprocess,os,sys,time
HERE=pathlib.Path(__file__).resolve().parent;EXP=HERE.parent;DEMO=EXP/'android-demo';REPO=EXP.parent.parent
LLVM=pathlib.Path('/opt/homebrew/opt/llvm@21/bin');NDK=pathlib.Path.home()/'Library/Android/sdk/ndk/29.0.14206865/toolchains/llvm/prebuilt/darwin-x86_64'
OUT=HERE/'build';OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(EXP/'blind-eval'));from dataset import oracle,vectors
source=(DEMO/'demo.c').read_text().replace('AC BLA_SHADOW BLA_RUNTIME API uint32_t demo_evaluate','__attribute__((annotate("omvll.business-vm"))) AC BLA_SHADOW BLA_RUNTIME API uint32_t demo_evaluate');(OUT/'core.c').write_text(source)
def run(cmd,env=None):
 p=subprocess.run(list(map(str,cmd)),env=env,capture_output=True,text=True)
 if p.returncode:raise RuntimeError(p.stderr[-4000:])
secret={'key':0xc37a91e5,'salt':0x13579bdf,'judge_seed':1745};vs=vectors(secret)
report=[]
for platform in ['native','android']:
 target=['--target=aarch64-linux-android23',f'--sysroot={NDK}/sysroot']if platform=='android'else[]
 bc=OUT/f'{platform}.bc';outbc=OUT/f'{platform}-vm.bc';lib=OUT/f'vm-{platform}{".so"if platform=="android"else".dylib"}'
 run([LLVM/'clang',OUT/'core.c',*target,'-O2','-c','-emit-llvm','-o',bc])
 env=os.environ.copy();env['OMVLL_VM_SEED']='123456789';run([LLVM/'opt',f'-load-pass-plugin={HERE}/BusinessVM.dylib','-passes=v4-virtualize',bc,'-o',outbc],env)
 run([LLVM/'opt','-S',outbc,'-o',OUT/f'{platform}-vm.ll'])
 link=[f'-fuse-ld={NDK}/bin/ld.lld','-nostdlib','-shared','-Wl,-z,defs']if platform=='android'else['-dynamiclib']
 run([LLVM/'clang',outbc,*target,'-O2','-fPIC',*link,'-o',lib])
 start=time.monotonic()
 if platform=='native':
  d=ctypes.CDLL(str(lib));f=d.demo_evaluate;f.argtypes=[ctypes.c_uint32]*4;f.restype=ctypes.c_uint32
  for v in vs:
   assert f(*v)==oracle(v,secret['key'],secret['salt']),('native',v)
 else:
  sys.path.insert(0,str(DEMO/'layers'));from emulate_support import load,call
  u,s,fixture=load(lib)
  for v in vs:
   assert call(u,s['demo_evaluate'],v,budget=2000000)==oracle(v,secret['key'],secret['salt']),('android',v)
 report.append({'platform':platform,'vectors':len(vs),'result':'PASS','seconds':round(time.monotonic()-start,3),'bytes':lib.stat().st_size})
 print(report[-1],flush=True)
(OUT/'smoke-report.json').write_text(json.dumps(report,indent=2)+'\n')
