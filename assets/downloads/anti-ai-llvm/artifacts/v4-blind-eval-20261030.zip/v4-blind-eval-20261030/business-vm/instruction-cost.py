#!/usr/bin/env python3
"""Descriptive emulated instruction counts; never real-device timing."""
import pathlib,sys,json,random,statistics
H=pathlib.Path(__file__).resolve().parent;E=H.parent
sys.path.insert(0,str(E/'android-demo/layers'));from emulate_support import load,call
sys.path.insert(0,str(E/'blind-eval'));from dataset import mix,oracle
from unicorn import UC_HOOK_CODE
rng=random.Random(91);cases=[]
for i in range(40):
 u=rng.getrandbits(32);cases.append((u,[1,9,10,100][i%4],i%3,mix(u^0xc37a91e5)))
paths={'baseline':E/'build/android-demo-v3/libantiai_demo_baseline.so','v3':E/'build/android-demo-v3/libantiai_demo_hardened.so','v4_vm_layers':H/'build/vm-layers.so'}
report={'scope':'Public unchanged demo; clean ARM64 Unicorn; runtime probe warmed once, <64 measured calls. Instruction counts, not Android timings. V4 sample omits inactive metadata but retains flatten/shadow/runtime.','cases':len(cases),'variants':{}}
for name,path in paths.items():
 u,s,f=load(path);count=[0];u.hook_add(UC_HOOK_CODE,lambda uc,a,z,d:count.__setitem__(0,count[0]+1));call(u,s['demo_evaluate'],cases[0],budget=2000000);cs=[]
 for v in cases:
  count[0]=0;got=call(u,s['demo_evaluate'],v,budget=2000000);assert got==oracle(v,0xc37a91e5,0x13579bdf),(name,v,got);cs.append(count[0])
 report['variants'][name]={'median_instructions':statistics.median(cs),'min':min(cs),'max':max(cs),'counts':cs}
report['v4_vs_v3_median_ratio']=report['variants']['v4_vm_layers']['median_instructions']/report['variants']['v3']['median_instructions']
(H/'build/instruction-cost-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='variants'},indent=2));print({k:{a:b for a,b in v.items()if a!='counts'}for k,v in report['variants'].items()})
