V4 paired Android SO evaluation
================================

This evidence snapshot contains 18 primary trials (O-MVLL/V3/V4) and six
supplemental unprotected trials using the same three secret instances. All
inputs are owned toy Android ARM64 libraries. One primary static trial executed
its extracted target VM and is excluded; its raw score is not a defense win.

Read article.md, results.json, before-after-metrics.json and the cohort audit
files. Per-trial visible-tools.jsonl contains only visible tool requests/results;
work-files/ preserves agent-created scripts, data and owned target copies.
submitted-versions/ and submission-history.json preserve every submitted version
and its offline hidden score. Original inputs are in targets/.

The BusinessVM pass is opt-in and limited to pure i1..i32 CFG with an
i32(i32,i32,i32,i32) ABI. Its code/build entry is passes/business-vm/.
The main O-MVLL plugin, LLVM21, NDK29, licensed IDA and the local inference
authentication are environment dependencies, not included runtime products.
The infrastructure source snapshot retains the original project-relative layout;
use it in the existing o-mvll/experiments/analysis-complexity workspace.

Exact local judge replay manifests are retained separately at
o-mvll/experiments/analysis-complexity/build/blind-eval-private-v4-20261030/.
They are excluded here along with authentication, license copies and private
model reasoning. Generate NEW business secrets and VM seeds for future blind
attacks. Public scripts can reproduce fresh paired experiments, but publishing
these old samples is not a new holdout.

Token counts are the CLI's cumulative input+output; cached input is a subset of
input, not an additional count. Actual per-trial billed USD is unavailable.
Instruction measurements are ARM64 Unicorn counts on 120 matched valid inputs
per variant, not device latency or CPU cycle measurements.
