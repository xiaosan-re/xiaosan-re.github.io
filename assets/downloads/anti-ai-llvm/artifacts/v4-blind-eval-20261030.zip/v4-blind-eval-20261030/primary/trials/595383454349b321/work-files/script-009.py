import struct
p='target.so'; d=open(p,'rb').read()
print(len(d),d[:4])
# ELF64 header
(e_phoff,e_shoff)=struct.unpack_from('<QQ',d,32)
e_phentsize,e_phnum,e_shentsize,e_shnum,e_shstrndx=struct.unpack_from('<HHHHH',d,54)
print(hex(e_phoff),e_phnum,hex(e_shoff),e_shnum,e_shstrndx)
for i in range(e_phnum):
 o=e_phoff+i*e_phentsize
 typ,flags,off,va,pa,fs,ms,al=struct.unpack_from('<IIQQQQQQ',d,o)
 print('PH',i,typ,hex(flags),hex(off),hex(va),hex(fs),hex(ms))
try:
 import capstone; print('capstone',capstone.__version__)
except Exception as e: print('no capstone',e)