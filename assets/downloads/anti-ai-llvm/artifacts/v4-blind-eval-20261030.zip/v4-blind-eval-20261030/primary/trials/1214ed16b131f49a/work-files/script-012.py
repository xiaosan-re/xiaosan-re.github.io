from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
B=0x100000;S=0x200000;E=0x300000
with open('target.so','rb') as f:elf=ELFFile(f);segs=[(x['p_vaddr'],x.data()) for x in elf.iter_segments() if x['p_type']=='PT_LOAD']
def run(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000)
 for v,d in segs:u.mem_write(B+v,d)
 u.mem_write(B+0x4f9c,b'\xc0\x03\x5f\xd6');u.mem_map(S,0x10000);u.mem_map(E,0x1000);u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 u.emu_start(B+0x38cc,E,count=100000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
for defaults,idx,vals in [((0,0,0,0),0,range(0,65)),((10,0,0,0),1,range(0,21)),((10,0,0,0),2,[0,1,2,3,10,100,999,1000,5000,9299,9300,9301,9999,10000,10001,65535,0xffffffff]),((10,0,0,0),3,list(range(0,25))+[47,48,64,100,0xffffffff])]:
 out=[]
 for v in vals:
  a=list(defaults);a[idx]=v;out.append((v,run(a)))
 print('IDX',idx,out)
# a x d small with b=0,c=0
for aa in range(8): print('ad',aa,[run((aa,0,0,d)) for d in range(10)])