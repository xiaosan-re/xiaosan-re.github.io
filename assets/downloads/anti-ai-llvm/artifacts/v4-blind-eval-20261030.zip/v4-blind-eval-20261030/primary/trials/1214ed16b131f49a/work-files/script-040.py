# Compact clean emulator, search valid shape over b,c and vary d/a once b,c pass.
from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
B=0x100000;S=0x200000;E=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x['p_vaddr'],x.data()) for x in e.iter_segments() if x['p_type']=='PT_LOAD']
def run(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000)
 for v,d in segs:u.mem_write(B+v,d)
 u.mem_write(B+0x4f9c,b'\x00\x00\x80\x52\xc0\x03\x5f\xd6');u.mem_map(S,0x10000);u.mem_map(E,0x1000);u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 u.emu_start(B+0x38cc,E,count=100000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
print('b,c grid',[[hex(run((1,b,c,0))) for c in range(5)] for b in range(8)])
for idx,name in [(0,'a'),(3,'d')]:
 print(name)
 for v in list(range(0,70))+[100,149,279,409,9300,0x7fffffff,0xffffffff]:
  x=[1,1,0,0];x[idx]=v;o=run(tuple(x))
  if o<0x80000000:print(v,hex(o))
  elif v<20: print(v,hex(o))