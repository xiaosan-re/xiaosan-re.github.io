import struct
b=open('target.so','rb').read()
for a in range(0x456c,0x4700,16):
 w=struct.unpack_from('<4I',b,a)
 print(f'{a:04x}:',' '.join(f'{x:08x}' for x in w))