from unicorn import *
from unicorn.arm64_const import *
import random,collections
blob=open('target.so','rb').read();u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000)
def hk(q,p,s,z):
 if p==0x4f9c:q.reg_write(UC_ARM64_REG_W0,0);q.reg_write(UC_ARM64_REG_PC,q.reg_read(UC_ARM64_REG_X30))
 elif p==0x8000:q.emu_stop()
u.hook_add(UC_HOOK_CODE,hk)
def run(x):
 u.reg_write(UC_ARM64_REG_SP,0x110000);u.reg_write(UC_ARM64_REG_X30,0x8000)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),x):u.reg_write(r,v)
 u.emu_start(0x38cc,0x8004,count=100000);return u.reg_read(UC_ARM64_REG_W0)
for c in [0,1,2,3,4,0xffffffff]:
 ranges=[];last=None;start=0
 for b in range(1001):
  r=run((0,b,c,0))
  if r!=last:
   if last is not None:ranges.append((start,b-1,last))
   start=b;last=r
 ranges.append((start,1000,last));print('c',hex(c),[(a,b,hex(r)) for a,b,r in ranges])
co=collections.Counter(); ex={}
random.seed(2)
for i in range(10000):
 x=tuple(random.getrandbits(32) for _ in range(4));r=run(x);co[r]+=1;ex.setdefault(r,x)
print('random',[(hex(k),v,tuple(hex(q) for q in ex[k])) for k,v in co.items()])