from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
import struct
BASE=0x1000000; STACK=0x2000000; STOP=0x3000000
with open('target.so','rb') as f:
 raw=f.read(); f.seek(0); e=ELFFile(f); segs=[p for p in e.iter_segments() if p['p_type']=='PT_LOAD']
def run(args,trace=False):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
 u.mem_map(BASE,0xe000); u.mem_map(STACK,0x10000); u.mem_map(STOP,0x1000)
 for p in segs:u.mem_write(BASE+p['p_vaddr'],raw[p['p_offset']:p['p_offset']+p['p_filesz']])
 u.reg_write(UC_ARM64_REG_SP,STACK+0xf000); u.reg_write(UC_ARM64_REG_LR,STOP)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),args):u.reg_write(r,v)
 pcs=[]
 def code(uc,a,s,d):
  if trace: pcs.append(a-BASE)
 def bad(uc,access,a,size,val,d):
  print('BAD',access,hex(a),size,hex(uc.reg_read(UC_ARM64_REG_PC)-BASE));return False
 def intr(uc,n,d):
  print('INTR',n,'pc',hex(uc.reg_read(UC_ARM64_REG_PC)-BASE),'x8',uc.reg_read(UC_ARM64_REG_X8),'args',[hex(uc.reg_read(r)) for r in (UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2)])
  uc.reg_write(UC_ARM64_REG_X0,0xffffffffffffffff)
 u.hook_add(UC_HOOK_CODE,code);u.hook_add(UC_HOOK_MEM_INVALID,bad);u.hook_add(UC_HOOK_INTR,intr)
 try:u.emu_start(BASE+0x38cc,STOP,count=1000000)
 except UcError as x:print('ERR',x,'at',hex(u.reg_read(UC_ARM64_REG_PC)-BASE))
 print(args,'=>',hex(u.reg_read(UC_ARM64_REG_X0)&0xffffffff),'steps',len(pcs), 'path', ' '.join(hex(x) for x in pcs[:200]))
for a in [(0,0,0,0),(1,2,3,4),(100,9300,17,0),(0xffffffff,0xffffffff,0xffffffff,0xffffffff)]:run(a,True)