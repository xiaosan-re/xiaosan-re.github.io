M=0xffffffff
def fmix(x):
 x&=M;x^=x>>16;x=(x*0x7feb352d)&M;x^=x>>15;x=(x*0x846ca68b)&M;x^=x>>16;return x&M
def h1(a):return fmix((a+0x7188bda9)&M)
def h2(a):return fmix(a^0x9b05606f)
for a in range(8): print(a,hex(h1(a)),hex(h2(a)))
