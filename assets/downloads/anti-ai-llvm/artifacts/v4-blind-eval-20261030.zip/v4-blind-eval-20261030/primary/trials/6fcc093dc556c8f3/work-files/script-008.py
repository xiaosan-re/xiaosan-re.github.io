from elftools.elf.elffile import ELFFile
from capstone import *
with open('target.so','rb') as f:
 e=ELFFile(f); s=e.get_section_by_name('.text'); data=s.data(); addr=s['sh_addr']
 md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN)
 for i in md.disasm(data,addr): print(f'{i.address:04x}: {i.mnemonic:8} {i.op_str}')