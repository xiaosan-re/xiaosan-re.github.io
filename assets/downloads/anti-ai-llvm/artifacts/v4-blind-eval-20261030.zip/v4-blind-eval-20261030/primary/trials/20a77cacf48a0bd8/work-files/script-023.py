from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
with open('target.so','rb') as f:
 e=ELFFile(f);seg=[(p['p_vaddr'],p['p_memsz'],p.data()) for p in e.iter_segments() if p['p_type']=='PT_LOAD']
def run(q):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
 for a,m,b in seg:
  try:u.mem_map(a&~4095,((a+m+4095)&~4095)-(a&~4095))
  except:pass
  u.mem_write(a,b)
 u.mem_map(0x100000,4096);u.mem_map(0x200000,0x20000);u.reg_write(UC_ARM64_REG_SP,0x21fff0);u.reg_write(UC_ARM64_REG_LR,0x100000)
 for r,v in zip([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3],q):u.reg_write(r,v)
 seq=[]
 def h(uc,a,s,d):
  seq.append(a)
  if a==0x45ac:uc.reg_write(UC_ARM64_REG_X0,0);uc.reg_write(UC_ARM64_REG_PC,0x45b0)
  if a==0x100000:uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x100004,count=1000000)
 return u.reg_read(UC_ARM64_REG_W0),seq
cases=[(1,2,3,4),(0xdeadbeef,2,3,0xcafebabe),(1,0,3,4),(1,101,3,4),(1,2,2,4),(0xffffffff,100,0xffffffff,0)]
res=[]
for q in cases:
 r,s=run(q);res.append((r,s));print(q,hex(r),len(s),hex(s[-2]))
for j in range(1,len(cases)):
 a=res[0][1];b=res[j][1];i=0
 while i<min(len(a),len(b)) and a[i]==b[i]:i+=1
 print('diff base vs',cases[j],'at',i,hex(a[i]) if i<len(a) else '-',hex(b[i]) if i<len(b) else '-')
# compare exact paths varying ignored candidates
print('same path a,d?',res[0][1]==res[1][1])
for idx in range(len(cases)):
 print('\nCASE',cases[idx],'tail')
 s=res[idx][1]
 # compressed final 80 branch transitions
 trans=[];st=s[0]
 for i in range(1,len(s)):
  if s[i]!=s[i-1]+4:trans.append((st,s[i-1],s[i]));st=s[i]
 for x in trans[-35:]:print('%x-%x>%x'%x,end=' ')
 print()