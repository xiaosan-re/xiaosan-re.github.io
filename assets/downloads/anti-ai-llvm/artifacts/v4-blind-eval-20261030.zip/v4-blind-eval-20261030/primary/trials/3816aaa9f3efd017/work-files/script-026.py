p='/opt/homebrew/Cellar/capstone/5.0.7/include/capstone/capstone.h'
for l in open(p):
 if 'CS_ARCH_AARCH64' in l or 'CS_MODE_LITTLE_ENDIAN' in l or 'cs_disasm(' in l: print(l.rstrip())