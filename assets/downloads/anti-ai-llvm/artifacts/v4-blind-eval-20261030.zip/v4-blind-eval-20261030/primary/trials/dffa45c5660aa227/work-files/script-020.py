import struct
b=open('target.so','rb').read()
for a in range(0x456c,0x62d4,4):
 w=struct.unpack_from('<I',b,a)[0]; out=None
 if w>>26 in (0b000101,0b100101):
  imm=w&0x3ffffff; imm-= (1<<26) if imm&(1<<25) else 0; out=('bl' if w>>31 else 'b',a+imm*4)
 elif w&0xff000010==0x54000000:
  imm=(w>>5)&0x7ffff; imm-=1<<19 if imm&(1<<18) else 0; out=(f'b.cond{w&15:x}',a+imm*4)
 elif w&0x7e000000==0x34000000:
  imm=(w>>5)&0x7ffff; imm-=1<<19 if imm&(1<<18) else 0; out=(('cbnz' if w&(1<<24) else 'cbz'),a+imm*4)
 elif w&0x7e000000==0x36000000:
  imm=(w>>5)&0x3fff; imm-=1<<14 if imm&(1<<13) else 0; bit=((w>>31)&1)*32+((w>>19)&31); out=(('tbnz' if w&(1<<24) else 'tbz')+f' bit{bit}',a+imm*4)
 elif w&0xfffffc1f==0xd65f0000: out=('ret/br?',None)
 if out: print(f'{a:04x} {w:08x} {out[0]} {"" if out[1] is None else hex(out[1])}')