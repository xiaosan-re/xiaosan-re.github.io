from unicorn import *
from unicorn.arm64_const import *
blob=open('target.so','rb').read(); A=(0x11,0x22,0x33,0x44)
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
for i,x in enumerate(A):u.reg_write(UC_ARM64_REG_X0+i,x)
u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000)
it=[-1]
blocks={0x6008,0x60c0,0x5b70,0x5a34,0x61f8,0x5e24,0x6270,0x6030,0x6258,0x60a8,0x5b50,0x6288,0x606c,0x5b30}
def h(u,a,s,z):
 if a==0x6e74:u.reg_write(UC_ARM64_REG_X0,0);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
 if a==0x530c:it[0]+=1
 if it[0]>=69 and a in blocks:
  print(it[0],hex(a),' '.join(f'x{i}={u.reg_read(UC_ARM64_REG_X0+i)&0xffffffff:08x}' for i in range(29)))
u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=100000)
print('ret',hex(u.reg_read(UC_ARM64_REG_W0)))