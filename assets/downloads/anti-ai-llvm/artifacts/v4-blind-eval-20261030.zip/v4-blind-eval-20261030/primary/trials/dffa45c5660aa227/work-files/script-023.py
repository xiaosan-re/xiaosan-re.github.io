import struct
b=open('target.so','rb').read()
def R(n,sf=0,sp=False): return ('x' if sf else 'w')+('sp' if n==31 and sp else ('zr' if n==31 else str(n)))
def ds(a,w):
 sf=(w>>31)&1; rd=w&31; rn=(w>>5)&31
 # add/sub imm
 if w&0x1f000000==0x11000000:
  op=(w>>30)&1; S=(w>>29)&1; imm=(w>>10)&0xfff; imm <<= 12 if w&(1<<22) else 0
  name=('sub' if op else 'add')+('s' if S else '')
  return f'{name} {R(rd,sf,True)},{R(rn,sf,True)},#{imm:#x}'
 if w&0x1f800000==0x12800000:
  opc=(w>>29)&3; imm=(w>>5)&0xffff; sh=((w>>21)&3)*16
  return f'{["movn","?","movz","movk"][opc]} {R(rd,sf)},#{imm:#x},lsl#{sh}'
 if w&0x1f000000==0x0b000000:
  op=(w>>30)&1; S=(w>>29)&1; rm=(w>>16)&31; sh=(w>>22)&3; amt=(w>>10)&0x3f
  return f'{("sub" if op else "add")+("s" if S else "")} {R(rd,sf)},{R(rn,sf)},{R(rm,sf)},{["lsl","lsr","asr","ror"][sh]}#{amt}'
 if w&0x1f000000==0x0a000000:
  opc=(w>>29)&3; N=(w>>21)&1; rm=(w>>16)&31; sh=(w>>22)&3; amt=(w>>10)&0x3f
  return f'{["and","orr","eor","ands"][opc]}{ "n" if N else ""} {R(rd,sf)},{R(rn,sf)},{R(rm,sf)},{["lsl","lsr","asr","ror"][sh]}#{amt}'
 if w&0x1f000000==0x1b000000:
  rm=(w>>16)&31; ra=(w>>10)&31; sub=(w>>15)&1
  return f'{"msub" if sub else "madd"} {R(rd,sf)},{R(rn,sf)},{R(rm,sf)},{R(ra,sf)}'
 # unscaled ldst word/x by size/opc
 if w&0x3b200c00==0x38000000:
  size=(w>>30)&3; opc=(w>>22)&3; imm=(w>>12)&0x1ff; imm-=0x200 if imm&0x100 else 0; rt=rd
  nam={0:'str',1:'ldr',2:'ldrsw'}.get(opc,f'ld?{opc}')
  return f'{nam} {R(rt,1 if size==3 else 0)},[{R(rn,1,True)},#{imm}]'
 if w&0x3b000000==0x39000000:
  size=(w>>30)&3; opc=(w>>22)&3; imm=((w>>10)&0xfff)<<size; rt=rd
  nam={0:'str',1:'ldr',2:'ldrsw'}.get(opc,f'ld?{opc}')
  return f'{nam} {R(rt,1 if size==3 else 0)},[{R(rn,1,True)},#{imm}]'
 return f'.word {w:08x}'
for a in range(0x45c0,0x4750,4):
 w=struct.unpack_from('<I',b,a)[0]; print(f'{a:04x}: {ds(a,w)}')