import struct
b=open('target.so','rb').read()
for start,end in [(0x530c,0x5500),(0x5878,0x5a30)]:
 print('---')
 for a in range(start,end-12,4):
  w0,w1,w2,w3=struct.unpack_from('<4I',b,a)
  if w0&0x7f800000==0x52800000 and w1&0x7f800000==0x72800000 and w2&0xff000000==0x6b000000 and w3&0xff00001f==0x54000000:
   c=((w1>>5&0xffff)<<16)|(w0>>5&0xffff); im=w3>>5&0x7ffff;im-=1<<19 if im&(1<<18) else 0
   print(f'{c:08x} -> {a+12+im*4:04x}')