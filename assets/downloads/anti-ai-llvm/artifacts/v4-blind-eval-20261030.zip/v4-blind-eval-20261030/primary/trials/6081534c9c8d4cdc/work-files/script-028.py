from unicorn import *
from unicorn.arm64_const import *
blob=open('target.so','rb').read();u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000)
def hk(q,p,s,z):
 if p==0x4f9c:q.reg_write(UC_ARM64_REG_W0,0);q.reg_write(UC_ARM64_REG_PC,q.reg_read(UC_ARM64_REG_X30))
 elif p==0x8000:q.emu_stop()
u.hook_add(UC_HOOK_CODE,hk)
def run(x):
 u.reg_write(UC_ARM64_REG_SP,0x110000);u.reg_write(UC_ARM64_REG_X30,0x8000)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),x):u.reg_write(r,v)
 u.emu_start(0x38cc,0x8004,count=100000);return u.reg_read(UC_ARM64_REG_W0)
vals=list(range(0,21))+[31,32,63,64,99,100,101,127,128,255,256,999,0x7fffffff,0x80000000,0xffffffff]
for c in range(3):
 print('C',c)
 for pos in (0,3):
  g={}
  for v in vals:
   x=[0,1,c,0];x[pos]=v;g.setdefault(run(x),[]).append(v)
  print('ARG',pos,[(hex(r),[hex(v) for v in vs]) for r,vs in g.items()])
print('a,d 0..10 c0')
for a in range(11):print(a,[hex(run((a,1,0,d))) for d in range(11)])