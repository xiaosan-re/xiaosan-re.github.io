import ctypes.util,glob
print(ctypes.util.find_library('capstone'))
print(glob.glob('/usr/lib/**/libcapstone*',recursive=True)[:20],glob.glob('/opt/**/libcapstone*',recursive=True)[:20])