from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f)
 for sn in ['.dynsym','.rela.plt','.dynamic']:
  s=e.get_section_by_name(sn); print(sn)
  if sn=='.dynsym':
   for x in s.iter_symbols(): print(x.name,x.entry)
  elif sn=='.rela.plt':
   for x in s.iter_relocations(): print(x.entry)
  else:
   for x in s.iter_tags(): print(x.entry)
 print('rodata strings')
 s=e.get_section_by_name('.rodata'); d=s.data(); base=s['sh_addr']
 import re
 for m in re.finditer(rb'[ -~]{4,}',d): print(hex(base+m.start()),m.group()[:200])
