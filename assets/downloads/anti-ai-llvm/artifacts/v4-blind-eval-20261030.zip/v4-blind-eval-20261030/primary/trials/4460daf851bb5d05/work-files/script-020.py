s=open('disasm.txt').read().splitlines()
for lo,hi in [(0x4d00,0x4f00),(0x4f00,0x5100),(0x5100,0x5320),(0x5300,0x5530),(0x5500,0x58a0)]:
 print('\nRANGE',hex(lo),hex(hi))
 for x in s:
  a=int(x[:4],16)
  if lo<=a<hi:print(x)