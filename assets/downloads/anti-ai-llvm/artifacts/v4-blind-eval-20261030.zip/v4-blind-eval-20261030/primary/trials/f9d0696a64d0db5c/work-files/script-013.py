from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 b=f.read()
for a in range(0x4300,0x452c,16):
 c=b[a:a+16]
 print(hex(a),c.hex(),''.join(chr(x) if 32<=x<127 else '.' for x in c))