print(hex(0x05988750^0x74103af9))
# verify compare condition from helper and hash direct for some values
