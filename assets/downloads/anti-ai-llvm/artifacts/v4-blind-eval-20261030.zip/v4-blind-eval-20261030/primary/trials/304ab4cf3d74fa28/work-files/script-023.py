from pathlib import Path
import struct,collections
b=Path('target.so').read_bytes(); D=b[0x38cc:0x3f74]
c=collections.Counter(struct.unpack_from('<I',D,i)[0]>>24 for i in range(0,len(D),4))
for k,v in c.most_common(): print(f'{k:02x}',v)