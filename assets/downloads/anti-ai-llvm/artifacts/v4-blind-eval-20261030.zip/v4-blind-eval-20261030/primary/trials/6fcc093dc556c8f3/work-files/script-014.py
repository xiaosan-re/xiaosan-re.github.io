from unicorn import *
from unicorn.arm64_const import *
BASE=0x100000; STACK=0x200000; STOP=0x300000
blob=open('target.so','rb').read()
def run(args,verbose=False):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0x10000);u.mem_write(BASE,blob[:2032]);u.mem_write(BASE+0x47f0,blob[0x7f0:0x8e0]);u.mem_map(STACK,0x10000);u.mem_map(STOP,0x1000)
 u.reg_write(UC_ARM64_REG_SP,STACK+0x8000);u.reg_write(UC_ARM64_REG_LR,STOP)
 for r,v in zip([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3],args):u.reg_write(r,v)
 trace=[]
 def hk(uc,a,size,user):
  trace.append(a-BASE if BASE<=a<BASE+0x10000 else a)
  if a==STOP: uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,hk)
 try:u.emu_start(BASE+0x32c,STOP+4,count=100000)
 except UcError as e: print('ERR',e,'pc',hex(u.reg_read(UC_ARM64_REG_PC)-BASE),'n',len(trace))
 print(args,'=>',hex(u.reg_read(UC_ARM64_REG_X0)&0xffffffff),'n',len(trace),'last',[hex(x) for x in trace[-20:]])
 if verbose: print(' '.join(hex(x) for x in trace))
for a in [(0,0,0,0),(1,2,3,4),(0xffffffff,0xffffffff,0xffffffff,0xffffffff),(123,456,789,1011)]:run(a,True)
