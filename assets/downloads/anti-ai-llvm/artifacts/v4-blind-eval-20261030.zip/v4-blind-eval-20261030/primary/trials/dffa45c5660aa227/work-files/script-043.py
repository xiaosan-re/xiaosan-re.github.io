a=3954774723
u=lambda x:x&0xffffffff
def m(x):x=u(x^(x>>16));x=u(x*0x7feb352d);x=u(x^(x>>15));x=u(x*0x846ca68b);return u(x^(x>>16))
print(hex(a),hex(m(u(a+0x4c55a6ee))),m(u(a+0x4c55a6ee))&7)
# Maybe constant reg13 is 4c55a6ee yes.