#include <stdint.h>

static uint32_t token_for(uint32_t a)
{
    uint32_t x = a ^ UINT32_C(0x87f7daef);
    x = ((x >> 16) ^ x) * UINT32_C(0x7feb352d);
    x = ((x >> 15) ^ x) * UINT32_C(0x846ca68b);
    return (x >> 16) ^ x;
}

static int special_discount(uint32_t a)
{
    uint32_t x = a + UINT32_C(0x7f70ea69);
    x = ((x >> 16) ^ x) * UINT32_C(0x631805ed);
    x = ((x >> 15) ^ x) * UINT32_C(0x4bb6ce6d);
    x = (x >> 16) ^ x;
    return (x & UINT32_C(0xf78dbac7)) == UINT32_C(3);
}

uint32_t recovered(uint32_t a, uint32_t b, uint32_t c, uint32_t d)
{
    uint32_t price;

    if (b == 0 || b > 100)
        return UINT32_C(0x80000001);
    if (c > UINT32_C(0x3103f66b))
        return UINT32_C(0x80000002);
    if (d != token_for(a))
        return UINT32_C(0x80000003);

    price = (c == 0 ? UINT32_C(129) :
             c == 1 ? UINT32_C(249) : UINT32_C(399)) * b;

    if (b > 9)
        price = (price * UINT32_C(85)) / UINT32_C(100);
    if (special_discount(a))
        price = (price * UINT32_C(95)) / UINT32_C(100);

    return price;
}
