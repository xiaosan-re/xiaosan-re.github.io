seed=0x05988750^0x74103af9;m1=0x7f5ba6be^0x00b09393;m2=0x2a7ecfb6^0xae12693d
print(hex(seed),hex(m1),hex(m2))
def pred(a):
 x=(a+seed)&0xffffffff;x=((x^(x>>16))*m1)&0xffffffff;x=((x^(x>>15))*m2)&0xffffffff;x^=x>>16;return (x&7)==3
print([(i,pred(i)) for i in range(64) if pred(i)])