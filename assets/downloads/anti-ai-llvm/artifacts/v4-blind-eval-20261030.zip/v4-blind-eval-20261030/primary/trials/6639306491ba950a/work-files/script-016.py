import subprocess
p=subprocess.run(['/usr/bin/objdump','-d','target.so'],capture_output=True,text=True)
print('rc',p.returncode)
print(p.stdout[:4000]); print(p.stderr[:1000])