from unicorn import *
from unicorn.arm64_const import *
import random
BASE=0x100000;STACK=0x200000;STOP=0x300000;blob=open('target.so','rb').read();R=[getattr(__import__('unicorn.arm64_const',fromlist=['x']),f'UC_ARM64_REG_X{i}') for i in range(4)]
def target(v):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0x10000);u.mem_write(BASE,blob[:2032]);u.mem_write(BASE+0x47f0,blob[0x7f0:0x8e0]);u.mem_map(STACK,0x10000);u.mem_map(STOP,0x1000);u.reg_write(UC_ARM64_REG_SP,STACK+0x8000);u.reg_write(UC_ARM64_REG_LR,STOP)
 for r,x in zip(R,v):u.reg_write(r,x)
 def h(uc,a,z,d):
  if a==STOP:uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(BASE+0x32c,STOP+4,count=10000);return u.reg_read(UC_ARM64_REG_W0)
def checksum(a):
 x=(a^0x838d31dc)&0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x&0xffffffff
def model(a,b,c,d):
 if b<1 or b>100:return 0x80000001
 if c>2:return 0x80000002
 if d!=checksum(a):return 0x80000003
 p=(129,249,399)[c]; t=b*p
 return t if b<10 else t*85//100
cases=[]
for b in range(0,106):
 for c in range(5):
  a=random.getrandbits(32);h=checksum(a);cases.append((a,b,c,h));cases.append((a,b,c,h^1))
for _ in range(100):cases.append(tuple(random.getrandbits(32) for _ in range(4)))
random.shuffle(cases)
for i,v in enumerate(cases):
 got=target(v);exp=model(*v)
 if got!=exp: print('MISMATCH',v,hex(got),hex(exp));break
else:print('all matched',len(cases))
