#include <stdint.h>

static uint32_t authenticate(uint32_t a)
{
    uint32_t x = a ^ UINT32_C(0x9b05606f);
    x = (x ^ (x >> 16)) * UINT32_C(0x7feb352d);
    x = (x ^ (x >> 15)) * UINT32_C(0x846ca68b);
    return x ^ (x >> 16);
}

static int extra_discount(uint32_t a)
{
    uint32_t x = a + UINT32_C(0x7188bda9);
    x = (x ^ (x >> 16)) * UINT32_C(0x7feb352d);
    x = (x ^ (x >> 15)) * UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return (x & 7u) == 3u;
}

uint32_t recovered(uint32_t a, uint32_t b, uint32_t c, uint32_t d)
{
    static const uint32_t base[3] = { 129u, 249u, 399u };
    uint32_t value;

    if (b < 1u || b > 100u)
        return UINT32_C(0x80000001);
    if (c >= 3u)
        return UINT32_C(0x80000002);
    if (d != authenticate(a))
        return UINT32_C(0x80000003);

    value = base[c] * b;
    if (b >= 10u)
        value = (value * 85u) / 100u;
    if (extra_discount(a))
        value = (value * 95u) / 100u;
    return value;
}
