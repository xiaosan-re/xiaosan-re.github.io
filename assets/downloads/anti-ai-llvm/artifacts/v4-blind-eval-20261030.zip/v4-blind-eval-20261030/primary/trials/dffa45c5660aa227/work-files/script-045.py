# Purpose-built trace of recovered VM for one valid case, printing only pc>=39.
import struct
D=open('target.so','rb').read();K=[0xbc479312,0x39ac5979,0xb79007c4,0x2d84cc53,0xabe8babe,0x21dd6705,0x9fc12d90,0x15351bff,0x9319c04a];u=lambda x:x&0xffffffff
def h(x):x=u(x^(x>>16));x=u(x*0x7feb352d);x=u(x^(x>>15));x=u(x*0x846ca68b);return u(x^(x>>16))
R=[[struct.unpack_from('<I',D,0x2d0+36*i+4*j)[0]^h(u(i*0x9e3779b9)^K[j]) for j in range(9)] for i in range(92)]
a=0xebb912c3;bb=2;c=2;d=h(a^0x838d31dc);r=[0]*70;r[58]=a;r[23]=bb;r[27]=c;r[14]=d;p=0
for st in range(100):
 op,z,ai,bi,ci,im,w,nx,al=R[p];A=r[ai];B=r[bi];C=r[ci]
 if p>=39:print('pc',p,'op',hex(op),'dst',z,'A',ai,hex(A),'B',bi,hex(B),'imm',im,'nx',nx,al)
 if op==0x31ef8a34:o=im
 elif op==0x432b31fa:o=A
 elif op==0xa9050067:o=u(B+A)
 elif op==0x778380a7:o=u(B*A)
 elif op==0xc179bd02:o=B^A
 elif op==0xcc213f3b:o=B&A
 elif op==0x68a9af5d:o=A>>(B&31)
 elif op==0x2d296d65:o=0 if (1 if B==0 else C)==0 else A//(1 if B==0 else C)
 elif op==0xfd23a89f:o={32:A==B,34:A>B,36:A<B}[im]
 elif op==0x86b9c54f:o=B if A else C
 elif op==0xd515b9c4:p=nx;continue
 elif op==0x9153976a:p=nx if A else al;continue
 elif op==0xe9855c9d:print('RET',hex(A));break
 bits=w&31;r[z]=u(int(o))&(0xffffffff if bits==0 else (1<<bits)-1)
 if p>=39:print(' ->',z,hex(r[z]))
 p=nx