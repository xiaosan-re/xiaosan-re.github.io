vals={
'invalid_qty_next':0xe576aa42^0x8811e5e3^0x59df2daf,
'invalid_c_next':0x26140179^0x00dcd632^0x1270b545,
'invalid_d_next':0xc3b21eb9^0xf70a7cb7,
'qty_valid':0xe4a7252e^0x9e0a27a6,
'qty_invalid':0xe4a7252e^0x01d18f6c,
'c_valid':0x7aad0288^0x37e1bbac,
'c_invalid':0x7aad0288^0x5cb903f1,
'd_valid':0x4d4cb924^0x4ff9b1f4,
'd_invalid':0x4d4cb924^0x8efea79d,
'base0':0x02b508d0^0xdaf0e110,
'base1':0x02b508d0^0xa71a7200,
'base0next':0xd845e9c0^0xc74f82b5,
'base1next':0xa5af7ad0^0xbaa511a5,
'bsmall':0x1f0a6b75^0xef740d99,
'bbig':0x1f0a6b75^0xf73f4402,
'discnext':0xe8352f77^0x184b499b,
'hfalse':0xf07e66ec^0x7d6a72fd,
'htrue':0xf07e66ec^0xe0655fc5,
'extradiscnext':0x101b3929^0x9d0f2d38,
'returnnext':0x8d141411^0xb9ac761f}
for k,v in vals.items():print(k,hex(v&0xffffffff))
# signed ordering states
states=set(vals.values())|{0xe4a7252e,0x34b8620e}
for x in sorted(states,key=lambda z:(z if z<2**31 else z-2**32)):print(hex(x),x if x<2**31 else x-2**32)
