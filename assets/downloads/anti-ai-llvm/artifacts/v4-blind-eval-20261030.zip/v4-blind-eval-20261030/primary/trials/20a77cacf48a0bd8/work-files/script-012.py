from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
with open('target.so','rb') as f:
 e=ELFFile(f)
 for p in e.iter_segments():
  if p['p_type']=='PT_LOAD':
   a=p['p_vaddr'];lo=a&~4095;hi=(a+p['p_memsz']+4095)&~4095
   try:u.mem_map(lo,hi-lo)
   except:pass
   u.mem_write(a,p.data())
u.mem_map(0x100000,4096);u.mem_map(0x200000,0x20000);u.reg_write(UC_ARM64_REG_SP,0x21fff0);u.reg_write(UC_ARM64_REG_LR,0x100000)
n=[0]
def h(uc,a,s,d):
 print(n[0],hex(a),uc.mem_read(a,4).hex(),'x0',hex(uc.reg_read(UC_ARM64_REG_X0)),'x8',hex(uc.reg_read(UC_ARM64_REG_X8)))
 n[0]+=1
 if n[0]>50:uc.emu_stop()
u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x100004,count=60)