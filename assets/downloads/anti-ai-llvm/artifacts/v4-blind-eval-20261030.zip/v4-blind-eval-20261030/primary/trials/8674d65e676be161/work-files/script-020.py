import ctypes.util,glob,os
print('capstone',ctypes.util.find_library('capstone'))
for p in ['/usr/lib','/usr/local/lib','/opt/homebrew/lib']:
 print(p,glob.glob(p+'/*capstone*')[:10],glob.glob(p+'/*LLVM*')[:10])
