from unicorn import *
from unicorn.arm64_const import *
with open('target.so','rb') as f:blob=f.read()
def u32(x):return x&0xffffffff
def mix(a,base):
 x=u32(a+base) if base==0x7f70ea69 else a^base
 x^=x>>16;x=u32(x*0x7feb352d);x^=x>>15;x=u32(x*0x846ca68b);x^=x>>16;return u32(x)
def h(a):return mix(a,0x87f7daef)
def sel(a):return mix(a,0x7f70ea69)&7
def run(a,b,c,d):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x10000);u.reg_write(UC_ARM64_REG_SP,0x108000);u.reg_write(UC_ARM64_REG_X30,0x9000)
 for r,x in zip([UC_ARM64_REG_W0,UC_ARM64_REG_W1,UC_ARM64_REG_W2,UC_ARM64_REG_W3],[a,b,c,d]):u.reg_write(r,x)
 u.emu_start(0x32c,0x9000,count=10000);return u.reg_read(UC_ARM64_REG_W0)
for a in list(range(16))+[100,0xffffffff,0x12345678,0x80000000]:
 print('a',hex(a),'h',hex(h(a)),'sel',sel(a), end=': ')
 for b in [1,2,3,9,10,50,100]: print([hex(run(a,b,c,h(a))) for c in range(3)],end=' ')
 print()