def fm(x):
 x&=0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x
for i in [0,25,29,54,58]:
 print(i,hex(fm(i^0x11da8884)|1),hex(i*0xc2b2ae35&0xffffffff),hex(i*0x85ebca6b&0xffffffff))