import subprocess
r=subprocess.run(['/usr/bin/objdump','-d','--start-address=0x456c','--stop-address=0x4700','target.so'],capture_output=True,text=True)
print('rc',r.returncode); print(r.stdout); print(r.stderr)