import struct
b=open('target.so','rb').read()
for a in range(0x380,0x780,4):
 w=struct.unpack_from('<I',b,a)[0]
 if (w & 0x7fe08000)==0x1b000000: # madd family maybe
  print(hex(a),hex(w),'rd',w&31,'rn',(w>>5)&31,'ra',(w>>10)&31,'rm',(w>>16)&31,'op',(w>>21)&15)
