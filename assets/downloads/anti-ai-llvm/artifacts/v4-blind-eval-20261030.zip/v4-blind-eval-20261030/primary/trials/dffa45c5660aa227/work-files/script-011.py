import struct
p='target.so'
b=open(p,'rb').read()
print(len(b),b[:16].hex())
# ELF64 headers
E=struct.unpack_from('<16sHHIQQQIHHHHHH',b,0)
print('type machine entry phoff shoff flags ehsize phentsize phnum shentsize shnum shstr',E[1:])
for i in range(E[10]):
 o=E[5]+i*E[9]
 print('PH',i,struct.unpack_from('<IIQQQQQQ',b,o))
try:
 import capstone
 print('capstone',capstone.__version__)
except Exception as e: print('no capstone',repr(e))