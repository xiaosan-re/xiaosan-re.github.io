import re,base64,textwrap
s=open('compact.c').read();c=open('ir.lz','rb').read();b=base64.b64encode(c).decode();lit='static const char I[]=\n'+'\n'.join('"'+x+'"' for x in textwrap.wrap(b,120))+';'
s=re.sub(r'static const char I\[\]=\n.*?;\nstatic unsigned vv',lit+'\nstatic unsigned vv',s,flags=re.S)
s=s.replace('uint8_t m[0x5000]={0};uint32_t pc=0,im;', 'uint8_t m[0x5000]={0},ir[18610];uint32_t pc=0,im;')
needle='int32_t si;x[29]=0x4000;'
dec='int32_t si;{size_t u=0,v=0;while(u<18610){unsigned t=q(I,v++);if(t<128){unsigned j=t+1;while(j--)ir[u++]=q(I,v++);}else{unsigned j=(t&127)+3,dd=q(I,v)|((unsigned)q(I,v+1)<<8);v+=2;while(j--){ir[u]=ir[u-dd];u++;}}}}x[29]=0x4000;'
s=s.replace(needle,dec)
for i in range(10):s=s.replace(f'q(I,k{("+"+str(i)) if i else ""})',f'ir[k{("+"+str(i)) if i else ""}]')
open('compact2.c','w').write(s);print(len(s),len(b))