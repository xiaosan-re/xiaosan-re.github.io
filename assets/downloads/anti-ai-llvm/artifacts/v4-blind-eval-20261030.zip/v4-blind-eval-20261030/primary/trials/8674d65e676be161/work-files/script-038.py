from unicorn import *
from unicorn.arm64_const import *
import struct,random
raw=open('target.so','rb').read();B=0x100000;ST=0x800000;S=0x900000;mu=Uc(UC_ARCH_ARM64,UC_MODE_ARM);mu.mem_map(B,0x10000);mu.mem_write(B,raw[:0x7200]);mu.mem_write(B+0xb200,raw[0x7200:0x72f0]);mu.mem_map(ST,0x20000);mu.mem_map(S,0x1000)
def hk(mu,a,s,u):
 if a==B+0x6e74:mu.reg_write(UC_ARM64_REG_X0,0);mu.reg_write(UC_ARM64_REG_PC,mu.reg_read(UC_ARM64_REG_LR))
 elif a==S:mu.emu_stop()
mu.hook_add(UC_HOOK_CODE,hk);R=[UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3]
def run(v):
 mu.reg_write(UC_ARM64_REG_SP,ST+0x10000);mu.reg_write(UC_ARM64_REG_LR,S)
 for r,x in zip(R,v):mu.reg_write(r,x)
 mu.emu_start(B+0x456c,S,count=200000);return mu.reg_read(UC_ARM64_REG_X0)&0xffffffff
def mix(x):
 x&=0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x
def f(a,b,c,d):
 if b<1 or b>100:return 0x80000001
 if c>2:return 0x80000002
 if d!=mix(a^0x9b05606f):return 0x80000003
 v=([129,249,399][c]*b)&0xffffffff
 if b>9:v=((v*85)&0xffffffff)//100
 if mix((a+0x7188bda9)&0xffffffff)&7==3:v=((v*95)&0xffffffff)//100
 return v
for i in range(40):
 a=random.randrange(2**32);b=random.choice([0,1,9,10,11,100,101,0xffffffff]);c=random.choice([0,1,2,3,0xffffffff]);d=mix(a^0x9b05606f)
 if i%4==0:d^=1
 v=(a,b,c,d);x=run(v);y=f(*v)
 if x!=y:print('BAD',v,hex(x),hex(y))
print('done')
