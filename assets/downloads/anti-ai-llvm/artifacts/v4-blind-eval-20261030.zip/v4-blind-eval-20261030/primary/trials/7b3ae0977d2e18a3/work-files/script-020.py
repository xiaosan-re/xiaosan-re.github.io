from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
B=0x100000;S=0x200000;E=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x.header.p_vaddr,x.data()) for x in e.iter_segments() if x.header.p_type=='PT_LOAD']
def once(a,stop=None):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000);u.mem_map(S,0x10000);u.mem_map(E,0x1000)
 for v,d in segs:u.mem_write(B+v,d)
 u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 if stop:
  def h(uc,ad,sz,user):
   if ad-B==stop: uc.emu_stop()
  u.hook_add(UC_HOOK_CODE,h)
 u.emu_start(B+0x32c,E,count=1000);return u
def expected(a):
 u=once((a,50,10,0),0x428);return u.reg_read(UC_ARM64_REG_X23)&0xffffffff
for a in [0,1,2,3,4,5,10,36,100,0x12345678,0xffffffff]:
 d=expected(a);print('a',hex(a),'d',hex(d))
 for b in [1,8,9,10,100]:
  for c in [2,3,10]:
   u=once((a,b,c,d));o=u.reg_read(UC_ARM64_REG_X0)&0xffffffff
   print(b,c,hex(o),end=';')
  print(end=' | ')
 print()
