from unicorn import *
from unicorn.arm64_const import *
import struct
raw=open('target.so','rb').read();B=0x100000;ST=0x800000;S=0x900000
mu=Uc(UC_ARCH_ARM64,UC_MODE_ARM);mu.mem_map(B,0x10000);mu.mem_write(B,raw[:0x7200]);mu.mem_write(B+0xb200,raw[0x7200:0x72f0]);mu.mem_map(ST,0x20000);mu.mem_map(S,0x1000)
ops=set([0x5b30,0x5b50,0x5b70,0x5b98,0x5bc0,0x5be8,0x5c10,0x5c38,0x5c60,0x5c8c,0x5cb8,0x5ce4,0x5d1c,0x5d80,0x5dbc,0x5e24,0x5f80,0x5fb4,0x5fd4,0x6008,0x6030,0x606c,0x6090,0x60a8,0x60c0,0x60d8,0x60f0,0x6108,0x6120,0x6138,0x6150,0x6168,0x6180,0x6198,0x61b0,0x61c8,0x61e0,0x61f8,0x6210,0x6228,0x6240,0x6258,0x6270,0x6288,0x5a34,0x5b0c])
seq=[]
def rw(addr):return struct.unpack('<I',mu.mem_read(addr,4))[0]
def hook(mu,a,s,u):
 p=a-B
 if p==0x6e74:mu.reg_write(UC_ARM64_REG_X0,0);mu.reg_write(UC_ARM64_REG_PC,mu.reg_read(UC_ARM64_REG_LR));return
 if a==S:mu.emu_stop();return
 if p==0x551c:
  fp=mu.reg_read(UC_ARM64_REG_X29);ptr=struct.unpack('<Q',mu.mem_read(fp-8,8))[0];seq.append(['I',rw(ptr)])
 elif p in ops:
  rec=['O',hex(p)]
  for r in [UC_ARM64_REG_X0,UC_ARM64_REG_X3,UC_ARM64_REG_X4,UC_ARM64_REG_X10,UC_ARM64_REG_X11,UC_ARM64_REG_X13,UC_ARM64_REG_X14]:
   q=mu.reg_read(r);rec.append((hex(q),rw(q) if ST<=q<ST+0x20000 else None))
  seq.append(rec)
mu.hook_add(UC_HOOK_CODE,hook)
mu.reg_write(UC_ARM64_REG_SP,ST+0x10000);mu.reg_write(UC_ARM64_REG_LR,S)
for r,v in zip([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3],[1,2,3,4]):mu.reg_write(r,v)
mu.emu_start(B+0x456c,S,count=200000)
print('ret',hex(mu.reg_read(UC_ARM64_REG_X0)), 'events',len(seq))
for x in seq:print(x)
