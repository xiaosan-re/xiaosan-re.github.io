from unicorn import *
from unicorn.arm64_const import *
BASE=0x100000;STACK=0x200000;STOP=0x300000; blob=open('target.so','rb').read()
regs=[getattr(__import__('unicorn.arm64_const',fromlist=['x']),f'UC_ARM64_REG_X{i}') for i in range(31)]
def snap(args):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0x10000);u.mem_write(BASE,blob[:2032]);u.mem_write(BASE+0x47f0,blob[0x7f0:0x8e0]);u.mem_map(STACK,0x10000);u.mem_map(STOP,0x1000);u.reg_write(UC_ARM64_REG_SP,STACK+0x8000);u.reg_write(UC_ARM64_REG_LR,STOP)
 for r,v in zip(regs[:4],args):u.reg_write(r,v)
 seen=[]
 def hk(uc,a,size,user):
  off=a-BASE
  if off in [0x4fc,0x52c,0x580,0x5ac,0x5e8,0x60c,0x640,0x678,0x694,0x6b4,0x6d4,0x6f0,0x700,0x718,0x72c,0x74c,0x75c] and (off,uc.reg_read(UC_ARM64_REG_W4)) not in seen:
   seen.append((off,uc.reg_read(UC_ARM64_REG_W4)));print(hex(off),'state',hex(uc.reg_read(UC_ARM64_REG_W4)), 'regs',' '.join(f'w{i}={uc.reg_read(regs[i])&0xffffffff:08x}' for i in range(31)))
  if a==STOP:uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,hk);u.emu_start(BASE+0x32c,STOP+4,count=10000)
 print('result',hex(u.reg_read(regs[0])&0xffffffff))
snap((1,2,3,4))
