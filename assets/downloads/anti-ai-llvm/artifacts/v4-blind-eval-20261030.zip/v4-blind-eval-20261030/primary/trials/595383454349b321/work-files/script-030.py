import struct,collections
D=open('target.so','rb').read();c=collections.Counter()
for a in range(0x4588,0x62d4,4):
 w=struct.unpack_from('<I',D,a)[0]
 if w&0x3b200000==0x38000000:c[(w>>10)&3]+=1
print(c)