from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
import struct
B=0x100000;S=0x200000;E=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x['p_vaddr'],x.data()) for x in e.iter_segments() if x['p_type']=='PT_LOAD']
CASES={x for x in [0x3be8,0x3c5c,0x3cb0,0x3d00,0x3d5c,0x3dac,0x3de8,0x3e24,0x3e44,0x3e64,0x3e94,0x3eb0,0x3ecc,0x3ef8,0x3f04,0x3f38,0x3f50]}
def run(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000)
 for v,d in segs:u.mem_write(B+v,d)
 u.mem_write(B+0x4f9c,b'\x00\x00\x80\x52\xc0\x03\x5f\xd6');u.mem_map(S,0x10000);u.mem_map(E,0x1000);u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 path=[]; first=[]
 def h(uc,ad,sz,x):
  off=ad-B
  if off in CASES:path.append(off)
  if off==0x3c1c and not first:
   fp=uc.reg_read(UC_ARM64_REG_X29); vals=struct.unpack('<9I',uc.mem_read(fp-0x24,36));
   first.extend([hex(uc.reg_read(r)&0xffffffff) for r in [UC_ARM64_REG_X19,UC_ARM64_REG_X20,UC_ARM64_REG_X21,UC_ARM64_REG_X22,UC_ARM64_REG_X23,UC_ARM64_REG_X25,UC_ARM64_REG_X26,UC_ARM64_REG_X27,UC_ARM64_REG_X28]]+[tuple(hex(v) for v in vals)])
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(B+0x38cc,E,count=100000)
 return hex(u.reg_read(UC_ARM64_REG_X0)&0xffffffff),[hex(x) for x in path],first
for a in [(0,0,0,0),(1,2,3,4),(100,1,0,17),(100,2,500,17),(1,1,1,18),(10,3,1,27),(0xffffffff,)*4]:print(a,run(a))