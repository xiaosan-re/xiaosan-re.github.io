from unicorn import *
from unicorn.arm64_const import *
import struct
raw=open('target.so','rb').read(); B=0x100000; ST=0x800000; SENT=0x900000
def run(vals,verbose=True):
 mu=Uc(UC_ARCH_ARM64,UC_MODE_ARM);mu.mem_map(B,0x10000);mu.mem_write(B,raw[:0x7200]);mu.mem_write(B+0xb200,raw[0x7200:0x72f0]);mu.mem_write(B+0xb2e8,struct.pack('<Q',B+0x456c));mu.mem_map(ST,0x20000);mu.mem_map(SENT,0x1000)
 mu.reg_write(UC_ARM64_REG_SP,ST+0x10000);mu.reg_write(UC_ARM64_REG_LR,SENT)
 for r,v in zip([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3],vals):mu.reg_write(r,v)
 fds={}; nxt=[3]; tr=[]; n=[0]
 def hc(mu,a,s,u):
  n[0]+=1
  if len(tr)<20000:tr.append(a-B)
  if a==SENT:mu.emu_stop()
 def cstr(p):
  z=mu.mem_read(p,256);return bytes(z).split(b'\0')[0]
 def hi(mu,ino,u):
  sc=mu.reg_read(UC_ARM64_REG_X8); args=[mu.reg_read(x) for x in [UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3]]
  if sc==56:
   path=cstr(args[1]);fd=nxt[0];nxt[0]+=1
   if path.endswith(b'status'): data=b'Name:\ttest\nTracerPid:\t0\nState:\tR (running)\n'
   elif path.endswith(b'maps'): data=b'100000-108000 r-xp 00000000 00:00 0 /data/app/lib/arm64/libtarget.so\n800000-820000 rw-p 00000000 00:00 0 [stack]\n'
   else: fd=(1<<64)-1;data=b''
   if fd<100: fds[fd]=[data,0]
   ret=fd
  elif sc==63:
   fd=args[0]
   if fd in fds:
    data,pos=fds[fd]; chunk=data[pos:pos+args[2]];mu.mem_write(args[1],chunk);fds[fd][1]+=len(chunk);ret=len(chunk)
   else:ret=(1<<64)-1
  elif sc==57: fds.pop(args[0],None);ret=0
  else: ret=(1<<64)-38
  if verbose:print('sys',sc,list(map(hex,args)),'=>',hex(ret))
  mu.reg_write(UC_ARM64_REG_X0,ret)
 mu.hook_add(UC_HOOK_CODE,hc);mu.hook_add(UC_HOOK_INTR,hi)
 try:mu.emu_start(B+0x456c,SENT,count=2000000)
 except Exception as ex: print('ERR',ex,hex(mu.reg_read(UC_ARM64_REG_PC)-B))
 if verbose:print('ret',hex(mu.reg_read(UC_ARM64_REG_X0)),'count',n[0],'last',list(map(hex,tr[-20:])))
 return mu.reg_read(UC_ARM64_REG_X0),tr,n[0]
run((1,2,3,4))
