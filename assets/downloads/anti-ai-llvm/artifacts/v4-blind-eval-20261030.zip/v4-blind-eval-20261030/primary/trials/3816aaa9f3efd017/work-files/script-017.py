from elftools.elf.elffile import ELFFile
import struct
with open('target.so','rb') as f:
 e=ELFFile(f); t=e.get_section_by_name('.text'); d=t.data(); b=t['sh_addr']
for a in range(0x38cc,0x3f74,4):
 w=struct.unpack_from('<I',d,a-b)[0]
 if w&0xfc000000==0x94000000:
  x=w&0x3ffffff
  if x&0x2000000:x-=0x4000000
  print(hex(a),'BL',hex(a+4*x))
print('all funcs potential BL targets in text')
ts=set()
for a in range(b,b+len(d)-3,4):
 w=struct.unpack_from('<I',d,a-b)[0]
 if w&0xfc000000==0x94000000:
  x=w&0x3ffffff
  if x&0x2000000:x-=0x4000000
  z=a+4*x
  if b<=z<b+len(d):ts.add(z)
print(' '.join(hex(x) for x in sorted(ts)))