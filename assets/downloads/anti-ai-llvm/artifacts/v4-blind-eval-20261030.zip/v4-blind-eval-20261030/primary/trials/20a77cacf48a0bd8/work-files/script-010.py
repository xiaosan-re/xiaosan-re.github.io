import shutil
for x in ['llvm-objdump','objdump','aarch64-linux-gnu-objdump','clang','readelf']: print(x,shutil.which(x))
from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f);t=e.get_section_by_name('.text');b=t.data();base=t['sh_addr']
 for a in [0x456c,0x45f0,0x6e80,0x6ee0,0x6f00,0x62d4]:
  o=a-base; print(hex(a),b[o:o+128].hex())