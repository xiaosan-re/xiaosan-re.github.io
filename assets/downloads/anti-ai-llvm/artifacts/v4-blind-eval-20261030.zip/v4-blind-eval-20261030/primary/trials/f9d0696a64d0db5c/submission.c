#include <stdint.h>

static uint32_t token_mix(uint32_t x)
{
    x ^= UINT32_C(0x838d31dc);
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

static uint32_t account_mix(uint32_t x)
{
    x += UINT32_C(0x4c55a6ee);
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

uint32_t recovered(uint32_t account, uint32_t quantity,
                   uint32_t tier, uint32_t token)
{
    static const uint32_t base[3] = { 129u, 249u, 399u };
    uint32_t total;

    if ((uint32_t)(quantity - 1u) >= 100u)
        return UINT32_C(0x80000001);
    if (tier >= 3u)
        return UINT32_C(0x80000002);
    if (token != token_mix(account))
        return UINT32_C(0x80000003);

    total = quantity * base[tier];
    if (quantity >= 10u)
        total = total * 85u / 100u;
    if ((account_mix(account) & 7u) == 3u)
        total = total * 95u / 100u;

    return total;
}
