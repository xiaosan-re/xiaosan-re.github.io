from unicorn import *
from unicorn.arm64_const import *
import struct
blob=open('target.so','rb').read()
def run(args, anti=0, trace=False):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
 for i,a in enumerate(args):u.reg_write(UC_ARM64_REG_X0+i,a)
 u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000)
 n=[0]; pcs=[]
 def hc(uc,a,s,d):
  n[0]+=1
  if a==0x6e74:
   uc.reg_write(UC_ARM64_REG_X0,anti);uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_X30));return
  if trace: pcs.append(a)
 u.hook_add(UC_HOOK_CODE,hc)
 try:u.emu_start(0x456c,0x200000,count=1000000)
 except UcError as x: print('ERR',x,hex(u.reg_read(UC_ARM64_REG_PC)),n[0])
 print(args,'anti',anti,'=>',hex(u.reg_read(UC_ARM64_REG_W0)), 'n',n[0])
 if trace:
  # compress basic contiguous runs
  runs=[]
  for a in pcs:
   if runs and a==runs[-1][1]+4:runs[-1][1]=a
   else:runs.append([a,a])
  print('runs',' '.join(hex(x) if x==y else f'{x:#x}-{y:#x}' for x,y in runs))
for a in [(0,0,0,0),(1,2,3,4),(0xffffffff,)*4,(123,456,789,101112),(100,9300,62,3)]:run(a,0,True)
run((1,2,3,4),1,True)