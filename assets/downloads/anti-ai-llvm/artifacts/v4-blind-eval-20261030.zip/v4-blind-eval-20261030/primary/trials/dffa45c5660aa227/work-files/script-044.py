# Recompute key register chain directly from recovered VM semantics and print values for mismatch.
a=0xebb912c3
u=lambda x:x&0xffffffff
def mix(x):x=u(x^(x>>16));x=u(x*0x7feb352d);x=u(x^(x>>15));x=u(x*0x846ca68b);return u(x^(x>>16))
x=u(a+0x4c55a6ee)
vals=[x]
x=u(x^(x>>16));vals.append(x);x=u(x*0x7feb352d);vals.append(x);x=u(x^(x>>15));vals.append(x);x=u(x*0x846ca68b);vals.append(x);x=u(x^(x>>16));vals.append(x)
print([hex(v) for v in vals], 'and7',x&7)
print('x result start',hex(u(0xffffff9b+2)), 'times95/a',hex(u(u(u(0xffffff9b+2)*95)//a)))