import subprocess
for exe in ['llvm-objdump','aarch64-linux-gnu-objdump','objdump']:
 try:
  p=subprocess.run([exe,'-d','target.so'],capture_output=True,text=True,timeout=10)
  print(exe,p.returncode,p.stdout[:10000],p.stderr[:500])
 except Exception as e: print(exe,repr(e))