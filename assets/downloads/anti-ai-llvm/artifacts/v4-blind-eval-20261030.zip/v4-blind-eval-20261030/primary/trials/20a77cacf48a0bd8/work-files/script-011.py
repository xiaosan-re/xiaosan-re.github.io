import subprocess
p=subprocess.run(['/usr/bin/objdump','-d','target.so'],capture_output=True,text=True)
print('rc',p.returncode,'err',p.stderr[:500]); print(p.stdout[:12000])