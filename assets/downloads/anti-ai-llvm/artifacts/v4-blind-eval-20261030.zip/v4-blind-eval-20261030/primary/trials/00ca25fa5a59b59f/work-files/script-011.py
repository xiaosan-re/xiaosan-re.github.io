mods=['elftools','angr','lief','unicorn','keystone','distorm3','pwntools','pwn','binaryninja','r2pipe']
for m in mods:
 try:
  x=__import__(m); print(m,'yes')
 except Exception: pass
