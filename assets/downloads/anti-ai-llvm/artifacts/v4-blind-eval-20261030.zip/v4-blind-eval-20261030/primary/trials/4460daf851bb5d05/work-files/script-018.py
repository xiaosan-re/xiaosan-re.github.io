import struct
b=open('target.so','rb').read(); lo=0x456c; hi=0x62d4

def sx(x,n): return x-(1<<n) if x>>(n-1) else x

def reg(n,sf=1,sp=False):
 if n==31:return 'sp' if sp else ('xzr' if sf else 'wzr')
 return ('x' if sf else 'w')+str(n)
def dec(w,a):
 sf=(w>>31)&1; rd=w&31; rn=(w>>5)&31; rm=(w>>16)&31
 # branches
 if w==0xd65f03c0:return 'ret'
 if w&0xfffffc1f==0xd61f0000:return f'br {reg(rn)}'
 if w&0xfffffc1f==0xd63f0000:return f'blr {reg(rn)}'
 if w&0x7c000000==0x14000000:
  im=sx(w&0x3ffffff,26)*4;return ('bl' if w>>31 else 'b')+f' {a+im:#x}'
 if w&0xff000010==0x54000000:
  cc=['eq','ne','cs','cc','mi','pl','vs','vc','hi','ls','ge','lt','gt','le','al','nv'][w&15];return f'b.{cc} {a+sx((w>>5)&0x7ffff,19)*4:#x}'
 if w&0x7e000000==0x34000000:return f'cb{("n" if w>>24&1 else "")}z {reg(rd,sf)}, {a+sx((w>>5)&0x7ffff,19)*4:#x}'
 if w&0x7e000000==0x36000000:return f'tb{("n" if w>>24&1 else "")}z {reg(rd,sf)}, #{((w>>19)&0x1f)|((w>>26)&0x20)}, {a+sx((w>>5)&0x3fff,14)*4:#x}'
 # add/sub immediate
 if w&0x1f000000==0x11000000:
  op=(w>>30)&1;S=(w>>29)&1;im=((w>>10)&0xfff)<<(12 if w>>22&1 else 0); name=('sub' if op else 'add')+('s' if S else '')
  return f'{name} {reg(rd,sf,not S)}, {reg(rn,sf,True)}, #{im:#x}'
 # logical immediate
 if w&0x1f800000==0x12000000:
  opc=(w>>29)&3;N=(w>>22)&1;imr=(w>>16)&63;ims=(w>>10)&63
  return f'{["and","orr","eor","ands"][opc]} {reg(rd,sf)}, {reg(rn,sf)}, #bitmask(N={N},r={imr},s={ims})'
 # move wide
 if w&0x1f800000==0x12800000:
  opc=(w>>29)&3; hw=(w>>21)&3; imm=(w>>5)&0xffff;return f'{["movn","?movw","movz","movk"][opc]} {reg(rd,sf)}, #{imm:#x}, lsl #{hw*16}'
 # bitfield
 if w&0x1f800000==0x13000000:
  opc=(w>>29)&3;N=(w>>22)&1;imr=(w>>16)&63;ims=(w>>10)&63;return f'{["sbfm","bfm","ubfm","?bf"][opc]} {reg(rd,sf)}, {reg(rn,sf)}, #{imr}, #{ims}'
 if w&0x1f800000==0x13800000:
  return f'extr {reg(rd,sf)}, {reg(rn,sf)}, {reg(rm,sf)}, #{(w>>10)&63}'
 # logical shifted register
 if w&0x1f000000==0x0a000000:
  opc=(w>>29)&3;N=(w>>21)&1;sh=(w>>22)&3;imm=(w>>10)&63; nm=[['and','bic'],['orr','orn'],['eor','eon'],['ands','bics']][opc][N]
  return f'{nm} {reg(rd,sf)}, {reg(rn,sf)}, {reg(rm,sf)}, { ["lsl","lsr","asr","ror"][sh]} #{imm}'
 # add/sub shifted/extended
 if w&0x1f200000==0x0b000000:
  op=(w>>30)&1;S=(w>>29)&1;sh=(w>>22)&3;imm=(w>>10)&63;nm=('sub' if op else 'add')+('s' if S else '')
  return f'{nm} {reg(rd,sf,not S)}, {reg(rn,sf,True)}, {reg(rm,sf)}, {["lsl","lsr","asr","?"][sh]} #{imm}'
 if w&0x1f200000==0x0b200000:
  op=(w>>30)&1;S=(w>>29)&1;opt=(w>>13)&7;imm=(w>>10)&7;nm=('sub' if op else 'add')+('s' if S else '')
  return f'{nm} {reg(rd,sf,not S)}, {reg(rn,sf,True)}, {reg(rm, bool(opt&3))}, ext{opt} #{imm}'
 # adc/sbc
 if w&0x1fe0fc00==0x1a000000:
  op=(w>>30)&1;S=(w>>29)&1;return f'{("sbc" if op else "adc")+("s" if S else "")} {reg(rd,sf)}, {reg(rn,sf)}, {reg(rm,sf)}'
 # conditional select
 if w&0x1fe00000==0x1a800000:
  op=(w>>30)&1;op2=(w>>10)&3;cc=(w>>12)&15; names={(0,0):'csel',(0,1):'csinc',(1,0):'csinv',(1,1):'csneg'}
  return f'{names.get((op,op2&1),"csel?")} {reg(rd,sf)}, {reg(rn,sf)}, {reg(rm,sf)}, {cc:x}'
 # data processing 2 source
 if w&0x1fe00000==0x1ac00000:
  op=(w>>10)&0x3f; names={2:'udiv',3:'sdiv',8:'lslv',9:'lsrv',10:'asrv',11:'rorv'}
  return f'{names.get(op,"dp2_"+hex(op))} {reg(rd,sf)}, {reg(rn,sf)}, {reg(rm,sf)}'
 # dp1
 if w&0x1fe00000==0x1ac00000: pass
 # mul/add
 if w&0x1f000000==0x1b000000:
  ra=(w>>10)&31;sub=(w>>15)&1; hi=(w>>21)&7
  return f'dp3(sf={sf},hi={hi},sub={sub}) {reg(rd,sf)}, {reg(rn,sf)}, {reg(rm,sf)}, {reg(ra,sf)}'
 # pair
 if w&0x3a000000==0x28000000:
  opc=(w>>30)&3; L=(w>>22)&1; mode=(w>>23)&3; imm=sx((w>>15)&0x7f,7)*(4 if opc==0 else 8 if opc==2 else 16);rt2=(w>>10)&31
  return f'{"ldp" if L else "stp"} {reg(rd,opc==2)}, {reg(rt2,opc==2)}, [{reg(rn,1,True)}, #{imm}] mode{mode}'
 # unsigned imm load/store
 if w&0x3b000000==0x39000000:
  size=(w>>30)&3;opc=(w>>22)&3;imm=((w>>10)&0xfff)<<size; names={(0,0):'strb',(0,1):'ldrb',(1,0):'strh',(1,1):'ldrh',(2,0):'str',(2,1):'ldr',(3,0):'str',(3,1):'ldr'}
  return f'{names.get((size,opc),"ldstU?")} {reg(rd,size==3)}, [{reg(rn,1,True)}, #{imm:#x}]'
 # unscaled/pre/post/regoff load stores
 if w&0x3b200000==0x38000000:
  size=(w>>30)&3;opc=(w>>22)&3;mode=(w>>10)&3;imm=sx((w>>12)&0x1ff,9);names={(0,0):'sturb',(0,1):'ldurb',(1,0):'sturh',(1,1):'ldurh',(2,0):'stur',(2,1):'ldur',(3,0):'stur',(3,1):'ldur'}
  return f'{names.get((size,opc),"ldst?")} {reg(rd,size==3)}, [{reg(rn,1,True)}, #{imm}] mode{mode}'
 # literals
 if w&0x3b000000==0x18000000:
  return f'ldr-lit opc{w>>30&3} {reg(rd,sf)}, {a+sx((w>>5)&0x7ffff,19)*4:#x}'
 return f'.word {w:#010x}'
lines=[];unknown=[]
for a in range(lo,hi,4):
 w=struct.unpack_from('<I',b,a)[0]; s=dec(w,a); lines.append(f'{a:04x}: {w:08x}  {s}')
 if s.startswith('.word'):unknown.append((a,w))
open('disasm.txt','w').write('\n'.join(lines))
print('lines',len(lines),'unknown',len(unknown))
from collections import Counter
for k,v in Counter(w&0xffe00000 for _,w in unknown).most_common():print(hex(k),v)
print('\n'.join(lines[:100]))