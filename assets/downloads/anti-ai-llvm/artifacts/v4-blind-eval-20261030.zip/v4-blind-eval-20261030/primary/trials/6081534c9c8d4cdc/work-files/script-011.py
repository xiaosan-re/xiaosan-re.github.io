import ctypes.util,glob
print('libs',ctypes.util.find_library('capstone'),ctypes.util.find_library('LLVM'))
print('unicorn ok')
from unicorn import *
from unicorn.arm64_const import *
print(UC_VERSION_MAJOR)