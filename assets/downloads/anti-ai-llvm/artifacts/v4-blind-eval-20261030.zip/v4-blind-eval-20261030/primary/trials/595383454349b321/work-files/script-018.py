import runpy,struct
ns=runpy.run_path('script-015.py'); dec=ns['dec'];D=open('target.so','rb').read()
for a in range(0x456c,0x62d4,4):
 w=struct.unpack_from('<I',D,a)[0]; s=dec(a,w)
 if s.startswith('.word'):print(hex(a),hex(w))