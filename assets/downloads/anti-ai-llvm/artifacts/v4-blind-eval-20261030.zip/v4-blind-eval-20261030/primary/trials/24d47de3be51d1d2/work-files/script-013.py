mods=['capstone','elftools','lief']
for m in mods:
 try:
  x=__import__(m); print(m,'ok')
 except Exception as e: print(m,'no',type(e).__name__)
