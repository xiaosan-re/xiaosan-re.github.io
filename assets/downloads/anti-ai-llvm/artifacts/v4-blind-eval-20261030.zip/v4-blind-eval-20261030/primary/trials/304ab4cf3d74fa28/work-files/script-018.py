for m in ['llvmlite','llvmlite.binding','clang','qiling']:
 try:
  x=__import__(m); print(m,'YES',getattr(x,'__version__',''))
 except Exception as e: print(m,'no')