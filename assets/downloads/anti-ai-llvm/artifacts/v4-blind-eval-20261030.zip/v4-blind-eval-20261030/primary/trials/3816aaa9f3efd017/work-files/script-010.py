import unicorn
print(unicorn.__version__)
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM
from unicorn.arm64_const import *
print('ok',UC_ARM64_REG_X0)