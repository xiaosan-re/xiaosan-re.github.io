from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
B=0x100000;S=0x200000;E=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x['p_vaddr'],x.data()) for x in e.iter_segments() if x['p_type']=='PT_LOAD']
def H(a):
 x=(a^0x9b05606f)&0xffffffff;x=((x^(x>>16))*0x7feb352d)&0xffffffff;x=((x^(x>>15))*0x846ca68b)&0xffffffff;return (x^(x>>16))&0xffffffff
def run(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000)
 for v,d in segs:u.mem_write(B+v,d)
 u.mem_write(B+0x4f9c,b'\x00\x00\x80\x52\xc0\x03\x5f\xd6');u.mem_map(S,0x10000);u.mem_map(E,0x1000);u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 path=[]
 def hook(uc,ad,sz,x):
  o=ad-B
  if o in (0x3be8,0x3c5c,0x3cb0,0x3d00,0x3d5c,0x3dac,0x3de8,0x3e24,0x3e44,0x3e64,0x3e94,0x3eb0,0x3ecc,0x3ef8,0x3f04,0x3f38,0x3f50):path.append(o)
 u.hook_add(UC_HOOK_CODE,hook);u.emu_start(B+0x38cc,E,count=100000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff,path
for a in [0,1,2,10,47,100,0xffffffff,123456789]:
 for b in [1,2,99,0xfffffffe]:
  for c in [0,1,2]:
   o,p=run((a,b,c,H(a)));print((a,b,c,hex(H(a))),hex(o),[hex(x) for x in p])