def ror(x,r,n): return ((x>>r)|(x<<(n-r)))&((1<<n)-1)
def limm(w):
 sf=(w>>31)&1; N=(w>>22)&1; immr=(w>>16)&63; imms=(w>>10)&63
 width=64 if sf else 32
 x=(N<<6)|((~imms)&63)
 length=x.bit_length()-1
 levels=(1<<length)-1
 S=imms&levels; R=immr&levels; esize=1<<length
 elem=(1<<(S+1))-1; elem=ror(elem,R,esize)
 val=0
 for i in range(0,width,esize):val|=elem<<i
 return sf,N,immr,imms,esize,val
for w in [0x12000b39,0x320107e0,0x32010be0]: print(hex(w),limm(w))