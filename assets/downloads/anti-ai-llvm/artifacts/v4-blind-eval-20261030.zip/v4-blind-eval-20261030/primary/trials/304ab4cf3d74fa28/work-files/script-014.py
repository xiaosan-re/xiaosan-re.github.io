from pathlib import Path
import struct
b=Path('target.so').read_bytes(); base=0x38cc; data=b[base:base+1704]
for off in range(0,len(data),4):
 w=struct.unpack_from('<I',data,off)[0]; pc=base+off
 if w>>26 in (0b100101,0b000101):
  imm=w&0x3ffffff
  if imm&(1<<25): imm-=1<<26
  print(hex(pc), 'BL' if w>>26==0b100101 else 'B', hex(pc+imm*4), hex(w))
 # conditional branch including cbz/tbz perhaps
