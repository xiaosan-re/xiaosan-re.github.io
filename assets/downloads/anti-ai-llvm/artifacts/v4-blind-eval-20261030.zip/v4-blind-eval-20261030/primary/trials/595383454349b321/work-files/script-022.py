D=open('target.so','rb').read();
for a in [0x2d0,0x451c]:print(hex(a),D[a:a+256].hex())