from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE,UC_HOOK_INTR
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
import struct
BASE=0x100000; STACK=0x200000; SENT=0x300000
with open('target.so','rb') as f:
 e=ELFFile(f); segs=[]
 for s in e.iter_segments():
  if s['p_type']=='PT_LOAD': segs.append((s['p_vaddr'],s.data(),s['p_memsz']))
def run(args,trace=False):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
 u.mem_map(BASE,0x10000)
 for va,data,ms in segs: u.mem_write(BASE+va,data)
 u.mem_map(STACK,0x10000); u.mem_map(SENT,0x1000)
 u.reg_write(UC_ARM64_REG_SP,STACK+0x8000)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),args):u.reg_write(r,v)
 u.reg_write(UC_ARM64_REG_X30,SENT)
 count=0; pcs=[]
 def hook(uc,addr,size,user):
  nonlocal count
  count+=1
  off=addr-BASE
  if trace and (len(pcs)<2000): pcs.append(off)
  if off==0x4f94:
   uc.reg_write(UC_ARM64_REG_X0,0); uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_X30))
  if addr==SENT: uc.emu_stop()
 def intr(uc,n,user):
  print('intr',n,hex(uc.reg_read(UC_ARM64_REG_PC)-BASE)); uc.reg_write(UC_ARM64_REG_X0,0xffffffffffffffff)
 u.hook_add(UC_HOOK_CODE,hook);u.hook_add(UC_HOOK_INTR,intr)
 try:u.emu_start(BASE+0x38cc,SENT,count=1000000)
 except Exception as ex: print('ERR',args,ex,'pc',hex(u.reg_read(UC_ARM64_REG_PC)-BASE))
 return u.reg_read(UC_ARM64_REG_X0)&0xffffffff,count,pcs
for a in [(0,0,0,0),(1,2,3,4),(100,1,0,17),(100,2,500,17),(149,9300,17,0),(0xffffffff,0xffffffff,0xffffffff,0xffffffff)]:
 print(a,run(a)[:2])
r,c,p=run((1,2,3,4),True); print('trace uniq',r,c,len(set(p)),[hex(x) for x in sorted(set(p))])