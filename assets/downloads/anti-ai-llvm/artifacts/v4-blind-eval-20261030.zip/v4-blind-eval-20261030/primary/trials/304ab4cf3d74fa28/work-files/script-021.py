import ctypes.util
for n in ['LLVM','LLVM-18','LLVM-17','LLVM-16','LLVM-15','LLVM-14']:
 print(n,ctypes.util.find_library(n))