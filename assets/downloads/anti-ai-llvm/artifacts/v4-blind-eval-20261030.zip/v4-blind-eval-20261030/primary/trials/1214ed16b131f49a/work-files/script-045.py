# Fast derive expected valid outputs by pure hash d and Unicorn for all quantities.
from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
B=0x100000;S=0x200000;E=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x['p_vaddr'],x.data()) for x in e.iter_segments() if x['p_type']=='PT_LOAD']
def H(a):
 x=(a^0x9b05606f)&0xffffffff;x=((x^(x>>16))*0x7feb352d)&0xffffffff;x=((x^(x>>15))*0x846ca68b)&0xffffffff;return (x^(x>>16))&0xffffffff
def run(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000)
 for v,d in segs:u.mem_write(B+v,d)
 u.mem_write(B+0x4f9c,b'\x00\x00\x80\x52\xc0\x03\x5f\xd6');u.mem_map(S,0x10000);u.mem_map(E,0x1000);u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 u.emu_start(B+0x38cc,E,count=100000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
for b in range(1,101):
 o=run((0,b,0,H(0))); raw=129*b
 flag='D' if o!=raw else '-'
 print(b,o,flag,end='; ')
 if b%10==0:print()
print('a flags at b=1')
for a in range(64):
 o=run((a,1,0,H(a)));print(a,o,'D' if o!=129 else '-',end='; ')
 if a%8==7:print()