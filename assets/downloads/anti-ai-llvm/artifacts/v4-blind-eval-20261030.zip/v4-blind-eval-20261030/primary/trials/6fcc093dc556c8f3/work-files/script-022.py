import struct
D=open('target.so','rb').read()
for a in range(0x34c,0x4cc,4):
 x=struct.unpack_from('<I',D,a)[0]; s=''
 if x&0x7f800000 in (0x52800000,0x72800000):
  typ='movz' if x&0x7f800000==0x52800000 else 'movk'; rd=x&31;imm=(x>>5)&0xffff;sh=((x>>21)&3)*16;s=f'{typ} w{rd}, #{imm:#x}, lsl #{sh}'
 elif x&0x7fe0fc00==0x1b007c00:
  s=f'mul w{x&31}, w{(x>>5)&31}, w{(x>>16)&31}'
 elif x&0x7f200000==0x0b000000:
  op='sub' if x&(1<<30) else 'add';s=f'{op} shifted regs rd{x&31} rn{(x>>5)&31} rm{(x>>16)&31} sh{(x>>22)&3} amt{(x>>10)&0x3f}'
 elif x&0x7f200000==0x4a000000:
  s=f'eor w{x&31},w{(x>>5)&31},w{(x>>16)&31},shift{(x>>22)&3}#{(x>>10)&0x3f}'
 print(f'{a:04x} {x:08x} {s}')