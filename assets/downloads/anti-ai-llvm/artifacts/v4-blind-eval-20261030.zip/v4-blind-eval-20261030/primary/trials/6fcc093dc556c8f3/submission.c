#include <stdint.h>

static uint32_t avalanche(uint32_t x)
{
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

uint32_t recovered(uint32_t account, uint32_t quantity,
                   uint32_t tier, uint32_t check)
{
    uint32_t expected;
    uint32_t total;

    if (quantity < 1 || quantity > 100)
        return UINT32_C(0x80000001);

    if (tier > 2)
        return UINT32_C(0x80000002);

    expected = avalanche(account ^ UINT32_C(0x838d31dc));
    if (check != expected)
        return UINT32_C(0x80000003);

    if (tier == 0)
        total = quantity * 129;
    else if (tier == 1)
        total = quantity * 249;
    else
        total = quantity * 399;

    if (quantity >= 10)
        total = total * 85 / 100;

    if ((avalanche(account + UINT32_C(0x4c55a6ee)) & 7) == 3)
        total = total * 95 / 100;

    return total;
}
