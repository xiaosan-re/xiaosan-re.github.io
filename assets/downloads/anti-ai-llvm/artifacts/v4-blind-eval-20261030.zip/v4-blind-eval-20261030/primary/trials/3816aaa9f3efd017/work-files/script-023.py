# compact emulator tests likely policy fields
from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
import struct
B=0x1000000;S=0x2000000;T=0x3000000
with open('target.so','rb') as f:raw=f.read();f.seek(0);e=ELFFile(f);ps=[p for p in e.iter_segments() if p['p_type']=='PT_LOAD']
def R(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0xe000);u.mem_map(S,0x10000);u.mem_map(T,0x1000)
 for p in ps:u.mem_write(B+p['p_vaddr'],raw[p['p_offset']:p['p_offset']+p['p_filesz']])
 u.mem_write(B+0xd410,struct.pack('<II',1,0));u.reg_write(UC_ARM64_REG_SP,S+0xf000);u.reg_write(UC_ARM64_REG_LR,T)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 u.emu_start(B+0x38cc,T,count=5000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
for x in [17,48,64,93,100,149,279,409,9300,10000]:
 for z in [17,64,149,279,409,9300,10000]:
  v=R((x,1,0,z))
  if v!=0x80000003:print((x,1,0,z),hex(v))
print('exact combos')
for tier,base in enumerate([149,279,409]):
 for q in [1,100]:print((base,q,tier,9300),hex(R((base,q,tier,9300))))