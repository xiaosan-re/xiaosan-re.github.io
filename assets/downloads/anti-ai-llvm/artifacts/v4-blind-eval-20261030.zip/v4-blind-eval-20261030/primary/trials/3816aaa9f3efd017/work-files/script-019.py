from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
import struct
BASE=0x1000000; STACK=0x2000000; STOP=0x3000000
with open('target.so','rb') as f:
 raw=f.read();f.seek(0);e=ELFFile(f);segs=[p for p in e.iter_segments() if p['p_type']=='PT_LOAD']
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0xe000);u.mem_map(STACK,0x10000);u.mem_map(STOP,0x1000)
for p in segs:u.mem_write(BASE+p['p_vaddr'],raw[p['p_offset']:p['p_offset']+p['p_filesz']])
u.reg_write(UC_ARM64_REG_SP,STACK+0xf000);u.reg_write(UC_ARM64_REG_LR,STOP)
regs=list(range(UC_ARM64_REG_X0,UC_ARM64_REG_X28+1))+[UC_ARM64_REG_X29,UC_ARM64_REG_X30,UC_ARM64_REG_SP,UC_ARM64_REG_NZCV]
for r,v in zip(regs[:4],(1,2,3,4)):u.reg_write(r,v)
prev=[u.reg_read(r) for r in regs]
def code(uc,a,s,d):
 global prev
 off=a-BASE
 if 0x38cc<=off<0x3f74:
  now=[uc.reg_read(r) for r in regs]; ch=[]
  for j,(x,y) in enumerate(zip(prev,now)):
   if x!=y: ch.append(('x'+str(j) if j<31 else ('sp' if j==31 else 'F'))+'='+hex(y))
  w=struct.unpack('<I',uc.mem_read(a,4))[0]
  print(f'{off:04x} {w:08x}', ' '.join(ch))
  prev=now
def intr(uc,n,d): uc.reg_write(UC_ARM64_REG_X0,0xffffffffffffffff)
u.hook_add(UC_HOOK_CODE,code);u.hook_add(UC_HOOK_INTR,intr)
u.emu_start(BASE+0x38cc,STOP,count=100000)
print('ret',hex(u.reg_read(UC_ARM64_REG_X0)))