from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
import struct,time
BASE=0x1000000;STACK=0x2000000;STOP=0x3000000
with open('target.so','rb') as f: raw=f.read();f.seek(0);e=ELFFile(f);segs=[p for p in e.iter_segments() if p['p_type']=='PT_LOAD']
def run(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0xe000);u.mem_map(STACK,0x10000);u.mem_map(STOP,0x1000)
 for p in segs:u.mem_write(BASE+p['p_vaddr'],raw[p['p_offset']:p['p_offset']+p['p_filesz']])
 u.mem_write(BASE+0xd410,struct.pack('<II',1,0));u.reg_write(UC_ARM64_REG_SP,STACK+0xf000);u.reg_write(UC_ARM64_REG_LR,STOP)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 u.emu_start(BASE+0x38cc,STOP,count=10000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
cases=[]
for i in [0,1,2,3,6,7,10,47,48,49]:
 for q in [0,1,2,99,100,101]:cases.append((i,q,i%7,i+17))
for a in cases:print(a,hex(run(a)))