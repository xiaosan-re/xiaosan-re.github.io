import struct
b=open('target.so','rb').read(); u=lambda a:struct.unpack_from('<I',b,a)[0]
def mc(a):
 w=u(a);v=((w>>5)&65535)<<(((w>>21)&3)*16);w2=u(a+4);v=(v&~(0xffff<<(((w2>>21)&3)*16)))|(((w2>>5)&65535)<<(((w2>>21)&3)*16));return v&0xffffffff
D={}
for a in list(range(0x5310,0x5500,0x14))+list(range(0x5878,0x5a30,0x14)):
 c=mc(a);wb=u(a+12);im=(wb>>5)&0x7ffff;im-= (1<<19) if im>>18 else 0;D[c]=a+12+im*4
T={}
for h in set(D.values()):
 for a in range(h,min(h+0x180,0x62a0),4):
  if (u(a)&0x7f80001f)==0x5280000c and u(a+8)==0x4a0c0129 and u(a+12)==0xb9000089:T[h]=mc(a);break
  if u(a)&0x7c000000==0x14000000:break
T[0x5a34]=0x01d18f6c
def fm(x):
 x&=0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x
for q in range(48):
 c0=u(0x2d0+q*36)^fm((q*0x9e3779b9&0xffffffff)^0x6ce1a125)
 storage=0xe4a7252e;d=c0;chain=[]
 for z in range(20):
  h=D.get(d);chain.append(h)
  if h in (None,0x606c,0x5508):break
  storage^=T[h];d=storage
  if h==0x5a34:break
 print(q,hex(c0), ' '.join('?' if h is None else hex(h) for h in chain))