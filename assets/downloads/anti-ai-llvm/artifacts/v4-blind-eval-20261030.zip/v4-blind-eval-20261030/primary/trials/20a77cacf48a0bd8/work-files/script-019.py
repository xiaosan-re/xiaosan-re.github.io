from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
import random,collections
with open('target.so','rb') as f:
 e=ELFFile(f);seg=[(p['p_vaddr'],p['p_memsz'],p.data()) for p in e.iter_segments() if p['p_type']=='PT_LOAD']
def run(q):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
 for a,m,b in seg:
  try:u.mem_map(a&~4095,((a+m+4095)&~4095)-(a&~4095))
  except:pass
  u.mem_write(a,b)
 u.mem_map(0x100000,4096);u.mem_map(0x200000,0x20000);u.reg_write(UC_ARM64_REG_SP,0x21fff0);u.reg_write(UC_ARM64_REG_LR,0x100000)
 for r,v in zip([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3],q):u.reg_write(r,v)
 def h(uc,a,s,d):
  if a==0x45ac:uc.reg_write(UC_ARM64_REG_X0,0);uc.reg_write(UC_ARM64_REG_PC,0x45b0)
  if a==0x100000:uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x100004,count=1000000)
 return u.reg_read(UC_ARM64_REG_W0)
tests=[]
# random full, bounded, constants neighborhoods
for bits in [4,8,12,16,24,32]:
 for _ in range(60):tests.append(tuple(random.getrandbits(bits) for _ in range(4)))
C=[0,1,17,18,48,64,93,100,149,279,409,9300,10000,0xffffffff]
for _ in range(200):tests.append(tuple(random.choice(C) for _ in range(4)))
out=collections.defaultdict(list)
for q in tests:
 r=run(q)
 if len(out[r])<8:out[r].append(q)
print('distinct',len(out))
for r,qs in out.items():print(hex(r),qs)