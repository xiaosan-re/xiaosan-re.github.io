import ctypes,ctypes.util
b=open('target.so','rb').read()
lib=ctypes.CDLL(ctypes.util.find_library('capstone'))
class Insn(ctypes.Structure):
 _fields_=[('id',ctypes.c_uint),('address',ctypes.c_uint64),('size',ctypes.c_uint16),('bytes',ctypes.c_ubyte*24),('mnemonic',ctypes.c_char*32),('op_str',ctypes.c_char*160),('detail',ctypes.c_void_p)]
h=ctypes.c_size_t(); print('open',lib.cs_open(1,0,ctypes.byref(h)),h.value)
arr=ctypes.POINTER(Insn)(); buf=(ctypes.c_ubyte*1140).from_buffer_copy(b[0x32c:0x32c+1140])
n=lib.cs_disasm(h,buf,1140,0x32c,0,ctypes.byref(arr)); print('n',n)
for i in range(n):
 x=arr[i]; print(f'{x.address:04x}: {x.mnemonic.decode():8} {x.op_str.decode()}')
lib.cs_free(arr,n);lib.cs_close(ctypes.byref(h))