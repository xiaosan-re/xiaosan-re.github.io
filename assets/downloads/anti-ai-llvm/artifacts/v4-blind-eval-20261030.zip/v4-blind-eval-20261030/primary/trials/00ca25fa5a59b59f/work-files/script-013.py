from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f)
 print('entry',hex(e.header.e_entry))
 for s in e.iter_segments(): print(s.header.p_type,hex(s.header.p_offset),hex(s.header.p_vaddr),hex(s.header.p_filesz),hex(s.header.p_flags))
 for sec in e.iter_sections():
  if sec.name in ('.text','.rodata','.data','.dynsym'): print(sec.name,hex(sec.header.sh_offset),hex(sec.header.sh_addr),hex(sec.header.sh_size))
