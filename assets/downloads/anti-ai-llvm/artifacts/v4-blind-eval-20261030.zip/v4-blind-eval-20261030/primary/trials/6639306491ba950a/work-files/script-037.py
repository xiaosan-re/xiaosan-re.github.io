M=0x51eb851f
for n in range(0,39901*95+1):
 q=(n*M)>>37
 if q!=n//100:
  print('mismatch',n,q,n//100);break
else: print('magic division matches /100 over complete reachable range')
# Show key state transitions as an independent constant check.
checks=[
 (0xe4a7252e,0x9e0a27a6,0x7aad0288),
 (0xe4a7252e,0x01d18f6c,0xe576aa42),
 (0x7aad0288,0x37e1bbac,0x4d4cb924),
 (0x7aad0288,0x5cb903f1,0x26140179),
 (0x4d4cb924,0x4ff9b1f4,0x02b508d0),
 (0x4d4cb924,0x8efea79d,0xc3b21eb9)]
print(all((a^b)==c for a,b,c in checks),[(hex(a^b),hex(c)) for a,b,c in checks])