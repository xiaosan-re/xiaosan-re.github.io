from unicorn import *
from unicorn.arm64_const import *
import struct
blob=open('target.so','rb').read()
def expected(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
 for i,x in enumerate((a,1,0,0)):u.reg_write(UC_ARM64_REG_X0+i,x)
 u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000);it=[-1]; ans=[None]
 def h(u,x,s,z):
  if x==0x6e74:u.reg_write(UC_ARM64_REG_X0,0);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
  if x==0x530c:
   it[0]+=1
   if it[0]==116:
    sp=u.reg_read(UC_ARM64_REG_SP);w=struct.unpack('<56I',u.mem_read(sp,224));ans[0]=w[0x90//4];u.emu_stop()
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=100000);return ans[0]
def f(a):
 x=(a+0x838d31dc)&0xffffffff;x^=x>>16;x=(x*0x7feb352d)&0xffffffff;x^=x>>15;x=(x*0x846ca68b)&0xffffffff;x^=x>>16;return x
for a in [0,1,2,3,100,0x1234,0x12345678,0x7fffffff,0x80000000,0xffffffff]:print(hex(a),hex(expected(a)),hex(f(a)))