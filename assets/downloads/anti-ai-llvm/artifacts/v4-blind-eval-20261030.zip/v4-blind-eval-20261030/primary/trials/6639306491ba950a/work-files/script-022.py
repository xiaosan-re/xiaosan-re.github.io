u=lambda x:x&0xffffffff
vals={
'w14':0xbb686f72^0x7ae645a4,
'w13':0xbb686f72^0x40991e6f,
'w4_const':0xf73f4402,
'w0_const':0xef740d99,
}
vals['state']=u(vals['w14']+0x2318fa58)
vals['w16_alt']=u(vals['w13']+0x2318fa58)
print({k:hex(v) for k,v in vals.items()})
# dispatcher constants
for x in [0xf2f756ae,0xe4a7252d,0xc3b21eb8,0x8d141411,0xc3b21eb9,0xe8352f76,0xe4a7252e,0xe8352f77,0x51eb851f,0x26140178,0x101b3928,0xf2f756af,0x101b3929,0x4d4cb923,0x4d4cb924]:
 print(hex(x), x if x<2**31 else x-2**32)