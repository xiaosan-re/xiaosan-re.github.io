import ctypes,ctypes.util
lib=ctypes.CDLL(ctypes.util.find_library('capstone'))
class Insn(ctypes.Structure):
 _fields_=[('id',ctypes.c_uint),('address',ctypes.c_uint64),('size',ctypes.c_uint16),('bytes',ctypes.c_ubyte*24),('mnemonic',ctypes.c_char*32),('op_str',ctypes.c_char*160),('detail',ctypes.c_void_p)]
lib.cs_open.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.POINTER(ctypes.c_size_t)];lib.cs_open.restype=ctypes.c_int
lib.cs_disasm.argtypes=[ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint64,ctypes.c_size_t,ctypes.POINTER(ctypes.POINTER(Insn))];lib.cs_disasm.restype=ctypes.c_size_t
h=ctypes.c_size_t();print('open',lib.cs_open(1,0,ctypes.byref(h)),h.value)
b=open('target.so','rb').read()[0x456c:0x62d4];buf=ctypes.create_string_buffer(b);out=ctypes.POINTER(Insn)();n=lib.cs_disasm(h,buf,len(b),0x456c,0,ctypes.byref(out));print('n',n)
for i in range(min(n,500)):
 x=out[i];print(f'{x.address:06x}: {x.mnemonic.decode():8} {x.op_str.decode()}')
lib.cs_free(out,n);lib.cs_close(ctypes.byref(h))
