import struct
b=open('target.so','rb').read()
# raw word dump per known op block until terminal branch (or ret)
targs=[0x5b0c,0x6090,0x60a8,0x60c0,0x60f0,0x6108,0x6120,0x6168,0x6198,0x61f8,0x6210,0x6258,0x6270,0x6288]
for st in targs:
 print('\n',hex(st))
 for a in range(st,min(st+0x40,0x62a0),4):
  w=struct.unpack_from('<I',b,a)[0]; print(f'{a:04x} {w:08x}')
  if w>>26==5 or w==0xd65f03c0: break