from pathlib import Path
p=Path('target.so')
b=p.read_bytes()
print(len(b), b[:16].hex())
# print ELF64 program and section headers minimally
import struct
assert b[:4]==b'\x7fELF'
e_phoff,e_shoff=struct.unpack_from('<QQ',b,32)
e_phentsize,e_phnum,e_shentsize,e_shnum,e_shstrndx=struct.unpack_from('<HHHHH',b,54)
print('ph',hex(e_phoff),e_phentsize,e_phnum,'sh',hex(e_shoff),e_shentsize,e_shnum,e_shstrndx)
for i in range(e_phnum):
 o=e_phoff+i*e_phentsize
 typ,flags,off,va,pa,fs,ms,al=struct.unpack_from('<IIQQQQQQ',b,o)
 print('PH',i,typ,flags,hex(off),hex(va),hex(fs),hex(ms))
# bytes at virtual address 38cc using PT_LOAD mapping
for i in range(e_phnum):
 o=e_phoff+i*e_phentsize; typ,flags,off,va,pa,fs,ms,al=struct.unpack_from('<IIQQQQQQ',b,o)
 if typ==1 and va<=0x38cc<va+fs:
  fo=off+0x38cc-va
  print('mapping',hex(fo),'bytes',b[fo:fo+1704].hex())