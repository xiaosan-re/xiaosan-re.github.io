from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
import struct,time
B=0x1000000;S=0x2000000;STOP=0x3000000
with open('target.so','rb') as f: raw=f.read();f.seek(0);e=ELFFile(f);segs=[p for p in e.iter_segments() if p['p_type']=='PT_LOAD']
def run(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0xe000);u.mem_map(S,0x10000);u.mem_map(STOP,0x1000)
 for p in segs:u.mem_write(B+p['p_vaddr'],raw[p['p_offset']:p['p_offset']+p['p_filesz']])
 u.mem_write(B+0xd410,struct.pack('<II',1,0));u.reg_write(UC_ARM64_REG_SP,S+0xf000);u.reg_write(UC_ARM64_REG_LR,STOP)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 u.emu_start(B+0x38cc,STOP,count=5000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
st=time.time();found=[];counts={}
for x in range(101):
 for z in range(101):
  v=run((x,1,0,z));counts[v]=counts.get(v,0)+1
  if v<0x80000000:found.append((x,z,v))
print('time',time.time()-st,'found',len(found),found[:100]);print('errors',{hex(k):v for k,v in counts.items() if k>=0x80000000})