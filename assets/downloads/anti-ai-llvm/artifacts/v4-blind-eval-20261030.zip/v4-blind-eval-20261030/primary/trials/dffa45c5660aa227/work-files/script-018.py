import struct
b=open('target.so','rb').read(); E=struct.unpack_from('<16sHHIQQQIHHHHHH',b,0); shoff,shentsz,shnum,shstr=E[6],E[11],E[12],E[13]
sh=[]
for i in range(shnum): sh.append(struct.unpack_from('<IIQQQQIIQQ',b,shoff+i*shentsz))
ss=sh[shstr]; names=b[ss[4]:ss[4]+ss[5]]
def cstr(data,o): return data[o:data.find(b'\0',o)].decode('utf8','replace')
for i,s in enumerate(sh): print(i,cstr(names,s[0]),'type',s[1],'flags',hex(s[2]),'addr',hex(s[3]),'off',hex(s[4]),'size',hex(s[5]),'link',s[6],'entsz',s[9])
for i,s in enumerate(sh):
 if s[1] in (2,11):
  st=sh[s[6]]; strs=b[st[4]:st[4]+st[5]]
  print('SYMS',cstr(names,s[0]))
  for o in range(s[4],s[4]+s[5],s[9]):
   n,info,other,idx,val,size=struct.unpack_from('<IBBHQQ',b,o)
   print(hex(val),size,info,idx,cstr(strs,n))