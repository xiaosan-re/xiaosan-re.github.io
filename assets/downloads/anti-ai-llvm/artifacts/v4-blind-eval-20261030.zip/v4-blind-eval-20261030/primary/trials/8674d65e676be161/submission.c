#include <stdint.h>

static uint32_t mix32(uint32_t x)
{
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

uint32_t recovered(uint32_t a, uint32_t b, uint32_t c, uint32_t d)
{
    uint32_t value;

    if (b < 1 || b > 100)
        return UINT32_C(0x80000001);
    if (c > 2)
        return UINT32_C(0x80000002);
    if (d != mix32(a ^ UINT32_C(0x9b05606f)))
        return UINT32_C(0x80000003);

    if (c == 0)
        value = 129 * b;
    else if (c == 1)
        value = 249 * b;
    else
        value = 399 * b;

    if (b > 9)
        value = (value * 85) / 100;

    if ((mix32(a + UINT32_C(0x7188bda9)) & 7) == 3)
        value = (value * 95) / 100;

    return value;
}
