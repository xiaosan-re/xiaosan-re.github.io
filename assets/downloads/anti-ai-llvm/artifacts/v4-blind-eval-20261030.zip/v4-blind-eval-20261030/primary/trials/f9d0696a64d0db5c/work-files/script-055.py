def mix(a,s):
 x=a^s;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x
for a in [1,63,0x15c1d2df,0xc36b472c]:print(hex(a),hex(mix(a,0x4c55a6ee)),mix(a,0x4c55a6ee)%7)