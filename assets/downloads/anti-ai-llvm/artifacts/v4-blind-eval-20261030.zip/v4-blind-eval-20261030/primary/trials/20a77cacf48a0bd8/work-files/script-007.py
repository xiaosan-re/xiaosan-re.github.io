from elftools.elf.elffile import ELFFile
P='target.so'
with open(P,'rb') as f:
 e=ELFFile(f)
 print('machine',e['e_machine'],'entry',hex(e['e_entry']))
 for s in e.iter_sections(): print(s.name,hex(s['sh_addr']),hex(s['sh_offset']),hex(s['sh_size']),s['sh_flags'])
 sym=e.get_section_by_name('.dynsym')
 for x in sym.iter_symbols():
  if x.name: print('SYM',x.name,hex(x['st_value']),x['st_size'],x['st_info']['type'])
 text=e.get_section_by_name('.text'); data=text.data(); base=text['sh_addr']; off=0x456c-base
 print('entrybytes',data[off:off+1024].hex())