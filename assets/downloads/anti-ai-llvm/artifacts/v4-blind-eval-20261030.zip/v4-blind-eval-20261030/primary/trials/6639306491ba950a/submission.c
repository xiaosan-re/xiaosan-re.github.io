#include <stdint.h>

static uint32_t mix_expected(uint32_t x)
{
    x ^= UINT32_C(0x87f7daef);
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

static uint32_t mix_bucket(uint32_t x)
{
    x += UINT32_C(0x7f70ea69);
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x & 7u;
}

uint32_t recovered(uint32_t a, uint32_t b, uint32_t c, uint32_t d)
{
    static const uint32_t multiplier[3] = { 129u, 249u, 399u };
    uint32_t score;

    if (b < 1u || b > 100u)
        return UINT32_C(0x80000001);
    if (c > 2u)
        return UINT32_C(0x80000002);
    if (d != mix_expected(a))
        return UINT32_C(0x80000003);

    score = multiplier[c] * b;
    if (b > 9u)
        score = (score * 85u) / 100u;
    if (mix_bucket(a) == 3u)
        score = (score * 95u) / 100u;
    return score;
}
