from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
import struct,random
with open('target.so','rb') as f:
 blob=f.read(); f.seek(0); e=ELFFile(f); segs=[dict(x.header) for x in e.iter_segments() if x['p_type']=='PT_LOAD']
def run(args,trace=False):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
 u.mem_map(0,0x10000)
 u.mem_write(0,blob)
 u.mem_map(0x100000,0x10000)
 u.reg_write(UC_ARM64_REG_SP,0x108000)
 u.reg_write(UC_ARM64_REG_X30,0x9000)
 for i,a in enumerate(args):u.reg_write([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3][i],a)
 if trace:
  def h(uc,addr,size,user): print(hex(addr),*[hex(uc.reg_read(r)) for r in [UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3,UC_ARM64_REG_X8,UC_ARM64_REG_X9,UC_ARM64_REG_X10,UC_ARM64_REG_X11]])
  u.hook_add(UC_HOOK_CODE,h)
 try:u.emu_start(0x32c,0x9000,count=100000)
 except UcError as ex: print('ERR',ex,hex(u.reg_read(UC_ARM64_REG_PC))); raise
 return u.reg_read(UC_ARM64_REG_W0)
vals=[(0,0,0,0),(1,2,3,4),(0xffffffff,0xffffffff,0xffffffff,0xffffffff),(1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1),(100,200,300,400)]
for x in vals:print(x,hex(run(x)))
print('random')
for _ in range(20):
 x=tuple(random.randrange(0x100000000) for _ in range(4)); print(*(hex(y) for y in x),hex(run(x)))