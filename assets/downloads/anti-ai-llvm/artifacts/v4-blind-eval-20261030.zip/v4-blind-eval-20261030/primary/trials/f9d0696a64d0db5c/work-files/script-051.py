from unicorn import *
from unicorn.arm64_const import *
import struct
blob=open('target.so','rb').read()
def tag(a):
 x=a^0x838d31dc;x^=x>>16;x=(x*0x7feb352d)&0xffffffff;x^=x>>15;x=(x*0x846ca68b)&0xffffffff;x^=x>>16;return x
def trace(a,b=1,c=0):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
 for i,x in enumerate((a,b,c,tag(a))):u.reg_write(UC_ARM64_REG_X0+i,x)
 u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000);it=[-1]; rec=[]
 def h(u,x,s,z):
  if x==0x6e74:u.reg_write(UC_ARM64_REG_X0,0);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
  if x==0x530c:
   it[0]+=1
   if it[0]>=113:
    sp=u.reg_read(UC_ARM64_REG_SP);w=struct.unpack('<56I',u.mem_read(sp,224));rec.append([it[0],w,None])
  elif it[0]>=113 and rec and rec[-1][2] is None and not (0x530c<=x<=0x59b0):rec[-1][2]=x
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=100000)
 print('a,b,c',hex(a),b,c,'tag',hex(tag(a)),'ret',hex(u.reg_read(UC_ARM64_REG_W0)),'iters',it[0]+1)
 for n,w,p in rec:print(n,hex(p or 0),f'pc={w[24]:x} t={w[4]:x} r0={w[32]:x} r1={w[36]:x} r2={w[40]:x} imm={w[12]:x},{w[16]:x}')
trace(1);trace(63)