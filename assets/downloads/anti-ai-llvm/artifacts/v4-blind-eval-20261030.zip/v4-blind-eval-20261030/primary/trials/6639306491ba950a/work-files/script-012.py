import struct
b=open('target.so','rb').read()
# ELF64 header
h=struct.unpack_from('<16sHHIQQQIHHHHHH',b,0)
print('type machine entry phoff shoff flags eh phents phnum shents shnum shstr',h[1:])
phoff=h[5]; ents=h[9]; n=h[10]
for i in range(n):
 print('PH',i,struct.unpack_from('<IIQQQQQQ',b,phoff+i*ents))
shoff=h[6]; se=h[11]; sn=h[12]; ss=h[13]
S=[struct.unpack_from('<IIQQQQIIQQ',b,shoff+i*se) for i in range(sn)]
shstr=b[S[ss][4]:S[ss][4]+S[ss][5]]
for i,s in enumerate(S):
 name=shstr[s[0]:].split(b'\0')[0].decode(errors='replace')
 print(i,name, 'type',s[1],'flags',hex(s[2]),'addr',hex(s[3]),'off',hex(s[4]),'size',hex(s[5]),'link',s[6],'info',s[7])