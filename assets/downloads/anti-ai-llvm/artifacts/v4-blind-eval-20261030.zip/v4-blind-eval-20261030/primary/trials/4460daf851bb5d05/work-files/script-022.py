w=0x10fd6d31;a=0x552c
immlo=(w>>29)&3;immhi=(w>>5)&0x7ffff;imm=(immhi<<2)|immlo
if imm>>20:imm-=1<<21
print(hex(imm),hex(a+imm))
# decode unknown reg-offset load fields
import struct
b=open('target.so','rb').read()
for a in range(0x456c,0x62d4,4):
 w=struct.unpack_from('<I',b,a)[0]
 if w&0x3b200c00==0x38200800:
  print(hex(a),hex(w),'size',w>>30,'opc',w>>22&3,'rm',w>>16&31,'opt',w>>13&7,'S',w>>12&1,'rn',w>>5&31,'rt',w&31)
print('table bytes',b[0x22d0:0x2544].hex())