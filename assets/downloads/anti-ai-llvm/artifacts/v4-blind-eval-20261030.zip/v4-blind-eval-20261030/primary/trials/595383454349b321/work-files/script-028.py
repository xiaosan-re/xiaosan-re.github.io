import struct,collections
D=open('target.so','rb').read()
def mask(w):
 sf=w>>31; M=64 if sf else 32; N=(w>>22)&1; immr=(w>>16)&63; imms=(w>>10)&63
 q=(N<<6)|((~imms)&63); ln=q.bit_length()-1; levels=(1<<ln)-1; S=imms&levels;R=immr&levels;esize=1<<ln
 elem=(1<<(S+1))-1; R%=esize; elem=((elem>>R)|(elem<<(esize-R)))&((1<<esize)-1)
 out=0
 for i in range(0,M,esize):out|=elem<<i
 return out
for a in range(0x456c,0x62d4,4):
 w=struct.unpack_from('<I',D,a)[0]
 if w&0x1f800000==0x12000000:print(hex(a),hex(w),hex(mask(w)))