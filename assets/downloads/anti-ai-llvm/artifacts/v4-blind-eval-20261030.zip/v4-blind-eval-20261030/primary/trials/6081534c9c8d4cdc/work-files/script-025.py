from unicorn import *
from unicorn.arm64_const import *
blob=open('target.so','rb').read()
def run(a,b,c,d):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.reg_write(UC_ARM64_REG_SP,0x110000);u.reg_write(UC_ARM64_REG_X30,0x8000)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),(a,b,c,d)):u.reg_write(r,v)
 def hk(uc,x,s,z):
  if x==0x4f9c:uc.reg_write(UC_ARM64_REG_W0,0);uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_X30))
  elif x==0x8000:uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,hk);u.emu_start(0x38cc,0x8004,count=100000)
 return u.reg_read(UC_ARM64_REG_W0)
vals=list(range(0,21))+[31,32,63,64,99,100,101,127,128,129,255,256,999,0x7fffffff,0x80000000,0xffffffff]
for pos in range(4):
 groups={}
 for v in vals:
  x=[0,0,0,0];x[pos]=v;r=run(*x);groups.setdefault(r,[]).append(v)
 print('ARG',pos)
 for r,vs in groups.items():print(hex(r),[hex(v) for v in vs])
print('grid b,c')
for b in range(0,8):print(b,[hex(run(0,b,c,0)) for c in range(0,8)])