from unicorn import *
from unicorn.arm64_const import *
blob=open('target.so','rb').read();states=[]
def run(c):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.reg_write(UC_ARM64_REG_SP,0x110000);u.reg_write(UC_ARM64_REG_X30,0x8000)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),(0,1,c,0)):u.reg_write(r,v)
 t=[]
 def h(q,p,s,z):
  if p==0x4f9c:q.reg_write(UC_ARM64_REG_W0,0);q.reg_write(UC_ARM64_REG_PC,q.reg_read(UC_ARM64_REG_X30))
  elif p==0x3c1c:t.append(q.reg_read(UC_ARM64_REG_W28))
  elif p==0x8000:q.emu_stop()
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x38cc,0x8004,count=100000);return u.reg_read(UC_ARM64_REG_W0),t
for c in list(range(10))+[0xffffffff]:print(c,hex(run(c)[0]),[hex(x) for x in run(c)[1]])