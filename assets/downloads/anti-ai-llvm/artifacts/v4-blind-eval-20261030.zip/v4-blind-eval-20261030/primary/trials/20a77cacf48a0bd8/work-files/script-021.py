from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
with open('target.so','rb') as f:
 e=ELFFile(f);seg=[(p['p_vaddr'],p['p_memsz'],p.data()) for p in e.iter_segments() if p['p_type']=='PT_LOAD']
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
for a,m,b in seg:
 try:u.mem_map(a&~4095,((a+m+4095)&~4095)-(a&~4095))
 except:pass
 u.mem_write(a,b)
u.mem_map(0x100000,4096);u.mem_map(0x200000,0x20000)
def h(uc,a,s,d):
 if a==0x45ac:uc.reg_write(UC_ARM64_REG_X0,0);uc.reg_write(UC_ARM64_REG_PC,0x45b0)
 if a==0x100000:uc.emu_stop()
u.hook_add(UC_HOOK_CODE,h)
def run(q):
 u.reg_write(UC_ARM64_REG_SP,0x21fff0);u.reg_write(UC_ARM64_REG_LR,0x100000)
 for r,v in zip([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3],q):u.reg_write(r,v)
 u.emu_start(0x456c,0x100004,count=1000000);return u.reg_read(UC_ARM64_REG_W0)&0xff
def rle(xs):
 out=[];st=0;v=xs[0]
 for i,x in enumerate(xs[1:],1):
  if x!=v:out.append((st,i-1,v));st=i;v=x
 out.append((st,len(xs)-1,v));return out
for base in [(1,2,3,4),(15,7,2,14),(7,0,7,3),(149,279,409,17)]:
 print('\nBASE',base,'=',run(base),flush=True)
 for k in range(4):
  vals=[]
  for x in range(256):
   q=list(base);q[k]=x;vals.append(run(q))
  rr=rle(vals);print('var',k,'runs',len(rr),rr[:80],flush=True)