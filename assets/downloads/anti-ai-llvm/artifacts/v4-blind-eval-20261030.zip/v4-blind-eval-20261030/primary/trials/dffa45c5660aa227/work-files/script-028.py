import struct,collections
b=open('target.so','rb').read(); c=collections.Counter(struct.unpack_from('<I',b,a)[0]&0xff000000 for a in range(0x551c,0x62a0,4))
for k,v in c.most_common(): print(f'{k:08x}',v)