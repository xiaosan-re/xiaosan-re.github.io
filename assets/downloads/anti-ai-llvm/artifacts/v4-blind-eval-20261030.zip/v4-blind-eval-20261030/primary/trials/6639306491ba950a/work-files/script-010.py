from pathlib import Path
p=Path('target.so')
b=p.read_bytes()
print(len(b), b[:16].hex())
print(b[0x32c:0x36c].hex())