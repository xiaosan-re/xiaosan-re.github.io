def h(a):
 x=(a^0x838d31dc)&0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x&0xffffffff
for a in [0,1,2,3,4,5,0x1234,0x12345678,0xffffffff]:print(hex(a),hex(h(a)))