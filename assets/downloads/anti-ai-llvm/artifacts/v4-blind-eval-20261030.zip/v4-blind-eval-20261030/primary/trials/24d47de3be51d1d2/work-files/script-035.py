for w in [0x293defa8]:
 imm=(w>>15)&0x7f; imm=imm-128 if imm&64 else imm
 print('rt',w&31,'rt2',(w>>10)&31,'rn',(w>>5)&31,'off',imm*4,'mode',(w>>23)&3)
# decode bitmask immediates using ARM DecodeBitMasks for ORR logical immediate words
def ror(x,r,n): return ((x>>r)|(x<<(n-r)))&((1<<n)-1)
def highest(x): return x.bit_length()-1
def bitmask(w):
 sf=(w>>31)&1; N=(w>>22)&1; imms=(w>>10)&0x3f; immr=(w>>16)&0x3f
 length=highest((N<<6)|((~imms)&0x3f))
 levels=(1<<length)-1; S=imms&levels; R=immr&levels; esize=1<<length
 welem=(1<<(S+1))-1; welem=ror(welem,R,esize)
 out=0
 for i in range((64 if sf else 32)//esize):out|=welem<<(i*esize)
 return out
for w in [0x320107f5,0x32010bf5]: print(hex(w),hex(bitmask(w)))
# ubfm d365fd1a etc fields
for w in [0xd365fd1a,0xd365fd13]:print(hex(w),'rd',w&31,'rn',(w>>5)&31,'immr',(w>>16)&63,'imms',(w>>10)&63)
