import struct
b=open('target.so','rb').read()
def r(n,sf=0,sp=0): return ('x' if sf else 'w')+('sp' if n==31 and sp else ('zr' if n==31 else str(n)))
def ds(a,w):
 sf=w>>31; d=w&31;n=w>>5&31
 if w&0x9f000000==0x10000000:
  lo=w>>29&3; hi=w>>5&0x7ffff; im=hi<<2|lo; im-=1<<21 if im&(1<<20) else 0; return f'adr x{d},{a+im:#x}'
 if w&0x1f000000==0x11000000:
  op=w>>30&1;S=w>>29&1;im=w>>10&0xfff; im <<=12 if w>>22&1 else 0;return f'{("sub"if op else"add")+("s"if S else"")} {r(d,sf,1)},{r(n,sf,1)},#{im:#x}'
 if w&0x1f800000==0x12800000:
  op=w>>29&3;im=w>>5&0xffff;sh=(w>>21&3)*16;return f'{["movn","?","movz","movk"][op]} {r(d,sf)},#{im:#x},lsl#{sh}'
 if w&0x1f000000==0x0b000000:
  op=w>>30&1;S=w>>29&1;m=w>>16&31;sh=w>>22&3;am=w>>10&63;return f'{("sub"if op else"add")+("s"if S else"")} {r(d,sf)},{r(n,sf)},{r(m,sf)},{["lsl","lsr","asr","ror"][sh]}#{am}'
 if w&0x1f000000==0x0a000000:
  op=w>>29&3;N=w>>21&1;m=w>>16&31;sh=w>>22&3;am=w>>10&63;return f'{["and","orr","eor","ands"][op]}{("n"if N else"")} {r(d,sf)},{r(n,sf)},{r(m,sf)},{["lsl","lsr","asr","ror"][sh]}#{am}'
 if w&0x1f000000==0x1b000000:
  m=w>>16&31;ra=w>>10&31;sub=w>>15&1;return f'{"msub"if sub else"madd"} {r(d,sf)},{r(n,sf)},{r(m,sf)},{r(ra,sf)}'
 if w&0x1fe00000==0x1a800000:
  m=w>>16&31;cond=w>>12&15;op=(w>>10)&3; return f'csel?{op} {r(d,sf)},{r(n,sf)},{r(m,sf)},cond{cond:x}'
 if w&0x3b200c00==0x38000000:
  sz=w>>30&3;op=w>>22&3;im=w>>12&0x1ff;im-=0x200 if im&0x100 else 0;return f'{["str","ldr","ldrsw","?3"][op]} {r(d,sz==3)},[{r(n,1,1)},#{im}]'
 if w&0x3b000000==0x39000000:
  sz=w>>30&3;op=w>>22&3;im=(w>>10&0xfff)<<sz;return f'{["str","ldr","ldrsw","?3"][op]} {r(d,sz==3)},[{r(n,1,1)},#{im}]'
 if w&0x3b200c00==0x38200800:
  sz=w>>30&3;op=w>>22&3;m=w>>16&31;opt=w>>13&7;S=w>>12&1;return f'{["str","ldr","ldrsw","?3"][op]} {r(d,sz==3)},[{r(n,1)},{r(m,0)},opt{opt},S{S}]'
 if w&0x7f800000 in (0x13000000,0x53000000):
  immr=w>>16&63;imms=w>>10&63;return f'bitfield {r(d,sf)},{r(n,sf)},r{immr},s{imms}'
 if w&0x1f800000==0x12000000:
  N=w>>22&1;immr=w>>16&63;imms=w>>10&63;op=w>>29&3;return f'logimm{op} {r(d,sf)},{r(n,sf)},N{N},r{immr},s{imms}'
 if w&0xff000010==0x54000000:
  im=w>>5&0x7ffff;im-=1<<19 if im&(1<<18) else 0;return f'b.cond{w&15:x} {a+im*4:#x}'
 if w>>26 in (5,37):
  im=w&0x3ffffff;im-=1<<26 if im&(1<<25) else 0;return f'{"bl"if w>>31 else"b"} {a+im*4:#x}'
 if w==0xd503201f:return 'nop'
 return f'.word {w:08x}'
for a in range(0x551c,0x5884,4):print(f'{a:04x}: {ds(a,struct.unpack_from("<I",b,a)[0])}')