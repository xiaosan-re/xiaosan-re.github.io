import struct
b=open('target.so','rb').read();u=lambda a:struct.unpack_from('<I',b,a)[0]
def fm(x):
 x&=0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x
S=[0x6ce1a125,0xe90a6b4e,0x673635f3,0xfd22fe64,0x7b4e8889,0xf17b5532,0x4f671fa7,0xc59329c8,0x43bff27d]
print('static const uint32_t tab[92][9] = {')
for q in range(92):
 g=q*0x9e3779b9&0xffffffff;v=[u(0x2d0+4*(q*9+j))^fm(g^S[j]) for j in range(9)]
 print(' {'+', '.join('0x%08xu'%x for x in v)+'},')
print('};')