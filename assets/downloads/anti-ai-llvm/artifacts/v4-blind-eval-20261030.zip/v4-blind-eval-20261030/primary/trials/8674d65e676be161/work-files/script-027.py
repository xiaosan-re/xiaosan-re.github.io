import struct
b=open('target.so','rb').read()
for a in range(0x5500,0x5b10,16):print(hex(a),b[a:a+16].hex(),[hex(x) for x in struct.unpack('<4I',b[a:a+16])])
