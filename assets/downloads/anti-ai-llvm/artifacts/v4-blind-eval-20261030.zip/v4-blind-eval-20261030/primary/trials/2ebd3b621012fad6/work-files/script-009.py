import struct, importlib.util
p='target.so'
b=open(p,'rb').read()
print(len(b), b[:16].hex())
print('capstone', importlib.util.find_spec('capstone'))
# ELF header and section/program headers
E=struct.unpack_from('<16sHHIQQQIHHHHHH',b,0)
print('etype machine entry phoff shoff flags ehsize phentsz phnum shentsz shnum shstr',E[1:])
for i in range(E[10]):
 o=E[5]+i*E[9]; print('PH',i,struct.unpack_from('<IIQQQQQQ',b,o))