M=0xffffffff
def u(x):return x&M
def h(a):
 x=u(a + (0x05988750 ^ 0x74103af9))
 v=u((x^(x>>16))*0x7feb352d)
 v=u((v^(v>>15))*0x846ca68b)
 return u(v^(v>>16))
def f416c(a1,a2,a3):return u((a1^0x3523bc87^a2^0x958c503b)+(a3^0x92302251))^0x3075f77d
def f41a8(a1,a2,a3,a4):return ((a3^0xf87cda15) if ((a1^0xab^a2^0xf)&1) else (a4^0xe5b76471))^0xc7b3ad0f
def f41f4(a1,a2,a3,a4):return ((a3^0xac6a46a5) if ((a1^0x23^a2^0x19)&1) else (a4^0x3bfde1b3))^0x7abbbb77
def f4240(a1,a2,a3):return u((a1^0x932e7c5d^a2^0x606d5219)+(a3^0xb509ae97))^0x563bfb0b
def f427c(a1,a2,a3,a4):return ((a3^0xc65e77bb) if ((a1^0xe1^a2^0xcd)&1) else (a4^0xa43289df))^0x2c9c67a5
def f42c8(a1,a2,a3,a4):return ((a3^0x3deebbf3) if ((a1^0xc1^a2^0x1f)&1) else (a4^0xdb12eaa9))^0xd06533f5
def f4314(a1,a2,a3,a4):return ((a3^0xad4fbbed) if ((a1^0xc3^a2^0x47)&1) else (a4^0x2880ec69))^0xbf5464a7
# initial saved state
r=f416c(0xbb686f72^0x3523bc87,0xef6a159f,0x2318fa58^0x92302251)
print('S_saved_-16',hex(r^0x3075f77d))
# hash cond -> helper selector state
for ok in [0,1]:
 r=(ok^0x9005996b)
 r=f41a8(r^0xde23ecab,0x61448364,0x181985d0,0x98dd168c)
 print('hashcond',ok,'state',hex(r^0xc7b3ad0f))
# b>9 selector
for gt in [0,1]:
 r=gt^0x1247659b
 r=f41f4(r^0xddf9b723,0xf121a982,0x5b5502a7,0xd489ec2a)
 print('bgt9',gt,'state',hex(r^0x7abbbb77))
# fixed 4240 output xor
r=f4240(0xbb686f72^0x932e7c5d,0x20f44c76,0x2318fa58^0xb509ae97)
print('fixed4240 state',hex(r^0x563bfb0b))
# d==h selector
for eq in [0,1]:
 r=eq^0x0d0078a3
 r=f427c(r^0x077aaee1,0x9e50026e,0x89a7c64f,0x2acc2e42)
 print('deq',eq,'state',hex(r^0x2c9c67a5))
# c>2 selector
for gt in [0,1]:
 r=gt^0x3b448bc9
 r=f42c8(r^0xf0c8f4c1,0x55a36ad6,0x6157b802,0xecf35105)
 print('cgt2',gt,'state',hex(r^0xd06533f5))
# initial invalid selector through 4314
for bad in [0,1]:
 r=bad^0x65ff10ef
 r=f4314(r^0x3719cec3,0xe7d435a8,0xac9e3481,0xb68acbcf)
 print('badqty',bad,'state',hex(r^0xbf5464a7))
print('hash small',[(i,hex(h(i)),h(i)&7) for i in range(12)])
