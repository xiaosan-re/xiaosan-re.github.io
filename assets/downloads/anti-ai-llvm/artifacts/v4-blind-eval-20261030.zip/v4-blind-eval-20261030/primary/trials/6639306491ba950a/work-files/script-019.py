import struct
b=open('target.so','rb').read()
for a in range(0x32c,0x7a0,4):
 w=struct.unpack_from('<I',b,a)[0]
 if (w & 0x7f800000) in (0x52800000,0x72800000):
  typ='movk' if w&0x20000000 else 'movz'
  rd=w&31; imm=(w>>5)&0xffff; sh=((w>>21)&3)*16
  print(f'{a:04x} {typ} w{rd}, #{imm:#x}, lsl #{sh}')