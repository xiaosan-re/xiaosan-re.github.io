for a in [63,0xc36b472c]:
 print(hex(a),a%7,a%10,a%16,a%100,a.bit_count(),hex(a&0xff))
 t={63:0xa90e4d5e,0xc36b472c:0x35baaad8}[a]
 print('tag',t%7,t%10,t%16,t%100,t.bit_count(),hex(t&0xff))