def logimm(w):
 sf=(w>>31)&1;N=(w>>22)&1;immr=(w>>16)&63;imms=(w>>10)&63
 x=(N<<6)|((~imms)&63); ln=x.bit_length()-1; levels=(1<<ln)-1; S=imms&levels;R=immr&levels;esize=1<<ln
 ones=(1<<(S+1))-1
 R%=esize; elem=((ones>>R)|(ones<<(esize-R)))&((1<<esize)-1)
 width=64 if sf else 32; out=0
 for i in range(0,width,esize):out|=elem<<i
 return sf,N,immr,imms,ln,hex(out)
for w in [0x12000913,0x320107f5,0x32010bf5]:print(hex(w),logimm(w), 'rn',(w>>5)&31,'rd',w&31,'opc',(w>>29)&3)