from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f)
 print('imports/exports')
 for s in e.get_section_by_name('.dynsym').iter_symbols(): print(s.name, s.entry)
 print('relocs')
 for sec in e.iter_sections():
  if sec['sh_type'] in ('SHT_RELA','SHT_REL'):
   for r in sec.iter_relocations(): print(sec.name,r.entry)