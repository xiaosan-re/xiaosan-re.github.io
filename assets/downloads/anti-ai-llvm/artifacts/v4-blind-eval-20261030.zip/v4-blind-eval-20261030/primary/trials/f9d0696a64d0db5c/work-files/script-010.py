from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f)
 for s in e.iter_sections():
  if s['sh_type'] in ('SHT_DYNSYM','SHT_RELA'):
   print('SEC',s.name)
   if s['sh_type']=='SHT_DYNSYM':
    for i,x in enumerate(s.iter_symbols()): print(i,repr(x.name),dict(x.entry))
   else:
    syms=e.get_section(s['sh_link'])
    for r in s.iter_relocations(): print(hex(r['r_offset']),r['r_info_type'],r['r_info_sym'],syms.get_symbol(r['r_info_sym']).name,hex(r['r_addend'] & ((1<<64)-1)))