# Recheck only the corrected closed form against the already recovered VM logic, implemented independently here.
import random,struct
D=open('target.so','rb').read();K=[0xbc479312,0x39ac5979,0xb79007c4,0x2d84cc53,0xabe8babe,0x21dd6705,0x9fc12d90,0x15351bff,0x9319c04a];u=lambda x:x&0xffffffff
def m(x):x=u(x^(x>>16));x=u(x*0x7feb352d);x=u(x^(x>>15));x=u(x*0x846ca68b);return u(x^(x>>16))
R=[[struct.unpack_from('<I',D,0x2d0+36*i+4*j)[0]^m(u(i*0x9e3779b9)^K[j]) for j in range(9)] for i in range(92)]
def vm(a,b,c,d):
 r=[0]*70;r[58]=u(a);r[23]=u(b);r[27]=u(c);r[14]=u(d);p=0
 for _ in range(200):
  op,z,aa,bb,cc,im,w,nx,al=R[p];A=r[aa];B=r[bb];C=r[cc]
  if op==0x31ef8a34:o=im
  elif op==0x432b31fa:o=A
  elif op==0xa9050067:o=u(B+A)
  elif op==0x778380a7:o=u(B*A)
  elif op==0xc179bd02:o=B^A
  elif op==0xcc213f3b:o=B&A
  elif op==0x68a9af5d:o=A>>(B&31)
  elif op==0x2d296d65:
   den=1 if B==0 else C;o=0 if den==0 else A//den
  elif op==0xfd23a89f:o={32:A==B,34:A>B,36:A<B}[im]
  elif op==0x86b9c54f:o=B if A else C
  elif op==0xd515b9c4:p=nx;continue
  elif op==0x9153976a:p=nx if A else al;continue
  elif op==0xe9855c9d:return A
  n=w&31;r[z]=u(int(o))&(0xffffffff if n==0 else (1<<n)-1);p=nx
 raise RuntimeError
def direct(a,b,c,d):
 a=u(a);b=u(b);c=u(c);d=u(d)
 if not 1<=b<=100:return 0x80000001
 if c>2:return 0x80000002
 if d!=m(a^0x838d31dc):return 0x80000003
 x=u((129 if c==0 else 249 if c==1 else 399)*b)
 if b>9:x=0 if a==0 else u(x*85)//a
 if (m(u(a+0x4c55a6ee))&7)==3:x=0 if a==0 else u(x*95)//a
 return u(x)
for i in range(50000):
 a=random.randrange(2**32);b=random.randrange(2**32) if i%10==0 else random.randrange(130);c=random.randrange(8);d=m(a^0x838d31dc) if i%2 else random.randrange(2**32)
 x,y=vm(a,b,c,d),direct(a,b,c,d)
 if x!=y:print('MISMATCH',a,b,c,d,hex(x),hex(y));break
else:print('all 50000 matched')
for q in [(100,5,0),(100,10,0),(100,100,2),(0,10,1),(0,9,2)]:
 a,b,c=q;d=m(a^0x838d31dc);print(q,hex(d),hex(direct(a,b,c,d)), 'special',m(u(a+0x4c55a6ee))&7==3)