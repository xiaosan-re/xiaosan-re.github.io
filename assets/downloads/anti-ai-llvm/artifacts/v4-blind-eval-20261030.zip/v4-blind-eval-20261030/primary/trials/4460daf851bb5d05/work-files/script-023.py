import struct
b=open('target.so','rb').read()
for i in range(80):
 print(i,hex(struct.unpack_from('<I',b,0x2d0+4*i)[0]))