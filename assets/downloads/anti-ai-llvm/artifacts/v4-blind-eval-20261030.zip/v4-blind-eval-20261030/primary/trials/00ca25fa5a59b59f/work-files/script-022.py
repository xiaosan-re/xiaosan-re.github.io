for c in [0xdaf0e110,0xa71a7200]: print(hex(0x02b508d0^c))
# Selector corrected mapping and transition states
S0=0xe4a7252e
for name,c_even,c_odd in [('valid',0x9e0a27a6,0x01d18f6c)]: print(hex(S0^c_even),hex(S0^c_odd))
print('C false/true',hex(0x7aad0288^0x37e1bbac),hex(0x7aad0288^0x5cb903f1))
print('hash false/true',hex(0x4d4cb924^0x8efea79d),hex(0x4d4cb924^0x4ff9b1f4))
# Ahash false/true corrected: false uses arg3 local 7d..., true arg2 e065...
print('Ahash false/true',hex(0xf07e66ec^0x7d6a72fd),hex(0xf07e66ec^0xe0655fc5))
# B >9 false/true corrected: false choice arg3 ef740d99, true arg2 f73f4402
print('B false/true',hex(0x1f0a6b75^0xef740d99),hex(0x1f0a6b75^0xf73f4402))
