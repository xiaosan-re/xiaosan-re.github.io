from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f)
 print([(s.name,hex(s['st_value']),s['st_size']) for sec in e.iter_sections() if sec['sh_type']=='SHT_DYNSYM' for s in sec.iter_symbols() if s.name])
 print([(seg['p_type'],hex(seg['p_vaddr']),hex(seg['p_offset']),hex(seg['p_filesz']),seg['p_flags']) for seg in e.iter_segments()])
 try:
  import capstone; print('capstone',capstone.__version__)
 except Exception as x: print(x)