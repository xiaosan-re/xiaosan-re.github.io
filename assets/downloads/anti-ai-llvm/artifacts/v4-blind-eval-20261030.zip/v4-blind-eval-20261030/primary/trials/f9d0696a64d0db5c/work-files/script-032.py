from unicorn import *
from unicorn.arm64_const import *
import struct
blob=open('target.so','rb').read()
def run(A):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
 for i,x in enumerate(A):u.reg_write(UC_ARM64_REG_X0+i,x)
 u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000)
 it=[-1]; info=[]; pcs=[]
 def h(u,a,s,z):
  if a==0x6e74:u.reg_write(UC_ARM64_REG_X0,0);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
  if a==0x530c:
   it[0]+=1; sp=u.reg_read(UC_ARM64_REG_SP); mem=u.mem_read(sp,0x2e0)
   nz=[]
   for off in range(0,0x2e0,4):
    v=struct.unpack_from('<I',mem,off)[0]
    if v:nz.append(f'{off:x}:{v:08x}')
   info.append([it[0],[], ' '.join(nz[:20])])
  elif it[0]>=0 and info and not (0x530c<=a<=0x54c0):
   if not info[-1][1] or a!=info[-1][1][-1]+4:info[-1][1].append(a)
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=100000)
 print('A',A,'ret',hex(u.reg_read(UC_ARM64_REG_W0)),'iters',len(info))
 for n,ps,vals in info: print(n,','.join(hex(x) for x in ps),vals)
run((1,2,3,4))