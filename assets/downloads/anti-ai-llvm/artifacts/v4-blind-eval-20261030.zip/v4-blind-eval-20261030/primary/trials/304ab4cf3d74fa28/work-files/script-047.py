def u(x):return x&0xffffffff
def coupon(a):
 t=u(a+0x7f70ea69)
 v=u(((t>>16)^t)*0x631805ed)
 v=u(((v>>15)^v)*0x4bb6ce6d)
 return ((v^(v>>16))&0xf78dbac7)==3
def token(a):
 t=a^0x87f7daef
 v=u(((t>>16)^t)*0x7feb352d)
 v=u(((v>>15)^v)*0x846ca68b)
 return u(v^(v>>16))
for a in [0,1,2,3,17,0xffffffff,0x12345678]: print(hex(a),coupon(a),hex(token(a)))
# frequency coupon in first million
xs=[a for a in range(1000000) if coupon(a)]
print('coupon count',len(xs),'first',xs[:10])