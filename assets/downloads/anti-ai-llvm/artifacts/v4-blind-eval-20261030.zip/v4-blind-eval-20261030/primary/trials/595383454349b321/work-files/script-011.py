import subprocess
r=subprocess.run(['/usr/bin/objdump','-d','target.so'],capture_output=True,text=True)
print('rc',r.returncode,'err',r.stderr[:500]); print(r.stdout[:3000])