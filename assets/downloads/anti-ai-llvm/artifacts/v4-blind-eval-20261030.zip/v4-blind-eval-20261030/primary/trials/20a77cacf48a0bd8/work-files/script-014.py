from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
def probe(args):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
 with open('target.so','rb') as f:
  e=ELFFile(f)
  for p in e.iter_segments():
   if p['p_type']=='PT_LOAD':
    a=p['p_vaddr'];lo=a&~4095;hi=(a+p['p_memsz']+4095)&~4095
    try:u.mem_map(lo,hi-lo)
    except:pass
    u.mem_write(a,p.data())
 u.mem_map(0x200000,0x20000);u.reg_write(UC_ARM64_REG_SP,0x21fff0)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),args):u.reg_write(r,v)
 def h(uc,a,s,d):
  if a in [0x459c,0x45a0,0x45a4,0x45a8,0x45ac,0x45b0,0x45b4,0x45b8,0x45bc,0x45c0,0x45c4,0x45c8]:
   print(hex(a),*[f'w{i}={uc.reg_read(UC_ARM64_REG_W0+i):08x}' for i in [0,8,19,20,21,22,23]])
  if a==0x45ac:uc.reg_write(UC_ARM64_REG_X0,0);uc.reg_write(UC_ARM64_REG_PC,0x45b0)
  if a==0x45cc:uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x45d0)
for q in [(1,2,3,4),(0,0,0,0),(1,2,3,0xffffffff),(1,2,3,3),(1,2,3,100)]:print('\nARGS',q);probe(q)