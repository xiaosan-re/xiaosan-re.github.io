# Minimal reusable target runner for coupon bucket 3 (a=22)
from unicorn import *
from unicorn.arm64_const import *
B=0x100000;S=0x200000;T=0x300000;d=open('target.so','rb').read()
def h(a):
 x=(a^0x838d31dc)&0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x&0xffffffff
def run(a,q,c):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000);u.mem_write(B,d[:2032]);u.mem_write(B+0x47f0,d[0x7f0:0x8e0]);u.mem_map(S,0x10000);u.mem_map(T,0x1000);u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_LR,T)
 for r,v in zip([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3],[a,q,c,h(a)]):u.reg_write(r,v)
 u.emu_start(B+0x32c,T,count=10000);return u.reg_read(UC_ARM64_REG_W0)
for q in range(1,21):
 print(q,[run(22,q,c) for c in range(3)])
print('distinguish')
for q in range(10,101):
 for c,p in enumerate([129,249,399]):
  got=run(22,q,c); x=q*p; seq=(x*85//100)*95//100; comb=x*85*95//10000
  if seq!=comb:print(q,c,got,seq,comb);raise SystemExit
