from unicorn import *
from unicorn.arm64_const import *
import struct
r=open('target.so','rb').read();B=0x100000;ST=0x800000;S=0x900000;mu=Uc(UC_ARCH_ARM64,UC_MODE_ARM);mu.mem_map(B,0x10000);mu.mem_write(B,r[:0x7200]);mu.mem_write(B+0xb200,r[0x7200:0x72f0]);mu.mem_map(ST,0x20000);mu.mem_map(S,0x1000)
sem={0x5b30:'IMM',0x5b50:'MOV14',0x5b70:'ADD',0x5b98:'SUB',0x5bc0:'MUL',0x5be8:'XOR',0x5c10:'AND',0x5c38:'OR',0x5c60:'SHL',0x5c8c:'LSR',0x5cb8:'ASR',0x5ce4:'UDIV',0x5d1c:'SDIV',0x5d80:'UREM',0x5dbc:'SREM',0x5e24:'CMP',0x5f80:'SELECT',0x5fb4:'MOV',0x5fd4:'SEXT',0x6008:'JMP',0x6030:'CJMP',0x606c:'RET',0x5b0c:'BAD'}
cur=[0];rec=[];started=[0]
def u32(a):return struct.unpack('<I',mu.mem_read(a,4))[0]
def u64(a):return struct.unpack('<Q',mu.mem_read(a,8))[0]
def hk(mu,a,s,u):
 p=a-B
 if p==0x6e74:mu.reg_write(UC_ARM64_REG_X0,0);mu.reg_write(UC_ARM64_REG_PC,mu.reg_read(UC_ARM64_REG_LR));return
 if p==0x551c and not started[0]:started[0]=1;fp=mu.reg_read(UC_ARM64_REG_X29);mu.mem_write(u64(fp-8),struct.pack('<I',cur[0]));return
 if p in sem:
  fp=mu.reg_read(UC_ARM64_REG_X29);arr=mu.reg_read(UC_ARM64_REG_X8)
  # array is actually original frame x3-0x120, recover from fp? print arr for diagnosis
  def d(reg):
   q=mu.reg_read(reg);return (hex(q-ST),u32(q) if ST<=q<ST+0x20000 else -1)
  pp=[]
  for off in [8,0x10,0x18,0x20,0x28,0x30]:
   q=u64(fp-off);pp.append((off,hex(q-ST),u32(q)))
  rec.append((cur[0],sem[p],hex(arr-ST),d(UC_ARM64_REG_X0),d(UC_ARM64_REG_X13),d(UC_ARM64_REG_X14),pp))
  cur[0]+=1
  if cur[0]>=92:mu.emu_stop();return
  mu.mem_write(u64(fp-8),struct.pack('<I',cur[0]));mu.mem_write(mu.reg_read(UC_ARM64_REG_X4),struct.pack('<I',0xe4a7522e));mu.reg_write(UC_ARM64_REG_PC,B+0x551c)
mu.hook_add(UC_HOOK_CODE,hk)
mu.reg_write(UC_ARM64_REG_SP,ST+0x10000);mu.reg_write(UC_ARM64_REG_LR,S)
for q,v in zip([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3],[1,2,3,4]):mu.reg_write(q,v)
try:mu.emu_start(B+0x456c,S,count=2000000)
except Exception as ex:print('ERR',ex,cur[0],hex(mu.reg_read(UC_ARM64_REG_PC)-B))
print('decoded',len(rec))
for x in rec:print(x)
