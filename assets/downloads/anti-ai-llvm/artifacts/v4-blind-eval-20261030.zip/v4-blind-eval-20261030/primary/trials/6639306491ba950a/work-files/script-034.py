for w in [0x4a484108,0x4a4a414a,0x4a483d08,0x4a493d37,0x4a584319,0x4a5742f7]:
 print(hex(w),'shift',(w>>22)&3,'rm',(w>>16)&31,'imm6',(w>>10)&63,'rn',(w>>5)&31,'rd',w&31)