import ctypes.util,glob,sys
print(ctypes.util.find_library('capstone'))
print(glob.glob('/usr/lib*/**/*capstone*',recursive=True)[:20])
print(glob.glob('/opt/**/libcapstone*',recursive=True)[:20])