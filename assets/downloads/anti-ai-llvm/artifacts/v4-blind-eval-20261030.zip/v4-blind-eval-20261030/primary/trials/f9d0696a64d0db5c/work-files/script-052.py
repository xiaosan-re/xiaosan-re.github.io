# find order difference for b 10..100 bases
for base in [129,249,399]:
 for b in range(10,101):
  x=base*b;a=(x*85//100)*95//100;c=(x*95//100)*85//100
  if a!=c:print(base,b,x,a,c);break