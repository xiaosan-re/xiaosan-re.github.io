import ctypes
p='/opt/homebrew/lib/libcapstone.dylib'
try:
 c=ctypes.CDLL(p); print('loaded',c)
except Exception as e: print(type(e).__name__,e)