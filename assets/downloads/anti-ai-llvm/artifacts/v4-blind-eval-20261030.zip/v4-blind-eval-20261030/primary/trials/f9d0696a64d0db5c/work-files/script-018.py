w=0x3700e728
imm=(w>>5)&0x3fff
if imm&0x2000:imm-=0x4000
print(imm,hex(0x45bc+imm*4), 'bit',((w>>31)<<5)|((w>>19)&31))