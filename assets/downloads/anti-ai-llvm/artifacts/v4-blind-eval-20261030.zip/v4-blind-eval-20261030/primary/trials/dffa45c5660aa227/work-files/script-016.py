for a,w in [(0x45bc,0x3700e728)]:
 imm=(w>>5)&0x3fff
 if imm&0x2000: imm-=0x4000
 print(hex(a+imm*4),imm,(w>>19)&31,w&31)
# decode call
w=0x94000a32; imm=w&0x3ffffff
if imm&0x2000000: imm-=1<<26
print(hex(0x45ac+imm*4))