import runpy,struct
ns=runpy.run_path('script-015.py');dec=ns['dec'];D=open('target.so','rb').read()
for center in [0x5530,0x5578,0x55ac,0x55d8,0x5604,0x5630,0x5660,0x5694,0x56c8,0x56f8,0x577c,0x57e4]:
 print('\n--',hex(center))
 for a in range(center-12,center+12,4): print(f'{a:04x}: {dec(a,struct.unpack_from("<I",D,a)[0])}')