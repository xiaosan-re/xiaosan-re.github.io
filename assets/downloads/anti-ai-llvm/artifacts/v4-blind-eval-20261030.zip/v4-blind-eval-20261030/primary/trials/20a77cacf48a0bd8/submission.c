#include <stdint.h>

uint32_t recovered(uint32_t a, uint32_t b, uint32_t c, uint32_t d)
{
    (void)a;
    (void)d;

    if (b == 0u || b > 100u)
        return UINT32_C(0x80000001);

    if (c < 3u)
        return UINT32_C(0x80000003);

    return UINT32_C(0x80000002);
}
