M=0xffffffff
vals={
'C1':0x6e619c92^0x919e6309,'C2':0x9748d55b^0x68b72ac7,
'h416c_w9':0x0ab58f4d^0x7053cae9,'h416c_w10':0x244a1735^0x244a1735,
}
for k,v in vals.items(): print(k,hex(v&M))
# all main call decode constants
print('first pred threshold relation')
