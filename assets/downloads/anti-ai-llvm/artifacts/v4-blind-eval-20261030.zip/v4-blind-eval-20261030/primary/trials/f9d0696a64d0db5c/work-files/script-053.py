from unicorn import *
from unicorn.arm64_const import *
blob=open('target.so','rb').read()
def tag(a):
 x=a^0x838d31dc;x^=x>>16;x=(x*0x7feb352d)&0xffffffff;x^=x>>15;x=(x*0x846ca68b)&0xffffffff;x^=x>>16;return x
def E(b,c):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
 for i,x in enumerate((63,b,c,tag(63))):u.reg_write(UC_ARM64_REG_X0+i,x)
 u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000)
 def h(u,x,s,z):
  if x==0x6e74:u.reg_write(UC_ARM64_REG_X0,0);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=100000);return u.reg_read(UC_ARM64_REG_W0)
for b,c in [(13,0),(17,1),(21,2)]:print(b,c,E(b,c))