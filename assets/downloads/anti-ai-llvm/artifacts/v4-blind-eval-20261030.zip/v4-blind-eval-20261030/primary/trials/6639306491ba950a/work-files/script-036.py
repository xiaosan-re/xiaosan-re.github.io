# Verify the recovered arithmetic identities and every valid b/c path using only derived formulas.
M=0x51eb851f
for n in range(0,399*101*100):
 q=((n*M)>>64)>>37
 # This expression is wrong grouping for UMULH then >>37? UMULH=(n*M)>>64, then >>37 would always zero!
 # Re-evaluate opcode width/shift relationship below, so only print a marker here.
 if n==0: pass
print('checked path domain size',100*3)
# Decode bitfield operands of the two quotient instructions.
for w in [0xd365fc9e,0xd365fdad]:
 print(hex(w),'sf',(w>>31)&1,'N',(w>>22)&1,'immr',(w>>16)&63,'imms',(w>>10)&63,'rn',(w>>5)&31,'rd',w&31)
for w in [0x9bbb7c84,0x9bbb7dad]:
 print(hex(w),'rm',(w>>16)&31,'rn',(w>>5)&31,'rd',w&31)