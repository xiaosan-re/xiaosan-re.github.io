import struct
p='target.so'
b=open(p,'rb').read()
print(len(b), b[:4])
# ELF64 section/program/symbol summary
E=struct.unpack_from('<16sHHIQQQIHHHHHH',b,0)
_,etype,mach,ver,entry,phoff,shoff,flags,eh,phents,phnum,shents,shnum,shstrndx=E
print('mach',mach,'ph',phoff,phnum,'sh',shoff,shnum,shstrndx)
for i in range(phnum):
 t,fl,off,va,pa,fs,ms,al=struct.unpack_from('<IIQQQQQQ',b,phoff+i*phents)
 print('PH',i,hex(t),hex(fl),hex(off),hex(va),hex(fs),hex(ms))
print('bytes@456c',b[0x456c:0x45ac].hex())
try:
 import capstone
 print('capstone',capstone.__version__)
 md=capstone.Cs(capstone.CS_ARCH_ARM64,capstone.CS_MODE_LITTLE_ENDIAN)
 for x in md.disasm(b[0x456c:0x466c],0x456c): print(hex(x.address),x.mnemonic,x.op_str)
except Exception as e: print('capstone unavailable',repr(e))