import struct
b=open('target.so','rb').read();u=lambda a:struct.unpack_from('<I',b,a)[0]
def fm(x):
 x&=0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x
salts=[0x6ce1a125,0xe90a6b4e,0x673635f3,0xfd22fe64,0x7b4e8889,0xf17b5532,0x4f671fa7,0xc59329c8,0x43bff27d]
for q in range(48):
 base=q*9;gold=q*0x9e3779b9&0xffffffff
 vals=[u(0x2d0+4*(base+j))^fm(gold^salts[j]) for j in range(9)]
 print(q, [hex(x) if x>100 else x for x in vals])