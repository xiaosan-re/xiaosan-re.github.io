from elftools.elf.elffile import ELFFile
import struct
p='target.so'
with open(p,'rb') as f:
 e=ELFFile(f)
 print('entry',hex(e.header.e_entry),e.get_machine_arch())
 for s in e.iter_sections(): print(s.name,hex(s['sh_addr']),hex(s['sh_offset']),hex(s['sh_size']),hex(s['sh_flags']))
 dyn=e.get_section_by_name('.dynsym')
 for sym in dyn.iter_symbols():
  if sym.name: print('SYM',sym.name,hex(sym['st_value']),sym['st_size'],sym['st_info']['type'],sym['st_shndx'])
 text=e.get_section_by_name('.text'); b=text.data()[0x456c-text['sh_addr']:0x456c-text['sh_addr']+256]
 for j in range(0,len(b),16): print(hex(0x456c+j),b[j:j+16].hex(),*[hex(x) for x in struct.unpack('<IIII',b[j:j+16])])