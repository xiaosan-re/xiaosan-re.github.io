#include <stdint.h>

static uint32_t avalanche(uint32_t x) {
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

uint32_t recovered(uint32_t a, uint32_t b, uint32_t c, uint32_t d) {
    if (b < 1 || b > 100)
        return UINT32_C(0x80000001);
    if (c > 2)
        return UINT32_C(0x80000002);
    if (d != avalanche(a ^ UINT32_C(0x87f7daef)))
        return UINT32_C(0x80000003);

    static const uint32_t rate[3] = { 129, 249, 399 };
    uint32_t result = rate[c] * b;

    if (b > 9)
        result = (result * 85) / 100;
    if ((avalanche(a + UINT32_C(0x7f70ea69)) & 7) == 3)
        result = (result * 95) / 100;

    return result;
}
