import struct
b=open('target.so','rb').read(); cond=['eq','ne','cs','cc','mi','pl','vs','vc','hi','ls','ge','lt','gt','le','al','nv']
for a in range(0x4d0,0x780,4):
 w=struct.unpack_from('<I',b,a)[0]
 if w>>26 in (0b000101,0b100101):
  imm=(w&0x3ffffff); imm=imm-(1<<26) if imm&(1<<25) else imm
  print(f'{a:04x}: {"bl" if w>>26==0b100101 else "b"} {a+4*imm:04x}')
 elif (w&0xff000010)==0x54000000:
  imm=(w>>5)&0x7ffff; imm=imm-(1<<19) if imm&(1<<18) else imm
  print(f'{a:04x}: b.{cond[w&15]} {a+4*imm:04x}')
 elif (w&0x7f000000)==0x34000000:
  imm=(w>>5)&0x7ffff; imm=imm-(1<<19) if imm&(1<<18) else imm
  print(f'{a:04x}: {"cbnz" if w&(1<<24) else "cbz"} w{w&31}, {a+4*imm:04x}')