import struct
D=open('target.so','rb').read(); ptr={29:0,31:-0x30}; slots={}
def sx(v,n):return v-(1<<n) if v&(1<<(n-1)) else v
for a in range(0x45c0,0x52d8,4):
 w=struct.unpack_from('<I',D,a)[0]
 # add/sub imm 64
 if w&0x9f000000==0x91000000:
  op=(w>>30)&1; rd=w&31;rn=(w>>5)&31;imm=((w>>10)&0xfff)<<(12 if (w>>22)&1 else 0)
  if rn in ptr:ptr[rd]=ptr[rn]+(-imm if op else imm)
  elif rd in ptr:del ptr[rd]
 # unscaled 64 load/store
 elif w&0xff200000 in (0xf8000000,0xf8400000):
  load=(w>>22)&1;rn=(w>>5)&31;rt=w&31;off=sx((w>>12)&0x1ff,9)
  if rn in ptr:
   ea=ptr[rn]+off
   if load:
    if ea in slots:ptr[rt]=slots[ea]
    elif rt in ptr:del ptr[rt]
   else:
    if rt in ptr: slots[ea]=ptr[rt]
 # 32 stores to known addresses
 elif (w&0x3b200000)==0x38000000 and ((w>>30)&3)==2 and not((w>>22)&1):
  rn=(w>>5)&31;rt=w&31;off=sx((w>>12)&0x1ff,9)
  if rn in ptr:
   ea=ptr[rn]+off
   if ea in (-0x160,-0x150,-0x170,-0x180,-0x190,-0x1a0,-0x1b0,-0x1c0,-0x1d0,-0x1e0,-0x1f0,-0x200,-0x210):print(hex(a),'store w'+str(rt),'at fp',hex(ea))
 elif (w&0x3b000000)==0x39000000 and ((w>>30)&3)==2 and not((w>>22)&1):
  rn=(w>>5)&31;rt=w&31;off=((w>>10)&0xfff)*4
  if rn in ptr:
   ea=ptr[rn]+off
   if -0x220<=ea<=-0x140:print(hex(a),'store w'+str(rt),'at fp',hex(ea))
print('slots',slots,'ptr',ptr)