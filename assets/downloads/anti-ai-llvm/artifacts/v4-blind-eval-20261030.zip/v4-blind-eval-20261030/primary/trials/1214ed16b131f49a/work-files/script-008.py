from elftools.elf.elffile import ELFFile
import struct
with open('target.so','rb') as f:
 e=ELFFile(f)
 for seg in e.iter_segments(): print('SEG',seg['p_type'],hex(seg['p_vaddr']),hex(seg['p_offset']),hex(seg['p_filesz']),hex(seg['p_memsz']),seg['p_flags'])
 for s in e.iter_sections():
  if s['sh_type'] in ('SHT_RELA','SHT_REL'):
   print('RELOC',s.name)
   sym=e.get_section(s['sh_link'])
   for r in s.iter_relocations():
    si=r['r_info_sym']; print(hex(r['r_offset']),r['r_info_type'], sym.get_symbol(si).name if si else '', dict(r.entry))
 sec=e.get_section_by_name('.text'); base=sec['sh_addr']; b=sec.data()[0x38cc-base:0x38cc-base+1704]
 print('words')
 for off in range(0,len(b),32): print(hex(0x38cc+off), ' '.join(f'{x:08x}' for x in struct.unpack('<'+'I'*min(8,(len(b)-off)//4),b[off:off+32])))