from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f)
 ds=e.get_section_by_name('.dynsym')
 for i,s in enumerate(ds.iter_symbols()): print(i,repr(s.name),s.entry)
 r=e.get_section_by_name('.rela.plt')
 for x in r.iter_relocations(): print('reloc',hex(x.entry.r_offset),x.entry.r_info_sym,x.entry.r_info_type)
