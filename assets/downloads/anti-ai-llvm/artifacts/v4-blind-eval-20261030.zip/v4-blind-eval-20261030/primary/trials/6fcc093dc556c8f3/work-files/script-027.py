for x in [0x1a900230,0x1a808090,0x1a8600e3,0x1a938285,0x1a9532d3]: print(hex(x),'rd',x&31,'rn',(x>>5)&31,'rm',(x>>16)&31,'cond',(x>>12)&15)
def bucket(a):
 x=(a+0x4c55a6ee)&0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x&7
for a in range(30):print(a,bucket(a))
