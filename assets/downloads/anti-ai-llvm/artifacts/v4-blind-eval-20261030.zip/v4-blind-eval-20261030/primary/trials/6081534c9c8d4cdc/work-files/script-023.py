from unicorn import *
from unicorn.arm64_const import *
import random
blob=open('target.so','rb').read()
blocks=set([0x3be8,0x3c1c,0x3c5c,0x3cb0,0x3d00,0x3d5c,0x3dac,0x3de8,0x3e24,0x3e44,0x3e64,0x3e94,0x3eb0,0x3ecc,0x3ef8,0x3f04,0x3f38,0x3f50,0x392c])
def emu(args,detail=False):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0xd000,0x1000);u.mem_map(0x100000,0x20000)
 u.reg_write(UC_ARM64_REG_SP,0x110000);u.reg_write(UC_ARM64_REG_X30,0x8000)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),args):u.reg_write(r,v)
 trace=[]
 def hook(uc,ad,sz,user):
  if ad==0x4f9c:
   uc.reg_write(UC_ARM64_REG_W0,0);uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_X30));return
  if ad in blocks:
   fp=uc.reg_read(UC_ARM64_REG_X29)
   def rd(off):return int.from_bytes(uc.mem_read(fp-off,4),'little')
   trace.append((hex(ad),hex(uc.reg_read(UC_ARM64_REG_W28)),hex(uc.reg_read(UC_ARM64_REG_W21)),hex(uc.reg_read(UC_ARM64_REG_W23)),hex(uc.reg_read(UC_ARM64_REG_W19)),[hex(rd(x)) for x in (4,8,12,16,20,24,28,32,36)]))
  if ad==0x8000:uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,hook);u.emu_start(0x38cc,0x8004,count=1000000)
 return u.reg_read(UC_ARM64_REG_W0),trace
T=[(0,0,0,0),(1,2,3,4),(0xffffffff,)*4,(5,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1),(100,20,2,7)]
for a in T:
 try:
  r,t=emu(a);print('\n',tuple(hex(x) for x in a),'=',hex(r),'steps',len(t));print(' '.join(x[0] for x in t));print('last',t[-3:])
 except Exception as e:print('ERR',a,e)