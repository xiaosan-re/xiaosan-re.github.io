def p(a):
 x=(a+0x7f70ea69)&0xffffffff;x=((x^(x>>16))*0x7feb352d)&0xffffffff;x=((x^(x>>15))*0x846ca68b)&0xffffffff;x=x^(x>>16);return x&7,x
for a in range(20):print(a,p(a)[0])