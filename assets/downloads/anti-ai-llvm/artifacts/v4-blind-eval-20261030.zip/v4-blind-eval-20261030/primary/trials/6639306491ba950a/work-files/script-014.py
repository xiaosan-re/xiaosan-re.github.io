import pkgutil
mods={m.name for m in pkgutil.iter_modules()}
print(sorted(x for x in mods if any(k in x.lower() for k in ('capstone','arm','elf','disasm','keystone'))))