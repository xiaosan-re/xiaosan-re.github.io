from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
BASE=0x100000;STACK=0x200000;SENT=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(s['p_vaddr'],s.data()) for s in e.iter_segments() if s['p_type']=='PT_LOAD']
def run(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0x10000)
 for va,d in segs:u.mem_write(BASE+va,d)
 u.mem_write(BASE+0x4f9c,b'\xc0\x03\x5f\xd6')
 u.mem_map(STACK,0x10000);u.mem_map(SENT,0x1000);u.reg_write(UC_ARM64_REG_SP,STACK+0x8000);u.reg_write(UC_ARM64_REG_X30,SENT)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 cnt=[0]
 def h(uc,ad,sz,x):
  cnt[0]+=1
  if ad==SENT:uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(BASE+0x38cc,SENT,count=1000000)
 return u.reg_read(UC_ARM64_REG_X0)&0xffffffff,cnt[0]
for a in [(0,0,0,0),(1,2,3,4),(100,1,0,17),(100,2,500,17),(149,9300,17,0),(0xffffffff,)*4,(10,0,0,0),(10,1,0,0),(10,2,0,0),(10,3,0,0),(1000,9300,17,0)]:print(a,run(a))