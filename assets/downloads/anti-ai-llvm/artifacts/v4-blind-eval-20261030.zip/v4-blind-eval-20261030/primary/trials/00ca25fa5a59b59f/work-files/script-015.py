import ctypes,ctypes.util
from pathlib import Path
lib=ctypes.CDLL(ctypes.util.find_library('capstone'))
class I(ctypes.Structure): _fields_=[('id',ctypes.c_uint),('address',ctypes.c_uint64),('size',ctypes.c_uint16),('bytes',ctypes.c_ubyte*24),('mnemonic',ctypes.c_char*32),('op_str',ctypes.c_char*160),('detail',ctypes.c_void_p)]
lib.cs_open.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.POINTER(ctypes.c_size_t)];lib.cs_disasm.argtypes=[ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint64,ctypes.c_size_t,ctypes.POINTER(ctypes.POINTER(I))];lib.cs_disasm.restype=ctypes.c_size_t
h=ctypes.c_size_t();lib.cs_open(1,0,ctypes.byref(h)); raw=Path('target.so').read_bytes()
def dis(a,z):
 bb=raw[a:z];buf=ctypes.create_string_buffer(bb);p=ctypes.POINTER(I)();n=lib.cs_disasm(h,buf,len(bb),a,0,ctypes.byref(p));
 for j in range(n):
  x=p[j];print(f'{x.address:04x}: {x.mnemonic.decode():8} {x.op_str.decode()}')
dis(0x3f74,0x4410)
