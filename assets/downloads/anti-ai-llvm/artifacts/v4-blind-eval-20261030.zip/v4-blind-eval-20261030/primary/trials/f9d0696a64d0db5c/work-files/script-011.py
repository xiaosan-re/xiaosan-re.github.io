from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
import struct
PAGE=0x1000
with open('target.so','rb') as f:
 blob=f.read(); f.seek(0); e=ELFFile(f); segs=[dict(s.header) for s in e.iter_segments() if s['p_type']=='PT_LOAD']
print(segs)

def run(args,trace=False):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
 # map broad image and stack
 u.mem_map(0,0x10000,UC_PROT_ALL); u.mem_write(0,blob[:min(len(blob),0x10000)])
 u.mem_map(0x100000,0x20000,UC_PROT_ALL)
 u.mem_map(0x200000,0x1000,UC_PROT_ALL)
 for i,a in enumerate(args): u.reg_write(UC_ARM64_REG_X0+i,a)
 u.reg_write(UC_ARM64_REG_SP,0x118000); u.reg_write(UC_ARM64_REG_X30,0x200000)
 n=[0]
 def hc(uc,addr,size,user):
  n[0]+=1
  if trace and (n[0]<100 or addr in (0x6e74,)): print(n[0],hex(addr),uc.mem_read(addr,4).hex(),*[hex(uc.reg_read(r)) for r in [UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3]])
  if n[0]>2000000: uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,hc)
 try:u.emu_start(0x456c,0x200000,count=2100000)
 except UcError as x: print('ERR',x,'pc',hex(u.reg_read(UC_ARM64_REG_PC)),'n',n[0])
 print('args',args,'ret',hex(u.reg_read(UC_ARM64_REG_X0)),'pc',hex(u.reg_read(UC_ARM64_REG_PC)),'n',n[0])
run((0,0,0,0),True)
for a in [(1,2,3,4),(0xffffffff,0xffffffff,0xffffffff,0xffffffff),(123,456,789,101112)]: run(a)