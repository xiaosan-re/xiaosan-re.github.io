from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
import random
B=0x100000;S=0x200000;E=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x.header.p_vaddr,x.data()) for x in e.iter_segments() if x.header.p_type=='PT_LOAD']
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000);u.mem_map(S,0x10000);u.mem_map(E,0x1000)
for v,d in segs:u.mem_write(B+v,d)
def run(v,stop=0):
 u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
 for r,x in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),v):u.reg_write(r,x)
 if stop:
  hit=[]
  def h(uc,a,z,q):
   if a-B==stop:hit.append(1);uc.emu_stop()
  hh=u.hook_add(UC_HOOK_CODE,h);u.emu_start(B+0x32c,E,count=1000);u.hook_del(hh)
 else:u.emu_start(B+0x32c,E,count=1000)
 return u
def mix(x):
 x&=0xffffffff;x^=x>>16;x=(x*0x7feb352d)&0xffffffff;x^=x>>15;x=(x*0x846ca68b)&0xffffffff;x^=x>>16;return x&0xffffffff
def tok(a):return mix(a^0x9b05606f)
def bucket(a):return mix((a+0x7188bda9)&0xffffffff)&7
def pred(a,b,c,d):
 if b<1 or b>100:return 0x80000001
 if c>2:return 0x80000002
 if d!=tok(a):return 0x80000003
 z=(129,249,399)[c]*b
 if bucket(a)==3:z=(z*95)//100
 if b>=10:z=(z*85)//100
 return z
for i in range(1000):
 a=random.getrandbits(32);q=run((a,1,2,0),0x428);actual=q.reg_read(UC_ARM64_REG_X23)&0xffffffff
 if actual!=tok(a):raise Exception(('token',hex(a),hex(actual),hex(tok(a))))
print('1000 token/hash checks passed')
# exhaustive valid business ranges over diverse a
As=list(range(64))+[random.getrandbits(32) for _ in range(36)]
n=0
for a in As:
 d=tok(a)
 for b in range(1,101):
  for c in range(3):
   actual=run((a,b,c,d)).reg_read(UC_ARM64_REG_X0)&0xffffffff;want=pred(a,b,c,d);n+=1
   if actual!=want:raise Exception(('valid',hex(a),b,c,hex(actual),hex(want),bucket(a)))
print(n,'valid behavior checks passed')
for i in range(10000):
 v=tuple(random.getrandbits(32) for _ in range(4));actual=run(v).reg_read(UC_ARM64_REG_X0)&0xffffffff;want=pred(*v)
 if actual!=want:raise Exception(('random',tuple(hex(x) for x in v),hex(actual),hex(want)))
print('10000 arbitrary-input checks passed')
