from unicorn import *
from unicorn.arm64_const import *
blob=open('target.so','rb').read()
def R(A):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
 for i,x in enumerate(A):u.reg_write(UC_ARM64_REG_X0+i,x)
 u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000)
 def h(u,x,s,z):
  if x==0x6e74:u.reg_write(UC_ARM64_REG_X0,0);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=100000);return u.reg_read(UC_ARM64_REG_W0)
vals=[0,1,2,3,4,5,6,7,10,16,17,47,48,49,63,64,99,100,101,149,279,409,9299,9300,10000,0xffffffff]
for c in [0,1,2]:
 print('c',c,'vary b d0')
 print(' '.join(f'{b}:{R((1,b,c,0)):#x}' for b in vals))
 print('c',c,'vary d b0')
 print(' '.join(f'{d}:{R((1,0,c,d)):#x}' for d in vals))