from unicorn import *
from unicorn.arm64_const import *
import random
B=0x100000;S=0x200000;T=0x300000;blob=open('target.so','rb').read();RR=[UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3]
def target(v):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000);u.mem_write(B,blob[:2032]);u.mem_write(B+0x47f0,blob[0x7f0:0x8e0]);u.mem_map(S,0x10000);u.mem_map(T,0x1000);u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_LR,T)
 for r,x in zip(RR,v):u.reg_write(r,x)
 u.emu_start(B+0x32c,T,count=10000);return u.reg_read(UC_ARM64_REG_W0)
def mix(a,add):
 x=((a+0x4c55a6ee)&0xffffffff) if add else (a^0x838d31dc);x&=0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x&0xffffffff
def model(a,b,c,d):
 if not 1<=b<=100:return 0x80000001
 if c>2:return 0x80000002
 if d!=mix(a,False):return 0x80000003
 t=b*(129,249,399)[c]
 if b>=10:t=t*85//100
 if (mix(a,True)&7)==3:t=t*95//100
 return t
cases=[]
for b in range(106):
 for c in range(5):
  a=random.getrandbits(32);h=mix(a,False);cases.extend([(a,b,c,h),(a,b,c,h^1)])
for _ in range(200):cases.append(tuple(random.getrandbits(32) for _ in range(4)))
random.shuffle(cases)
for i,v in enumerate(cases):
 got=target(v);exp=model(*v)
 if got!=exp:print('MISMATCH',i,tuple(hex(x) for x in v),hex(got),hex(exp));break
else:print('all matched',len(cases))