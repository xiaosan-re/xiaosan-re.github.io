from elftools.elf.elffile import ELFFile
import struct
with open('target.so','rb') as f:
 e=ELFFile(f)
 print([(s.name,hex(s['sh_addr']),hex(s['sh_offset']),hex(s['sh_size'])) for s in e.iter_sections()])
 for s in e.iter_sections():
  if s.name=='.text':
   d=s.data(); a=s['sh_addr'];
   start=0x38cc-a
   for i in range(start,start+1704,16):
    ws=struct.unpack_from('<4I',d,i)
    print(f'{a+i:04x}:',' '.join(f'{x:08x}' for x in ws))
