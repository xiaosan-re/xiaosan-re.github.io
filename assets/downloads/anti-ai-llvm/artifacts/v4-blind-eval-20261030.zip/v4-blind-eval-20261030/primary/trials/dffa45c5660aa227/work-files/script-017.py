w=0x12000908
print('sf',w>>31,'N',(w>>22)&1,'immr',(w>>16)&63,'imms',(w>>10)&63,'rn',(w>>5)&31,'rd',w&31)
# cset cond from aliases CSINC wd,wzr,wzr,invert(cond); bits cond 15:12
for x in [0x1a9f17f7,0x1a9f07e8]: print(hex(x),(x>>12)&15)