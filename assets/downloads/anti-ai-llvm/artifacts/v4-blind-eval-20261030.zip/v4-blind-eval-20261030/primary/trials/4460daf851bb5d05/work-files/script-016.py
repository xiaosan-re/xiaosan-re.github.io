import struct,collections
b=open('target.so','rb').read(); start=0x456c; end=0x62d4
ws=list(struct.unpack_from('<%dI'%((end-start)//4),b,start))
print('n',len(ws))
print('top11')
for k,v in collections.Counter(w>>21 for w in ws).most_common(): print(f'{k:03x} {v}')
# recognized control flow patterns
for i,w in enumerate(ws):
 a=start+4*i
 s=''
 if w&0x7c000000==0x14000000:
  imm=w&0x3ffffff; imm=imm-(1<<26) if imm>>25 else imm; s=('bl' if w>>31 else 'b')+f' {a+4*imm:#x}'
 elif w&0xff000010==0x54000000:
  imm=(w>>5)&0x7ffff; imm=imm-(1<<19) if imm>>18 else imm;s=f'b.cond{w&15:x} {a+4*imm:#x}'
 elif w&0x7f000000==0x34000000:
  imm=(w>>5)&0x7ffff;imm=imm-(1<<19) if imm>>18 else imm;s=f'{"cbnz" if w>>24&1 else "cbz"} {a+4*imm:#x}'
 elif w&0x7f000000==0x36000000:
  imm=(w>>5)&0x3fff;imm=imm-(1<<14) if imm>>13 else imm;s=f'{"tbnz" if w>>24&1 else "tbz"} {a+4*imm:#x}'
 elif w in [0xd65f03c0]: s='ret'
 elif w&0xfffffc1f in [0xd61f0000,0xd63f0000]:s='br/blr'
 if s: print(f'{a:04x}: {w:08x} {s}')