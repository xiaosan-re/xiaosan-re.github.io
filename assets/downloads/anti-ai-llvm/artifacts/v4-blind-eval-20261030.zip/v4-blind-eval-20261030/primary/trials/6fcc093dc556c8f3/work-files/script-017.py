from unicorn import *
from unicorn.arm64_const import *
BASE=0x100000;STACK=0x200000; blob=open('target.so','rb').read(); regs=[getattr(__import__('unicorn.arm64_const',fromlist=['x']),f'UC_ARM64_REG_X{i}') for i in range(31)]
def s(args):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0x10000);u.mem_write(BASE,blob[:2032]);u.mem_write(BASE+0x47f0,blob[0x7f0:0x8e0]);u.mem_map(STACK,0x10000);u.reg_write(UC_ARM64_REG_SP,STACK+0x8000)
 for r,v in zip(regs[:4],args):u.reg_write(r,v)
 def hk(uc,a,z,d):
  if a==BASE+0x4fc: uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,hk);u.emu_start(BASE+0x32c,BASE+0x800,count=1000)
 return [u.reg_read(r)&0xffffffff for r in regs]
base=s((0,0,0,0)); print('base',' '.join(f'{i}:{x:08x}' for i,x in enumerate(base)))
for args in [(1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1),(0xffffffff,0,0,0),(0,0xffffffff,0,0),(0,0,0xffffffff,0),(0,0,0,0xffffffff)]:
 q=s(args); print(args,' '.join(f'w{i}={v:08x}' for i,(x,v) in enumerate(zip(base,q)) if x!=v))
