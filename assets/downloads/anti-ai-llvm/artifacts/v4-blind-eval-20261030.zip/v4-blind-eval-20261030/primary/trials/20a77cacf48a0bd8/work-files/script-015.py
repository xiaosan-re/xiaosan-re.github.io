# reusable emulator; bypass observer and sample grid
from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
with open('target.so','rb') as f:
 e=ELFFile(f); seg=[(p['p_vaddr'],p['p_memsz'],p.data()) for p in e.iter_segments() if p['p_type']=='PT_LOAD']
def run(q):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
 for a,m,b in seg:
  lo=a&~4095;hi=(a+m+4095)&~4095
  try:u.mem_map(lo,hi-lo)
  except:pass
  u.mem_write(a,b)
 u.mem_map(0x100000,4096);u.mem_map(0x200000,0x20000);u.reg_write(UC_ARM64_REG_SP,0x21fff0);u.reg_write(UC_ARM64_REG_LR,0x100000)
 for r,v in zip([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3],q):u.reg_write(r,v)
 vals={};n=[0]
 def h(uc,a,s,d):
  n[0]+=1
  if a in (0x45ac,0x45c0,0x6200,0x6210,0x6220,0x6230,0x6240,0x6250,0x6260,0x6270,0x6280,0x6290,0x62a0,0x62b0,0x62c0): vals[a]=(uc.reg_read(UC_ARM64_REG_W0),uc.reg_read(UC_ARM64_REG_W8),uc.reg_read(UC_ARM64_REG_W23))
  if a==0x45ac:uc.reg_write(UC_ARM64_REG_X0,0);uc.reg_write(UC_ARM64_REG_PC,0x45b0)
  if a==0x100000:uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x100004,count=1000000)
 return u.reg_read(UC_ARM64_REG_W0),n[0],vals
for a in range(16):
 r,n,v=run((a,2,3,4));print(a,hex(r),n,v.get(0x45ac),v.get(0x45c0))