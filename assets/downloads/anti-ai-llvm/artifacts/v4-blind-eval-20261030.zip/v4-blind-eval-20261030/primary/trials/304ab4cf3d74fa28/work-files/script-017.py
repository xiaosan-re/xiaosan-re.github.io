mods=['angr','archinfo','pyvex','pwn','pwnlib','keystone','unicorn','lief','elftools','r2pipe','binaryninja','miasm']
for m in mods:
 try:
  x=__import__(m); print(m,'YES')
 except Exception as e: pass