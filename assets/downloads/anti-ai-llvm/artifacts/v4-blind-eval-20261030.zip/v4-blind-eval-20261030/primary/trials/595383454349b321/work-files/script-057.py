try:
 import pycparser;print('pycparser',pycparser.__version__)
except Exception as e:print(e)