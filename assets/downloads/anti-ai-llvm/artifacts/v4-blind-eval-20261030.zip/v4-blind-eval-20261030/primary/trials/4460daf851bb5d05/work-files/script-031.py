# print state handler K data exactly
import struct
b=open('target.so','rb').read();u=lambda a:struct.unpack_from('<I',b,a)[0]
def mc(a):
 w=u(a); v=((w>>5)&65535)<<(((w>>21)&3)*16); w=u(a+4); sh=((w>>21)&3)*16; return ((v&~(65535<<sh))|(((w>>5)&65535)<<sh))&0xffffffff
D={}
for a in list(range(0x5310,0x5500,0x14))+list(range(0x5878,0x5a30,0x14)):
 wb=u(a+12);im=(wb>>5)&0x7ffff;im-=1<<19 if im>>18 else 0;D[mc(a)]=a+12+4*im
T={}
for h in set(D.values()):
 for a in range(h,min(h+0x180,0x62a0),4):
  if (u(a)&0x7f80001f)==0x5280000c and u(a+8)==0x4a0c0129 and u(a+12)==0xb9000089:T[h]=mc(a);break
  if u(a)&0x7c000000==0x14000000:break
T[0x5a34]=0x01d18f6c
names={0x551c:'INIT',0x5a34:'WRITE',0x5b0c:'BADRET',0x5b30:'MOV_X0',0x5b50:'MOV_R',0x5b70:'ADD',0x5b98:'SUB',0x5bc0:'MUL',0x5be8:'XOR',0x5c10:'AND',0x5c38:'OR',0x5c60:'SHL',0x5c8c:'LSR',0x5cb8:'ASR',0x5ce4:'UDIV',0x5d1c:'SDIV',0x5d80:'UREM',0x5dbc:'SREM',0x5e24:'CMP',0x5f80:'SEL',0x5fb4:'MOV_R2',0x5fd4:'SEXT',0x6008:'SETQ',0x6030:'CHQ',0x606c:'RETURN'}
for st,h in D.items():print(f'case 0x{st:08x}u: /* {names.get(h,"NOP")} {h:04x} */', '' if h in (0x551c,0x5b0c,0x606c,0x5508) else f'K=0x{T[h]:08x}')