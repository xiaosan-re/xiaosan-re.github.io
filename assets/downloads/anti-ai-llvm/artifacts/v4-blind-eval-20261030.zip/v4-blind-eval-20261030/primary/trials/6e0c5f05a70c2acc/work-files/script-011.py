import struct
p='target.so'
b=open(p,'rb').read()
print(len(b), b[:16].hex())
for mod in ['capstone','elftools']:
 try:
  m=__import__(mod); print(mod,'ok',getattr(m,'__version__',''))
 except Exception as e: print(mod,'no',e)
# ELF section headers
E=struct.unpack_from('<16sHHIQQQIHHHHHH',b,0)
print('shoff,shentsz,shnum,shstr',E[6],E[11],E[12],E[13])
for i in range(E[12]):
 s=struct.unpack_from('<IIQQQQIIQQ',b,E[6]+i*E[11]); print(i,s)
