import struct,collections
b=open('target.so','rb').read(); c=collections.Counter()
for a in range(0x45c0,0x530c,4): c[struct.unpack_from('<I',b,a)[0]&0xff000000]+=1
for k,v in c.most_common(): print(f'{k:08x}',v)