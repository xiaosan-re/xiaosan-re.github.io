from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
import struct
B=0x1000000;S=0x2000000;T=0x3000000
with open('target.so','rb') as f:raw=f.read();f.seek(0);e=ELFFile(f);ps=[p for p in e.iter_segments() if p['p_type']=='PT_LOAD']
def R(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0xe000);u.mem_map(S,0x10000);u.mem_map(T,0x1000)
 for p in ps:u.mem_write(B+p['p_vaddr'],raw[p['p_offset']:p['p_offset']+p['p_filesz']])
 u.mem_write(B+0xd410,struct.pack('<II',1,0));u.reg_write(UC_ARM64_REG_SP,S+0xf000);u.reg_write(UC_ARM64_REG_LR,T)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 u.emu_start(B+0x38cc,T,count=5000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
def h(a):
 x=(a^0x87f7daef)&0xffffffff;x=((x^(x>>16))*0x7feb352d)&0xffffffff;x=((x^(x>>15))*0x846ca68b)&0xffffffff;return (x^(x>>16))&0xffffffff
for a in [0,1,2,3,4,10,149,279,409,0xffffffff]:
 print('A',a,'H',hex(h(a)))
 for c in range(4):print([hex(R((a,b,c,h(a)))) for b in [0,1,2,9,10,11,99,100,101]])