import runpy,struct,contextlib,io
with contextlib.redirect_stdout(io.StringIO()):ns=runpy.run_path('script-015.py')
dec=ns['dec'];D=open('target.so','rb').read()
for a in range(0x6270,0x62d4,4):print(f'{a:04x}: {dec(a,struct.unpack_from("<I",D,a)[0])}')