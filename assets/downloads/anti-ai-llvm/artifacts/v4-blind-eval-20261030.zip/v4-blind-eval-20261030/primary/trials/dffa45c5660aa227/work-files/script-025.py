# reuse disassembler compact copied
import struct
b=open('target.so','rb').read()
def R(n,sf=0,sp=False): return ('x' if sf else 'w')+('sp' if n==31 and sp else ('zr' if n==31 else str(n)))
def ds(a,w):
 sf=w>>31; rd=w&31; rn=w>>5&31
 if w&0x1f000000==0x11000000:
  op=w>>30&1; S=w>>29&1; imm=w>>10&0xfff; imm <<=12 if w>>22&1 else 0
  return f'{("sub" if op else "add")+("s" if S else "")} {R(rd,sf,1)},{R(rn,sf,1)},#{imm:#x}'
 if w&0x1f800000==0x12800000:
  opc=w>>29&3; imm=w>>5&0xffff; sh=(w>>21&3)*16
  return f'{["movn","?","movz","movk"][opc]} {R(rd,sf)},#{imm:#x},lsl#{sh}'
 if w&0x1f000000==0x0b000000:
  op=w>>30&1; S=w>>29&1; rm=w>>16&31; sh=w>>22&3; amt=w>>10&0x3f
  return f'{("sub" if op else "add")+("s" if S else "")} {R(rd,sf)},{R(rn,sf)},{R(rm,sf)},{["lsl","lsr","asr","ror"][sh]}#{amt}'
 if w&0x1f000000==0x0a000000:
  opc=w>>29&3; N=w>>21&1; rm=w>>16&31; sh=w>>22&3; amt=w>>10&0x3f
  return f'{["and","orr","eor","ands"][opc]}{ "n" if N else ""} {R(rd,sf)},{R(rn,sf)},{R(rm,sf)},{["lsl","lsr","asr","ror"][sh]}#{amt}'
 if w&0x1f000000==0x1b000000:
  rm=w>>16&31; ra=w>>10&31; sub=w>>15&1
  return f'{"msub" if sub else "madd"} {R(rd,sf)},{R(rn,sf)},{R(rm,sf)},{R(ra,sf)}'
 if w&0x3b200c00==0x38000000:
  size=w>>30&3; opc=w>>22&3; imm=w>>12&0x1ff; imm-=0x200 if imm&0x100 else 0
  return f'{["str","ldr","ldrsw","?3"][opc]} {R(rd,1 if size==3 else 0)},[{R(rn,1,1)},#{imm}]'
 if w&0x3b000000==0x39000000:
  size=w>>30&3; opc=w>>22&3; imm=(w>>10&0xfff)<<size
  return f'{["str","ldr","ldrsw","?3"][opc]} {R(rd,1 if size==3 else 0)},[{R(rn,1,1)},#{imm}]'
 if w&0xff000010==0x54000000:
  imm=w>>5&0x7ffff; imm-=1<<19 if imm>>18 else 0; return f'b.{w&15:x} {a+imm*4:#x}'
 if w>>26 in (5,37):
  imm=w&0x3ffffff; imm-=1<<26 if imm>>25 else 0; return f'{"bl" if w>>31 else "b"} {a+imm*4:#x}'
 if w==0xd65f03c0:return 'ret'
 return f'.word {w:08x}'
for a in range(0x5270,0x5540,4): print(f'{a:04x}: {ds(a,struct.unpack_from("<I",b,a)[0])}')