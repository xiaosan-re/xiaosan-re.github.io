import pkgutil
mods={m.name for m in pkgutil.iter_modules()}
for n in ['lief','elftools','keystone','unicorn','angr','archinfo','pwn','r2pipe','binaryninja','iced_x86']:
 print(n,n in mods)