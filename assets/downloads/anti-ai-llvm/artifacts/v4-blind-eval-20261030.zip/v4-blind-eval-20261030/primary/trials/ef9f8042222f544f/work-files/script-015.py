import ctypes,ctypes.util
lib=ctypes.CDLL(ctypes.util.find_library('capstone'))
class I(ctypes.Structure): _fields_=[('id',ctypes.c_uint),('address',ctypes.c_uint64),('size',ctypes.c_uint16),('bytes',ctypes.c_ubyte*24),('mnemonic',ctypes.c_char*32),('op_str',ctypes.c_char*160),('detail',ctypes.c_void_p)]
lib.cs_disasm.restype=ctypes.c_size_t
with open('target.so','rb') as f:d=f.read()
for start,end in [(0x760,0x7a0),(0x780,0x7a0),(0x7a0,0x7d0)]:
 h=ctypes.c_size_t();lib.cs_open(1,0,ctypes.byref(h)); buf=(ctypes.c_ubyte*(end-start)).from_buffer_copy(d[start:end]);o=ctypes.POINTER(I)(); n=lib.cs_disasm(h,buf,len(buf),start,0,ctypes.byref(o));print('range',hex(start),hex(end),n)
 for j in range(n):print(f'{o[j].address:04x}: {o[j].mnemonic.decode():8} {o[j].op_str.decode()}')
 lib.cs_free(o,n);lib.cs_close(ctypes.byref(h))
print('raw',d[0x760:0x7c0].hex())