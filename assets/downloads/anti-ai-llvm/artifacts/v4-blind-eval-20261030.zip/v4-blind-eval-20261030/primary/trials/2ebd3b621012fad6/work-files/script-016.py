for x in [0xe0655fc5,0x7d6a72fd]: print(hex(0xf07e66ec^x))
print('b>9',hex(0xe8352f77))
# state paths likely
for s in [0x101b3929,0x8d141411]:
 print(hex(s),hex(s^0xb9ac761f),hex(s^0x9d0f2d38))