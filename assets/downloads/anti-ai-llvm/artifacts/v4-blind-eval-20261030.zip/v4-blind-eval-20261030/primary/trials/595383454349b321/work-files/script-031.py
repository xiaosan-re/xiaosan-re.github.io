import struct
D=open('target.so','rb').read()
START,END=0x45c0,0x62d4

def sx(v,n): return v-(1<<n) if v&(1<<(n-1)) else v

def bitmask(w):
 sf=w>>31; M=64 if sf else 32; N=(w>>22)&1; immr=(w>>16)&63; imms=(w>>10)&63
 q=(N<<6)|((~imms)&63); ln=q.bit_length()-1; levels=(1<<ln)-1; S=imms&levels;R=immr&levels; es=1<<ln
 e=(1<<(S+1))-1; R%=es; e=((e>>R)|(e<<(es-R)))&((1<<es)-1)
 out=0
 for i in range(0,M,es):out|=e<<i
 return out

def rr(n,sf): return '0' if n==31 else f'(uint{64 if sf else 32}_t)x[{n}]'
def ww(n,sf,e): return '' if n==31 else f'x[{n}]=(uint{64 if sf else 32}_t)({e});'
def spr(n): return 'sp' if n==31 else f'x[{n}]'
def sh(e,typ,k,sf):
 bits=64 if sf else 32; T=f'uint{bits}_t'; S=f'int{bits}_t'; k%=bits
 if typ==0:return f'(({T})({e})<<{k})'
 if typ==1:return f'(({T})({e})>>{k})'
 if typ==2:return f'(({T})(({S})({e})>>{k}))'
 return f'ror{bits}(({T})({e}),{k})'
def condexpr(c):return f'cond({c},N,Z,C,V)'
def label(a):return f'L_{a:04x}'
def emit(a,w):
 # direct branch/call
 if (w&0xfc000000) in (0x14000000,0x94000000):
  dst=a+sx(w&0x3ffffff,26)*4
  if (w>>31)&1:
   if a==0x62b0:return '/* unreachable dirty-process helper */ x[0]=0x800000ffu;'
   return f'/* call 0x{dst:x} omitted */'
  return f'goto {label(dst)};'
 if w&0xff000010==0x54000000:
  dst=a+sx((w>>5)&0x7ffff,19)*4; return f'if ({condexpr(w&15)}) goto {label(dst)};'
 if w&0x7e000000==0x34000000:
  sf=w>>31;nz=(w>>24)&1;dst=a+sx((w>>5)&0x7ffff,19)*4; op='!=' if nz else '=='
  return f'if ({rr(w&31,sf)} {op} 0) goto {label(dst)};'
 if w&0x7e000000==0x36000000:
  nz=(w>>24)&1; bit=((w>>31)&1)*32+((w>>19)&31);dst=a+sx((w>>5)&0x3fff,14)*4; op='!=' if nz else '=='
  return f'if ((({rr(w&31,w>>31)}>>{bit})&1u) {op} 0) goto {label(dst)};'
 if w==0xd65f03c0:return 'return (uint32_t)x[0];'
 # move wide
 if w&0x1f800000==0x12800000:
  sf=w>>31;opc=(w>>29)&3;rd=w&31;imm=(w>>5)&0xffff;shift=((w>>21)&3)*16; bits=64 if sf else 32; full=(1<<bits)-1
  if opc==2:e=str((imm<<shift)&full)
  elif opc==0:e=str((~(imm<<shift))&full)
  elif opc==3:e=f'(({rr(rd,sf)} & {hex(full ^ (0xffff<<shift))}ULL) | {hex(imm<<shift)}ULL)'
  else:raise ValueError(('movewide',hex(a),hex(w)))
  return ww(rd,sf,e)
 # add/sub immediate
 if w&0x1f000000==0x11000000:
  sf=w>>31;op=(w>>30)&1;S=(w>>29)&1;rd=w&31;rn=(w>>5)&31;imm=((w>>10)&0xfff)<<(12 if (w>>22)&1 else 0)
  av=spr(rn) if sf and rn==31 else rr(rn,sf); bits=64 if sf else 32
  if S:
   fn=('subf' if op else 'addf')+str(bits); e=f'{fn}({av},{imm}ULL,&N,&Z,&C,&V)'
  else:e=f'(({av}) {"-" if op else "+"} {imm}ULL)'
  if rd==31:
   if S:return f'(void){e};'
   return f'sp=(uint64_t)({e});'
  return ww(rd,sf,e)
 # logical immediate
 if w&0x1f800000==0x12000000:
  sf=w>>31;opc=(w>>29)&3;rd=w&31;rn=(w>>5)&31;m=bitmask(w);ops=['&','|','^','&'];e=f'({rr(rn,sf)} {ops[opc]} {hex(m)}ULL)'
  out=ww(rd,sf,e)
  if opc==3:out+=f' setlog{64 if sf else 32}((uint{64 if sf else 32}_t)({e}),&N,&Z,&C,&V);'
  return out
 # bitfield (only observed aliases)
 if w&0x1f800000==0x13000000:
  sf=w>>31;opc=(w>>29)&3;rd=w&31;rn=(w>>5)&31;R=(w>>16)&63;S=(w>>10)&63;bits=64 if sf else 32
  if opc==2 and S==bits-1:e=f'({rr(rn,sf)}>>{R})'
  elif opc==0 and R==0 and S==31 and sf:e=f'(uint64_t)(int64_t)(int32_t){rr(rn,0)}'
  else:raise ValueError(('bitfield',hex(a),hex(w),opc,R,S))
  return ww(rd,sf,e)
 # logical shifted register
 if w&0x1f000000==0x0a000000:
  sf=w>>31;opc=(w>>29)&3;inv=(w>>21)&1;rd=w&31;rn=(w>>5)&31;rm=(w>>16)&31;typ=(w>>22)&3;k=(w>>10)&63
  b=sh(rr(rm,sf),typ,k,sf); b=f'(~({b}))' if inv else b; ops=['&','|','^','&'];e=f'({rr(rn,sf)} {ops[opc]} {b})';out=ww(rd,sf,e)
  if opc==3:out+=f' setlog{64 if sf else 32}((uint{64 if sf else 32}_t)({e}),&N,&Z,&C,&V);'
  return out
 # add/sub shifted register
 if w&0x1f000000==0x0b000000:
  sf=w>>31;op=(w>>30)&1;S=(w>>29)&1;rd=w&31;rn=(w>>5)&31;rm=(w>>16)&31;typ=(w>>22)&3;k=(w>>10)&63;bits=64 if sf else 32
  b=sh(rr(rm,sf),typ,k,sf)
  if S:e=f'{"subf" if op else "addf"}{bits}({rr(rn,sf)},{b},&N,&Z,&C,&V)'
  else:e=f'({rr(rn,sf)} {"-" if op else "+"} {b})'
  if rd==31:return f'(void){e};' if S else ''
  return ww(rd,sf,e)
 # madd/msub
 if w&0x1f000000==0x1b000000:
  sf=w>>31;sub=(w>>15)&1;rd=w&31;rn=(w>>5)&31;rm=(w>>16)&31;ra=(w>>10)&31;op='-' if sub else '+'
  return ww(rd,sf,f'(({rr(rn,sf)}*{rr(rm,sf)}) {op} {rr(ra,sf)})')
 # dp2
 if w&0x1fe00000==0x1ac00000:
  sf=w>>31;op=(w>>10)&0x3f;rd=w&31;rn=(w>>5)&31;rm=(w>>16)&31;bits=64 if sf else 32;a1=rr(rn,sf);a2=rr(rm,sf)
  if op==2:e=f'udiv{bits}({a1},{a2})'
  elif op==3:e=f'sdiv{bits}({a1},{a2})'
  elif op==8:e=f'((uint{bits}_t){a1} << ({a2}&{bits-1}))'
  elif op==9:e=f'((uint{bits}_t){a1} >> ({a2}&{bits-1}))'
  elif op==10:e=f'((uint{bits}_t)((int{bits}_t){a1} >> ({a2}&{bits-1})))'
  elif op==11:e=f'ror{bits}({a1},{a2}&{bits-1})'
  else:raise ValueError(('dp2',hex(a),op))
  return ww(rd,sf,e)
 # conditional select
 if w&0x1fe00000==0x1a800000:
  sf=w>>31;op=(w>>30)&1;o2=(w>>10)&1;rd=w&31;rn=(w>>5)&31;rm=(w>>16)&31;ce=condexpr((w>>12)&15);b=rr(rm,sf)
  if (op,o2)==(0,0):alt=b
  elif (op,o2)==(0,1):alt=f'({b}+1u)'
  elif (op,o2)==(1,0):alt=f'(~{b})'
  else:alt=f'(-{b})'
  return ww(rd,sf,f'({ce}?{rr(rn,sf)}:{alt})')
 # unsigned immediate load/store
 if w&0x3b000000==0x39000000:
  size=(w>>30)&3;load=(w>>22)&1;rn=(w>>5)&31;rt=w&31;off=((w>>10)&0xfff)<<size;addr=f'({spr(rn)}+{off})';bits=8<<size
  if load:return ww(rt,1 if size==3 else 0,f'ld{bits}(mem,{addr})')
  return f'st{bits}(mem,{addr},(uint{bits}_t){rr(rt,1 if size==3 else 0)});'
 # unscaled load/store
 if w&0x3b200000==0x38000000:
  size=(w>>30)&3;load=(w>>22)&1;rn=(w>>5)&31;rt=w&31;off=sx((w>>12)&0x1ff,9);addr=f'({spr(rn)}+({off}))';bits=8<<size
  if load:return ww(rt,1 if size==3 else 0,f'ld{bits}(mem,{addr})')
  return f'st{bits}(mem,{addr},(uint{bits}_t){rr(rt,1 if size==3 else 0)});'
 # load/store register offset: observed ROM word reads
 if w&0x3b200c00==0x38200800:
  size=(w>>30)&3;load=(w>>22)&1;rm=(w>>16)&31;option=(w>>13)&7;scale=(w>>12)&1;rn=(w>>5)&31;rt=w&31
  if not(load and size==2 and option==6 and scale==1):raise ValueError(('regload',hex(a),hex(w)))
  if rn==19:return ww(rt,0,f'tab[(uint32_t){rr(rm,0)}]')
  return ww(rt,0,f'ld32(mem,{spr(rn)}+(uint64_t)((int64_t)(int32_t){rr(rm,0)}*4))')
 # load/store pair (epilog only)
 if w&0x3a000000==0x28000000:
  sf=w>>31;load=(w>>22)&1;rt=w&31;rt2=(w>>10)&31;rn=(w>>5)&31;off=sx((w>>15)&0x7f,7)*(8 if sf else 4);bits=64 if sf else 32;addr=f'({spr(rn)}+({off}))'
  if load:return ww(rt,sf,f'ld{bits}(mem,{addr})')+' '+ww(rt2,sf,f'ld{bits}(mem,{addr}+{bits//8})')
  return f'st{bits}(mem,{addr},{rr(rt,sf)}); st{bits}(mem,{addr}+{bits//8},{rr(rt2,sf)});'
 # specials / deliberately unreachable default trap
 if w==0xd503201f:return '/* nop */'
 if a==0x552c:return 'x[19]=0; /* recovered table base */'
 if a==0x5508:return '/* unreachable trap literal load */'
 if a==0x550c:return 'return 0x800000ffu;'
 if a==0x5514:return '/* unreachable epilogue pair */'
 raise ValueError(('unknown',hex(a),hex(w)))

# Build source.
ro=D[0x2d0:0x452c]
if len(ro)%4:ro+=b'\0'*(-len(ro)%4)
words=struct.unpack('<%dI'%(len(ro)//4),ro)
head='''#include <stdint.h>
#include <string.h>

static uint8_t N,Z,C,V;
static uint32_t ld32(const uint8_t*m,uint64_t a){uint32_t v;memcpy(&v,m+a,4);return v;}
static uint64_t ld64(const uint8_t*m,uint64_t a){uint64_t v;memcpy(&v,m+a,8);return v;}
static uint8_t ld8(const uint8_t*m,uint64_t a){return m[a];}
static uint16_t ld16(const uint8_t*m,uint64_t a){uint16_t v;memcpy(&v,m+a,2);return v;}
static void st8(uint8_t*m,uint64_t a,uint8_t v){m[a]=v;}
static void st16(uint8_t*m,uint64_t a,uint16_t v){memcpy(m+a,&v,2);}
static void st32(uint8_t*m,uint64_t a,uint32_t v){memcpy(m+a,&v,4);}
static void st64(uint8_t*m,uint64_t a,uint64_t v){memcpy(m+a,&v,8);}
static uint32_t ror32(uint32_t v,unsigned n){n&=31;return n?((v>>n)|(v<<(32-n))):v;}
static uint64_t ror64(uint64_t v,unsigned n){n&=63;return n?((v>>n)|(v<<(64-n))):v;}
static uint32_t addf32(uint32_t a,uint32_t b,uint8_t*n,uint8_t*z,uint8_t*c,uint8_t*v){uint32_t r=a+b;*n=r>>31;*z=!r;*c=r<a;*v=((~(a^b)&(a^r))>>31)&1;return r;}
static uint32_t subf32(uint32_t a,uint32_t b,uint8_t*n,uint8_t*z,uint8_t*c,uint8_t*v){uint32_t r=a-b;*n=r>>31;*z=!r;*c=a>=b;*v=(((a^b)&(a^r))>>31)&1;return r;}
static uint64_t addf64(uint64_t a,uint64_t b,uint8_t*n,uint8_t*z,uint8_t*c,uint8_t*v){uint64_t r=a+b;*n=r>>63;*z=!r;*c=r<a;*v=(uint8_t)((~(a^b)&(a^r))>>63);return r;}
static uint64_t subf64(uint64_t a,uint64_t b,uint8_t*n,uint8_t*z,uint8_t*c,uint8_t*v){uint64_t r=a-b;*n=r>>63;*z=!r;*c=a>=b;*v=(uint8_t)(((a^b)&(a^r))>>63);return r;}
static void setlog32(uint32_t r,uint8_t*n,uint8_t*z,uint8_t*c,uint8_t*v){*n=r>>31;*z=!r;*c=*v=0;}
static void setlog64(uint64_t r,uint8_t*n,uint8_t*z,uint8_t*c,uint8_t*v){*n=r>>63;*z=!r;*c=*v=0;}
static int cond(unsigned q,uint8_t n,uint8_t z,uint8_t c,uint8_t v){switch(q){case 0:return z;case 1:return !z;case 2:return c;case 3:return !c;case 4:return n;case 5:return !n;case 6:return v;case 7:return !v;case 8:return c&&!z;case 9:return !c||z;case 10:return n==v;case 11:return n!=v;case 12:return !z&&(n==v);case 13:return z||(n!=v);case 14:return 1;default:return 0;}}
static uint32_t udiv32(uint32_t a,uint32_t b){return b?a/b:0;} static uint64_t udiv64(uint64_t a,uint64_t b){return b?a/b:0;}
static uint32_t sdiv32(uint32_t a,uint32_t b){if(!b)return 0;if(a==0x80000000u&&b==0xffffffffu)return a;return (uint32_t)((int64_t)(int32_t)a/(int64_t)(int32_t)b);}
static uint64_t sdiv64(uint64_t a,uint64_t b){if(!b)return 0;if(a==0x8000000000000000ULL&&b==~0ULL)return a;{int64_t aa=(int64_t)a,bb=(int64_t)b;return (uint64_t)(aa/bb);}}
'''
tab='static const uint32_t tab[%d] = {\n'%len(words)
for i in range(0,len(words),8):tab+='  '+','.join('0x%08xu'%v for v in words[i:i+8])+',\n'
tab+='};\n\n'
body='uint32_t recovered(uint32_t a,uint32_t b,uint32_t c,uint32_t d){\n uint64_t x[31]={0},sp=0x4000; uint8_t mem[0x5000]={0};\n x[29]=0x4000; sp=x[29]-0x30; x[19]=d;x[20]=c;x[21]=b;x[22]=a;x[23]=0; N=Z=C=V=0;\n goto L_45c0;\n'
for a in range(START,END,4):
 w=struct.unpack_from('<I',D,a)[0]
 body+=f'{label(a)}: {emit(a,w)}\n'
body+='}\n'
open('recovered.c','w').write(head+tab+body)
print('generated',len(head+tab+body),'bytes,',len(words),'table words')
