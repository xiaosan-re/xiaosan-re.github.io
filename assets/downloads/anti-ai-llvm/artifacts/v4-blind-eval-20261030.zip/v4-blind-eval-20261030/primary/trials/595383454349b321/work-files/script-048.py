# Build a simple LZSS stream for the architecture-neutral IR from generator state.
import runpy,contextlib,io
with contextlib.redirect_stdout(io.StringIO()): ns=runpy.run_path('script-040.py')
raw=ns['raw']
def lz(data):
 out=bytearray();i=0;lits=bytearray()
 def flush():
  nonlocal lits
  while lits:
   n=min(128,len(lits));out.append(n-1);out.extend(lits[:n]);del lits[:n]
 while i<len(data):
  best=0;bd=0
  lo=max(0,i-65535)
  # candidates matching 3 bytes, scan recent via rfind repeatedly
  if i+3<=len(data):
   p=data.rfind(data[i:i+3],lo,i)
   tries=0
   while p>=lo and tries<64:
    n=3
    while n<130 and i+n<len(data) and data[p+n]==data[i+n]:n+=1
    if n>best:best=n;bd=i-p
    p=data.rfind(data[i:i+3],lo,p);tries+=1
  if best>=3:
   flush();out.append(0x80|(best-3));out.extend((bd&255,bd>>8));i+=best
  else:lits.append(data[i]);i+=1
 flush();return bytes(out)
c=lz(raw)
import base64
print(len(raw),len(c),len(base64.b64encode(c)))
open('ir.lz','wb').write(c)