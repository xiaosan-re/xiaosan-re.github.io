import shutil
for x in ['llvm-objdump','objdump','aarch64-linux-gnu-objdump','readelf']:
 print(x,shutil.which(x))