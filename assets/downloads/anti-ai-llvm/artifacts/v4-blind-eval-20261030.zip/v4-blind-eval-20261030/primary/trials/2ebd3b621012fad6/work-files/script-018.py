MASK=0xffffffff
M=0x7feb352d; N=0x846ca68b; C=0x4c55a6ee; X=0x838d31dc
mi=pow(M,-1,1<<32); ni=pow(N,-1,1<<32)
def unx(y,s):
 x=y
 k=s
 while k<32:
  x ^= y>>k
  k+=s
 return x&MASK
def invp(p):
 z=(p*ni)&MASK
 y=unx(z,15)
 t=(y*mi)&MASK
 q=unx(t,16)
 return (q-C)&MASK
def calc(a):
 t=(a+C)&MASK;t^=t>>16;t=t*M&MASK;t^=t>>15;p=t*N&MASK;bucket=(p^(p>>16))&7
 t=(a^X)&MASK;t^=t>>16;t=t*M&MASK;t^=t>>15;q=t*N&MASK;h=(q^(q>>16))&MASK
 return p,bucket,h
for p in [0xffffff9b,0xffffff9c,0xffffff9d,0xffffffff]:
 a=invp(p); print('p',hex(p),'a',hex(a),'calc',tuple(hex(x) for x in calc(a)))
# scores for sample p ffffff9c
for c,base in enumerate([129,249,399]):
 for b in [0,1,9,10,0xffffffff]:
  s=base*b&MASK
  if b>9:s=((s*85&MASK)*0x51eb851f)>>37
  if calc(invp(0xffffff9c))[1]==3:s=((s*95&MASK)*0x51eb851f)>>37
  print(c,b,hex(s))