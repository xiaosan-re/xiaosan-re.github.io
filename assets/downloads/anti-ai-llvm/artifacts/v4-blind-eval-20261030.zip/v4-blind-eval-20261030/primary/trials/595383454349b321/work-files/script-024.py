import struct,collections
D=open('target.so','rb').read();c=collections.Counter()
for a in range(0x456c,0x62d4,4):
 w=struct.unpack_from('<I',D,a)[0]
 if w&0xff000010==0x54000000:c[w&15]+=1
 if w&0x1fe00000==0x1a800000:c['csel'+str((w>>12)&15)]+=1
print(c)