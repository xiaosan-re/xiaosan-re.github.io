from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f)
 for secn in ['.dynsym','.dynstr','.rela.plt','.dynamic']:
  s=e.get_section_by_name(secn); print('\n',secn)
  if hasattr(s,'iter_symbols'):
   for x in s.iter_symbols(): print(x.name,x.entry)
  elif hasattr(s,'iter_relocations'):
   syms=e.get_section(s['sh_link'])
   for r in s.iter_relocations(): print(r.entry, syms.get_symbol(r['r_info_sym']).name)
  elif hasattr(s,'iter_tags'):
   for t in s.iter_tags(): print(t.entry)
