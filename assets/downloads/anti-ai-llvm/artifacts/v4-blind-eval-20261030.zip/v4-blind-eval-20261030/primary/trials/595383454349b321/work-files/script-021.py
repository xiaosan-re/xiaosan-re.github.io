w=0x10fd6d33;a=0x552c
immlo=(w>>29)&3; immhi=(w>>5)&0x7ffff; imm=(immhi<<2)|immlo
if imm&(1<<20):imm-=1<<21
print(hex(a+imm),imm)
D=open('target.so','rb').read();print(D[0x451c:0x456c].hex())
# decode literal target 5508
w=0x58ffffc1; print(hex(0x5508+((w>>5)&0x7ffff)*4))