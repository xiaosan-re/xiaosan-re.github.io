import runpy,struct,contextlib,io
with contextlib.redirect_stdout(io.StringIO()):ns=runpy.run_path('script-015.py')
dec=ns['dec'];D=open('target.so','rb').read()
for lo,hi in [(0x5af0,0x5b60),(0x5f50,0x60b0)]:
 print('\n')
 for a in range(lo,hi,4): print(f'{a:04x}: {dec(a,struct.unpack_from("<I",D,a)[0])}')