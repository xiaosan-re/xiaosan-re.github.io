import struct
b=open('target.so','rb').read()
for a in range(0x459c,0x45c0,4):
 w=struct.unpack_from('<I',b,a)[0]
 print(hex(a),hex(w),'cond',hex((w>>12)&15),'imm12',(w>>10)&0xfff,'regs',w&31,(w>>5)&31,(w>>16)&31)