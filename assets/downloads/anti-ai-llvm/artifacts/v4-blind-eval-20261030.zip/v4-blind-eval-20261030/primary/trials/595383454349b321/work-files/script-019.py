import runpy,struct
ns=runpy.run_path('script-015.py'); dec=ns['dec'];D=open('target.so','rb').read()
for a in range(0x52b0,0x5550,4):
 w=struct.unpack_from('<I',D,a)[0];print(f'{a:04x}: {dec(a,w)}')