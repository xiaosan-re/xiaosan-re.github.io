import runpy,struct,collections,contextlib,io
with contextlib.redirect_stdout(io.StringIO()): ns=runpy.run_path('script-015.py')
dec=ns['dec'];D=open('target.so','rb').read();c=collections.Counter()
for a in range(0x4588,0x62d4,4):
 s=dec(a,struct.unpack_from('<I',D,a)[0]);c[s.split()[0]]+=1
print(c)