from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f)
 print(e.header)
 for s in e.iter_sections(): print(s.name, hex(s['sh_addr']), hex(s['sh_offset']), s['sh_size'], s['sh_type'], s['sh_flags'])
 print('segments')
 for p in e.iter_segments(): print(p.header)
