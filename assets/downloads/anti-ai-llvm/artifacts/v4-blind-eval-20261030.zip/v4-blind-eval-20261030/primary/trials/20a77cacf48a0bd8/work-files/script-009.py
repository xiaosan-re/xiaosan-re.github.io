from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE,UC_HOOK_MEM_INVALID
from unicorn.arm64_const import *
P='target.so'
def run(args,count=False):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
 with open(P,'rb') as f:
  e=ELFFile(f)
  for p in e.iter_segments():
   if p['p_type']=='PT_LOAD':
    a=p['p_vaddr']; lo=a&~0xfff; hi=(a+p['p_memsz']+0xfff)&~0xfff
    try:u.mem_map(lo,hi-lo)
    except:pass
    u.mem_write(a,p.data())
 u.mem_map(0x100000,0x1000); u.mem_map(0x200000,0x20000)
 u.reg_write(UC_ARM64_REG_SP,0x21fff0); u.reg_write(UC_ARM64_REG_LR,0x100000)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),args):u.reg_write(r,v)
 n=[0]
 def hook(uc,a,s,d):
  n[0]+=1
  if a==0x100000: uc.emu_stop()
 def bad(uc,typ,a,size,val,d): print('BAD',typ,hex(a),size,hex(val));return False
 u.hook_add(UC_HOOK_CODE,hook);u.hook_add(UC_HOOK_MEM_INVALID,bad)
 try:u.emu_start(0x456c,0x100004,count=10000000)
 except Exception as ex: print('ERR',ex,'pc',hex(u.reg_read(UC_ARM64_REG_PC)),'ins',n[0])
 return u.reg_read(UC_ARM64_REG_X0)&0xffffffff,n[0],hex(u.reg_read(UC_ARM64_REG_PC))
for x in [(0,0,0,0),(1,2,3,4),(0xffffffff,0xffffffff,0xffffffff,0xffffffff),(123,456,789,1011),(10,20,30,40)]: print(x,run(x))