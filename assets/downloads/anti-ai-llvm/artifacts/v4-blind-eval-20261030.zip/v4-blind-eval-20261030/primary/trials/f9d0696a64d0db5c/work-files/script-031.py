from unicorn import *
from unicorn.arm64_const import *
import struct
blob=open('target.so','rb').read()
def snap(A):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
 for i,x in enumerate(A):u.reg_write(UC_ARM64_REG_X0+i,x)
 u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000)
 done=[False]
 def h(u,a,s,z):
  if a==0x6e74:u.reg_write(UC_ARM64_REG_X0,0);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
  if a==0x530c and not done[0]:
   done[0]=1;sp=u.reg_read(UC_ARM64_REG_SP);fp=u.reg_read(UC_ARM64_REG_X29)
   print('A',A,'sp/fp',hex(sp),hex(fp),'regs',' '.join(f'x{i}={u.reg_read(UC_ARM64_REG_X0+i):x}' for i in range(29)))
   mem=bytes(u.mem_read(sp,0x1000));
   for j in range(0,len(mem),16):
    q=struct.unpack_from('<QQ',mem,j)
    if q!=(0,0):print(f'{sp+j:08x}',mem[j:j+16].hex(),*[hex(x) for x in q])
   u.emu_stop()
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=100000)
snap((1,2,3,4))