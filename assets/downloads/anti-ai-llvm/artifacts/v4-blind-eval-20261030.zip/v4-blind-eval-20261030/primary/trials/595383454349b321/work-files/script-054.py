import hashlib
s=open('compact2.c','rb').read();print(len(s),hashlib.sha256(s).hexdigest())