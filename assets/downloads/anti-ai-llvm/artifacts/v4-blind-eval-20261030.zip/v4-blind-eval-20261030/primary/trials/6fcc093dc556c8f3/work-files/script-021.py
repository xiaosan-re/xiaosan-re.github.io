# Auditable Unicorn runner; report valid outputs around quantity boundaries and checksum snapshots
from unicorn import *
from unicorn.arm64_const import *
BASE=0x100000;STACK=0x200000;STOP=0x300000;blob=open('target.so','rb').read();R=[getattr(__import__('unicorn.arm64_const',fromlist=['x']),f'UC_ARM64_REG_X{i}') for i in range(31)]
def run(a,b,c,d=None,want_hash=False):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0x10000);u.mem_write(BASE,blob[:2032]);u.mem_write(BASE+0x47f0,blob[0x7f0:0x8e0]);u.mem_map(STACK,0x10000);u.mem_map(STOP,0x1000);u.reg_write(UC_ARM64_REG_SP,STACK+0x8000);u.reg_write(UC_ARM64_REG_LR,STOP)
 for r,v in zip(R[:4],[a,b,c,0 if d is None else d]):u.reg_write(r,v)
 def h(uc,x,z,q):
  if want_hash and x==BASE+0x4fc:uc.emu_stop()
  if x==STOP:uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(BASE+0x32c,STOP+4,count=10000)
 return u.reg_read(UC_ARM64_REG_W23) if want_hash else u.reg_read(UC_ARM64_REG_W0)
for a in [0,1,2,3,4,5,6,7,8,9,10,0x1234,0x12345678,0x80000000,0xffffffff]:print('H',hex(a),hex(run(a,1,0,want_hash=True)))
for b in [0,1,2,8,9,10,11,99,100,101,0xffffffff]:
 h=run(0x1234,1,0,want_hash=True);print('Q',b,[run(0x1234,b,c,h) for c in range(4)])