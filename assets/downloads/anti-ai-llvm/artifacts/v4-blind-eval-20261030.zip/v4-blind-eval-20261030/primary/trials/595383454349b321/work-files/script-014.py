import struct
D=open('target.so','rb').read(); start=0x456c; end=start+7528
for a in range(start,end,4):
 w=struct.unpack_from('<I',D,a)[0]
 # branch categories, ret, calls
 if w==0xd65f03c0 or (w&0x7c000000)==0x14000000 or (w&0x7e000000) in (0x34000000,0x36000000) or (w&0xff000010)==0x54000000:
  print(f'{a:04x}: {w:08x}')
print('end',hex(end))