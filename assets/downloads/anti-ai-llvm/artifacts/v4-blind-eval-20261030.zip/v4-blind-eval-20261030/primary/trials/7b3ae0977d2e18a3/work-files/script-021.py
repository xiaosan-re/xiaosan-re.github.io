from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
B=0x100000;S=0x200000;E=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x.header.p_vaddr,x.data()) for x in e.iter_segments() if x.header.p_type=='PT_LOAD']
def U(vals,stop=0):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000);u.mem_map(S,0x10000);u.mem_map(E,0x1000)
 for v,d in segs:u.mem_write(B+v,d)
 u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),vals):u.reg_write(r,v)
 if stop:
  u.hook_add(UC_HOOK_CODE,lambda uc,a,z,q: uc.emu_stop() if a-B==stop else None)
 u.emu_start(B+0x32c,E,count=1000);return u
def token(a):return U((a,1,2,0),0x428).reg_read(UC_ARM64_REG_X23)&0xffffffff
def out(a,b,c,d):return U((a,b,c,d)).reg_read(UC_ARM64_REG_X0)&0xffffffff
print('a: token x25at400 output')
for a in range(64):
 u=U((a,1,2,0),0x404);x25=u.reg_read(UC_ARM64_REG_X25)&0xffffffff;d=token(a)
 print(a,hex(d),x25,hex(out(a,1,2,d)))
print('c scan a0 b1 correct token')
d=token(0)
for c in list(range(0,21))+[100,0xffffffff]:print(c,hex(out(0,1,c,d)))
print('b boundaries c2')
for b in [0,1,2,8,9,10,11,50,99,100,101,0xffffffff]:print(b,hex(out(0,b,2,d)))
print('wrong token c scan')
for c in range(0,8):print(c,hex(out(0,1,c,d^1)))
