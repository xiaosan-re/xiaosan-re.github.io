for x in [2207068636,2207068600,2444847012,2087898659]:print(hex(x))
print(hex((0x838d31dc+100)&0xffffffff),hex(0x838d31dc^100),hex((0x838d31dc-100)&0xffffffff))