from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f)
 d=e.get_section_by_name('.dynsym')
 for i,x in enumerate(d.iter_symbols()): print(i,repr(x.name),hex(x['st_value']),x['st_info'])
 for s in e.iter_sections():
  if s['sh_type'] in ('SHT_RELA','SHT_REL'):
   print('RELOC',s.name)
   for r in s.iter_relocations(): print(hex(r['r_offset']),r['r_info_sym'],r.entry)