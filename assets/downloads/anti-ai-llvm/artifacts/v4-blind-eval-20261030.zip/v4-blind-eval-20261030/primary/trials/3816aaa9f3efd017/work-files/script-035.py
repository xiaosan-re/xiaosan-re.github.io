from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
import struct,random,time
BB=0x1000000;S=0x2000000;T=0x3000000
with open('target.so','rb') as f:raw=f.read();f.seek(0);e=ELFFile(f);ps=[p for p in e.iter_segments() if p['p_type']=='PT_LOAD']
def target(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BB,0xe000);u.mem_map(S,0x10000);u.mem_map(T,0x1000)
 for p in ps:u.mem_write(BB+p['p_vaddr'],raw[p['p_offset']:p['p_offset']+p['p_filesz']])
 u.mem_write(BB+0xd410,struct.pack('<II',1,0));u.reg_write(UC_ARM64_REG_SP,S+0xf000);u.reg_write(UC_ARM64_REG_LR,T)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 u.emu_start(BB+0x38cc,T,count=5000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
def mix_token(a):
 x=(a^0x87f7daef)&0xffffffff;x=((x^(x>>16))*0x7feb352d)&0xffffffff;x=((x^(x>>15))*0x846ca68b)&0xffffffff;return (x^(x>>16))&0xffffffff
def ref(a,b,c,d):
 if not 1<=b<=100:return 0x80000001
 if c>2:return 0x80000002
 if d!=mix_token(a):return 0x80000003
 x=(a+0x7f70ea69)&0xffffffff;x=((x^(x>>16))*0x7feb352d)&0xffffffff;x=((x^(x>>15))*0x846ca68b)&0xffffffff;x=x^(x>>16)
 v=[129,249,399][c]*b
 if b>=10:v=(v*85)//100
 if (x&7)==3:v=(v*95)//100
 return v
random.seed(123);cases=[]
for _ in range(300):
 a=random.getrandbits(32);b=random.choice([0,1,2,9,10,11,99,100,101,random.getrandbits(32)]);c=random.choice([0,1,2,3,0xffffffff]);d=mix_token(a) if random.randrange(2) else random.getrandbits(32);cases.append((a,b,c,d))
st=time.time()
for i,a in enumerate(cases):
 x=target(a);y=ref(*a)
 if x!=y:print('MISMATCH',i,tuple(hex(z) for z in a),hex(x),hex(y));break
else:print('all',len(cases),'matched in',time.time()-st)