import struct,collections
b=open('target.so','rb').read()
# classify stores in prelude
for a in range(0x464c,0x530c,4):
 w=struct.unpack_from('<I',b,a)[0]
 is_un=(w&0x3b200c00)==0x38000000 and ((w>>22)&3)==0
 is_ui=(w&0x3b000000)==0x39000000 and ((w>>22)&3)==0
 if is_un or is_ui:
  size=(w>>30)&3; rn=(w>>5)&31; rt=w&31
  if is_un:
   off=(w>>12)&0x1ff; off-=0x200 if off&0x100 else 0
  else: off=((w>>10)&0xfff)<<size
  print(f'{a:04x}: str {"x" if size==3 else "w"}{rt}, [x{rn},{off:+}]')