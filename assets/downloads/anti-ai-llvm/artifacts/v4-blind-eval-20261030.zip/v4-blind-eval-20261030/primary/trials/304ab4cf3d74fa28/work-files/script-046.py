for w in [0xd365fd1a,0xd365fd13]: print(hex(w),(w>>16)&63,(w>>10)&63,w&31,(w>>5)&31)
for w in [0x9ba97d08]:print('rm',(w>>16)&31,'ra',(w>>10)&31,'rn',(w>>5)&31,'rd',w&31)