import ctypes,struct
lib=ctypes.CDLL('/opt/homebrew/lib/libcapstone.dylib')
class I(ctypes.Structure): _fields_=[('id',ctypes.c_uint),('address',ctypes.c_uint64),('size',ctypes.c_uint16),('bytes',ctypes.c_ubyte*24),('mnemonic',ctypes.c_char*32),('op_str',ctypes.c_char*160),('detail',ctypes.c_void_p)]
h=ctypes.c_size_t();lib.cs_open(1,0,ctypes.byref(h));lib.cs_disasm.restype=ctypes.c_size_t
b=open('target.so','rb').read()
for a in range(0x760,0x7d0,4):
 raw=b[a:a+4]; buf=ctypes.create_string_buffer(raw);o=ctypes.POINTER(I)(); n=lib.cs_disasm(h,buf,4,a,1,ctypes.byref(o));
 print(f'{a:04x} {raw.hex()} '+(o[0].mnemonic.decode()+' '+o[0].op_str.decode() if n else 'INVALID'))
 if n:lib.cs_free(o,n)
lib.cs_close(ctypes.byref(h))