s=open('compact2.c').read();
print('qI count',s.count('q(I,k'))
print(s[s.index('for(;;)'):s.index('for(;;)')+400])
print('lines',s.count('\n'))