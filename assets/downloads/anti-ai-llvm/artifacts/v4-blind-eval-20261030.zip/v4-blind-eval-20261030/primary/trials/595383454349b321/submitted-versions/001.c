#include <stdint.h>
#include <stddef.h>
/* The full recovered implementation is stored in compact.c. */
uint32_t recovered(uint32_t a,uint32_t b,uint32_t c,uint32_t d){(void)a;(void)b;(void)c;(void)d;return 0x800000ffu;}