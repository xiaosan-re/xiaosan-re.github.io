from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f);r=e.get_section_by_name('.rodata');b=r.data();base=r['sh_addr']
 cur=[]
 for i,x in enumerate(b+b'\0'):
  if 32<=x<127:cur.append(x)
  else:
   if len(cur)>=4:print(hex(base+i-len(cur)),bytes(cur).decode())
   cur=[]