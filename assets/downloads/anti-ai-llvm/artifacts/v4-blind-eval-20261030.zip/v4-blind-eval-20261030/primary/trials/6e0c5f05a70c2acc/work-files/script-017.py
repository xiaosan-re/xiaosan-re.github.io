import ctypes,struct
lib=ctypes.CDLL('/opt/homebrew/lib/libcapstone.dylib')
major=ctypes.c_int();minor=ctypes.c_int();print(hex(lib.cs_version(ctypes.byref(major),ctypes.byref(minor))),major.value,minor.value)
class Insn(ctypes.Structure):
 _fields_=[('id',ctypes.c_uint),('address',ctypes.c_uint64),('size',ctypes.c_uint16),('bytes',ctypes.c_ubyte*24),('mnemonic',ctypes.c_char*32),('op_str',ctypes.c_char*160),('detail',ctypes.c_void_p)]
print('sizeof',ctypes.sizeof(Insn),[(x,getattr(Insn,x).offset) for x,_ in Insn._fields_])
h=ctypes.c_size_t(); print('open',lib.cs_open(1,0,ctypes.byref(h)),h.value)
b=open('target.so','rb').read()[0x32c:0x7a0]
buf=ctypes.create_string_buffer(b)
out=ctypes.POINTER(Insn)()
lib.cs_disasm.restype=ctypes.c_size_t
n=lib.cs_disasm(h,buf,len(b),0x32c,0,ctypes.byref(out)); print('n',n)
for i in range(min(n,300)):
 q=out[i]; print(f'{q.address:04x}: {q.mnemonic.decode()} {q.op_str.decode()}')
lib.cs_free(out,n);lib.cs_close(ctypes.byref(h))