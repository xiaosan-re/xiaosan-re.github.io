from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f)
 print('segments')
 for p in e.iter_segments():
  print(p['p_type'],hex(p['p_vaddr']),hex(p['p_offset']),hex(p['p_filesz']),hex(p['p_memsz']),p['p_flags'])
 print('symbols')
 for sn in ('.dynsym','.symtab'):
  s=e.get_section_by_name(sn)
  if s:
   for x in s.iter_symbols(): print(sn,x.name,hex(x['st_value']),x['st_size'],x['st_shndx'])
 print('relocs')
 for s in e.iter_sections():
  if s['sh_type'] in ('SHT_RELA','SHT_REL'):
   symtab=e.get_section(s['sh_link'])
   for r in s.iter_relocations():
    sym=symtab.get_symbol(r['r_info_sym']) if r['r_info_sym'] else None
    print(s.name,hex(r['r_offset']),r['r_info_type'],sym.name if sym else '',hex(r['r_addend']) if r.is_RELA() else '')
 print('strings')
 for s in e.iter_sections():
  if s.name in ('.rodata','.data.rel.ro'):
   d=s.data(); base=s['sh_addr']; cur=[]; st=0
   for j,b in enumerate(d+b'\0'):
    if 32<=b<127: 
     if not cur: st=j
     cur.append(chr(b))
    else:
     if len(cur)>=4: print(hex(base+st),''.join(cur))
     cur=[]