from elftools.elf.elffile import ELFFile
import struct
with open('target.so','rb') as f:e=ELFFile(f);s=e.get_section_by_name('.text');d=s.data();b=s['sh_addr']
for a in range(0x38cc,0x3960,4):print(hex(a),hex(struct.unpack('<I',d[a-b:a-b+4])[0]))