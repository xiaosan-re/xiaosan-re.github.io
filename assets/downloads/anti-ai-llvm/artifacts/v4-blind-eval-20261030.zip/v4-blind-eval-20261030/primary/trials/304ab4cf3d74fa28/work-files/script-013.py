try:
 import capstone
 print('capstone',capstone.__version__)
except Exception as e: print(type(e).__name__,e)