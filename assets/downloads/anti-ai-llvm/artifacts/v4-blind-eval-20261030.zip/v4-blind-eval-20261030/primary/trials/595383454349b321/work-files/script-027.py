import runpy,struct,contextlib,io
with contextlib.redirect_stdout(io.StringIO()):ns=runpy.run_path('script-015.py')
dec=ns['dec'];D=open('target.so','rb').read()
for a in range(0x456c,0x62d4,4):
 s=dec(a,struct.unpack_from('<I',D,a)[0])
 if s.startswith(('ubfm','sbfm')):print(hex(a),s)