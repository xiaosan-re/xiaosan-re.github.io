from unicorn import *
from unicorn.arm64_const import *
import random
with open('target.so','rb') as f:blob=f.read()
def mix(a,add):
 x=((a+0x7f70ea69)&0xffffffff) if add else (a^0x87f7daef)
 x^=x>>16;x=(x*0x7feb352d)&0xffffffff;x^=x>>15;x=(x*0x846ca68b)&0xffffffff;x^=x>>16;return x&0xffffffff
def rec(a,b,c,d):
 if not (1<=b<=100):return 0x80000001
 if c>2:return 0x80000002
 if d!=mix(a,False):return 0x80000003
 v=[129,249,399][c]*b
 if b>9:v=v*85//100
 if (mix(a,True)&7)==3:v=v*95//100
 return v&0xffffffff
def run(q):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x10000);u.reg_write(UC_ARM64_REG_SP,0x108000);u.reg_write(UC_ARM64_REG_X30,0x9000)
 for r,x in zip([UC_ARM64_REG_W0,UC_ARM64_REG_W1,UC_ARM64_REG_W2,UC_ARM64_REG_W3],q):u.reg_write(r,x)
 u.emu_start(0x32c,0x9000,count=10000);return u.reg_read(UC_ARM64_REG_W0)
cases=[]
for a in [0,1,2,3,4,5,0xffffffff,0x80000000,0x12345678]:
 for b in [0,1,9,10,11,99,100,101,0xffffffff]:
  for c in [0,1,2,3,0xffffffff]:
   hh=mix(a,False)
   for d in [hh,(hh+1)&0xffffffff,0,0xffffffff]:cases.append((a,b,c,d))
for _ in range(500):
 a=random.getrandbits(32);b=random.choice([random.getrandbits(32),random.randrange(0,102)]);c=random.choice([random.getrandbits(32),random.randrange(0,5)]);d=random.choice([random.getrandbits(32),mix(a,False)]);cases.append((a,b,c,d))
for i,q in enumerate(cases):
 x=run(q);y=rec(*q)
 if x!=y:print('MISMATCH',q,hex(x),hex(y));break
else:print('all matched',len(cases))