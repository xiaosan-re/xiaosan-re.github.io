from elftools.elf.elffile import ELFFile
from capstone import *
with open('target.so','rb') as f:
 e=ELFFile(f)
 print('entry',hex(e.header.e_entry),'type',e.header.e_type)
 for s in e.iter_sections():
  if s.name in ('.text','.rodata','.data','.dynamic','.rela.dyn','.rela.plt','.plt'):
   print(s.name,hex(s['sh_addr']),hex(s['sh_offset']),hex(s['sh_size']))
 text=e.get_section_by_name('.text'); data=text.data(); base=text['sh_addr']
 md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN)
 md.detail=False
 start=0x38cc; blob=data[start-base:start-base+1704]
 for i in md.disasm(blob,start): print(f'{i.address:04x}: {i.mnemonic:8} {i.op_str}')