v=(399*0xe4a7252e)&0xffffffff
q=((v*85)&0xffffffff) # ARM mul w8 wraps BEFORE umull
res=(q*0x51eb851f)>>37
print(hex(v),hex(q),res,hex(res))
# compare floor q/100
print(q//100)
