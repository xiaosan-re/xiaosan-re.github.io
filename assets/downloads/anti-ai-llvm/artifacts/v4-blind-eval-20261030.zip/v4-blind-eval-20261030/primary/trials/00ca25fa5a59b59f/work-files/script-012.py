import ctypes.util
for n in ['capstone','opcodes','bfd','LLVM','llvm']:
 print(n,ctypes.util.find_library(n))