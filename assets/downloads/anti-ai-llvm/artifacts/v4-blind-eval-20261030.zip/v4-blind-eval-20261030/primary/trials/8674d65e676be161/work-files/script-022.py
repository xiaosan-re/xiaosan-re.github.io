import ctypes,ctypes.util
lib=ctypes.CDLL(ctypes.util.find_library('capstone'))
class I(ctypes.Structure):_fields_=[('id',ctypes.c_uint),('address',ctypes.c_uint64),('size',ctypes.c_uint16),('bytes',ctypes.c_ubyte*24),('mnemonic',ctypes.c_char*32),('op_str',ctypes.c_char*160),('detail',ctypes.c_void_p)]
lib.cs_open.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.POINTER(ctypes.c_size_t)];lib.cs_disasm.argtypes=[ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint64,ctypes.c_size_t,ctypes.POINTER(ctypes.POINTER(I))];lib.cs_disasm.restype=ctypes.c_size_t
h=ctypes.c_size_t();lib.cs_open(1,0,ctypes.byref(h));raw=open('target.so','rb').read();b=raw[0x456c:0x62d4];buf=ctypes.create_string_buffer(b);o=ctypes.POINTER(I)();n=lib.cs_disasm(h,buf,len(b),0x456c,0,ctypes.byref(o))
for j in range(n):
 x=o[j]
 if x.address>=0x5400: print(f'{x.address:06x}: {x.mnemonic.decode():8} {x.op_str.decode()}')
lib.cs_free(o,n);lib.cs_close(ctypes.byref(h))
