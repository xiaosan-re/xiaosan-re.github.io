with open('target.so','rb') as f:
 f.seek(0x38cc); b=f.read(1704)
for i in range(0,len(b),32): print(f'{0x38cc+i:04x}:',b[i:i+32].hex())