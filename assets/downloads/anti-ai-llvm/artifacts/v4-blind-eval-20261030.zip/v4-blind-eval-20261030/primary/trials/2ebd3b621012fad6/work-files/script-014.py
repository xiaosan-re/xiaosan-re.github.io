import struct
b=open('target.so','rb').read()
for a in range(0x740,0x7a0,4): print(hex(a),hex(struct.unpack_from('<I',b,a)[0]))