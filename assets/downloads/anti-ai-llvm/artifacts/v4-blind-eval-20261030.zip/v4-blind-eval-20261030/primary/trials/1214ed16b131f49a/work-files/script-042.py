vals={'k':0xb683484e^0x2d862821,'m1':0x4da7137e^0x324c2653,'m2':0x1d264bde^0x994aed55}
print({k:hex(v&0xffffffff) for k,v in vals.items()})
def h(a):
 x=(a^vals['k'])&0xffffffff;x=((x^(x>>16))*vals['m1'])&0xffffffff;x=((x^(x>>15))*vals['m2'])&0xffffffff;return (x^(x>>16))&0xffffffff
for a in [0,1,2,10,47,0xffffffff,123456789]:print(a,hex(h(a)))