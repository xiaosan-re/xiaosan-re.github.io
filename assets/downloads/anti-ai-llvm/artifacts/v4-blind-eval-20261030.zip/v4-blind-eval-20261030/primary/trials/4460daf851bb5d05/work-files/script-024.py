import struct
b=open('target.so','rb').read()
def u32(a):return struct.unpack_from('<I',b,a)[0]
def movconst(a):
 w=u32(a); val=(w>>5)&0xffff; sh=((w>>21)&3)*16; v=val<<sh
 w2=u32(a+4)
 if w2&0x1f800000==0x12800000 and ((w2>>29)&3)==3 and (w2&31)==(w&31):
  sh2=((w2>>21)&3)*16; v=(v&~(0xffff<<sh2))|(((w2>>5)&0xffff)<<sh2);return v&0xffffffff,8
 return v&0xffffffff,4
# dispatch maps
D={}
for a in list(range(0x5310,0x5500,0x14))+list(range(0x5878,0x5a30,0x14)):
 try:
  c,_=movconst(a)
  # branch at a+12
  wb=u32(a+12); imm=(wb>>5)&0x7ffff
  if imm>>18:imm-=1<<19
  target=a+12+imm*4
  D[c]=target
 except: pass
print('dispatch',len(D))
for k,v in D.items():print(hex(k),hex(v))
# transition constants find in handlers by ldr/movz/movk/eor/str sequence, inspect blocks targets
T={}
for h in sorted(set(D.values())):
 found=[]
 for a in range(h,min(h+0x180,0x62a0),4):
  # movz w12 followed movk w12, then eor w9,w9,w12 then str w9,[x4]
  if (u32(a)&0x7f80001f)==0x5280000c:
   c,n=movconst(a)
   if n==8 and u32(a+8)==0x4a0c0129 and u32(a+12)==0xb9000089:
    found.append((a,c))
    break
  if u32(a)&0x7c000000==0x14000000: break
 T[h]=found[0] if found else None
print('transitions')
for h,x in T.items():print(hex(h), x and (hex(x[0]),hex(x[1])))
# calculate fmix
def fm(x):
 x&=0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x
state=0xb0d0c641 ^ fm(0x6ce1a125)
print('postinit',hex(state), 'target',hex(D.get(state,0)))
seen=[]
while state in D and state not in seen:
 seen.append(state);h=D[state]; tr=T.get(h)
 print(len(seen)-1,hex(state),'->',hex(h),'K', tr and hex(tr[1]))
 if h in (0x5b0c,0x606c):break
 if not tr:break
 state ^= tr[1]
print('end',hex(state),'n',len(seen))