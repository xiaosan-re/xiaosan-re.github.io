import ctypes,ctypes.util
b=open('target.so','rb').read();lib=ctypes.CDLL(ctypes.util.find_library('capstone'))
class I(ctypes.Structure): _fields_=[('id',ctypes.c_uint),('address',ctypes.c_uint64),('size',ctypes.c_uint16),('bytes',ctypes.c_ubyte*24),('mnemonic',ctypes.c_char*32),('op_str',ctypes.c_char*160),('detail',ctypes.c_void_p)]
h=ctypes.c_size_t();lib.cs_open(1,0,ctypes.byref(h))
print('raw',b[0x740:0x7a0].hex())
for st in [0x764,0x768,0x76c,0x770,0x774,0x778,0x77c,0x780]:
 arr=ctypes.POINTER(I)(); data=b[st:0x7a0];buf=(ctypes.c_ubyte*len(data)).from_buffer_copy(data);n=lib.cs_disasm(h,buf,len(data),st,0,ctypes.byref(arr));
 print('\nSTART',hex(st),'n',n)
 for i in range(min(n,20)): print(f'{arr[i].address:04x}: {arr[i].mnemonic.decode():8} {arr[i].op_str.decode()}')
 if n:lib.cs_free(arr,n)
lib.cs_close(ctypes.byref(h))