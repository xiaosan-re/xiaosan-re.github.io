#include <stdint.h>

static uint32_t token_for(uint32_t a)
{
    uint32_t x = a ^ UINT32_C(0x87f7daef);
    x = (x ^ (x >> 16)) * UINT32_C(0x7feb352d);
    x = (x ^ (x >> 15)) * UINT32_C(0x846ca68b);
    return x ^ (x >> 16);
}

static uint32_t has_coupon(uint32_t a)
{
    uint32_t x = a + UINT32_C(0x7f70ea69);
    x = (x ^ (x >> 16)) * UINT32_C(0x7feb352d);
    x = (x ^ (x >> 15)) * UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return (x & 7u) == 3u;
}

uint32_t recovered(uint32_t a, uint32_t quantity,
                   uint32_t tier, uint32_t token)
{
    static const uint32_t base[3] = { 129u, 249u, 399u };
    uint32_t value;

    if (quantity - 1u >= 100u)
        return UINT32_C(0x80000001);
    if (tier > 2u)
        return UINT32_C(0x80000002);
    if (token != token_for(a))
        return UINT32_C(0x80000003);

    value = base[tier] * quantity;
    if (quantity >= 10u)
        value = (value * 85u) / 100u;
    if (has_coupon(a))
        value = (value * 95u) / 100u;
    return value;
}
