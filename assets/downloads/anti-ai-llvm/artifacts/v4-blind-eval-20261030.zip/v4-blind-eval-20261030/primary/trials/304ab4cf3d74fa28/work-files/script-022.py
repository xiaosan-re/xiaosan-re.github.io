import ctypes.util
for n in ['opcodes','bfd','LLVM-19','LLVM-20']:
 print(n,ctypes.util.find_library(n))