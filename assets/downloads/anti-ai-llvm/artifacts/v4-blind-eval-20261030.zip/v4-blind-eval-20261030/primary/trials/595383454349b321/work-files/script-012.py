import struct
D=open('target.so','rb').read()
for a in range(0x456c,0x46fc,4):
 w=struct.unpack_from('<I',D,a)[0]
 print(f'{a:04x}: {w:08x}')