import struct,base64,textwrap
D=open('target.so','rb').read();START=0x45c0;END=0x62d4
sx=lambda v,n:v-(1<<n) if v&(1<<(n-1)) else v
def bm(w):
 sf=w>>31;M=64 if sf else 32;N=(w>>22)&1;r=(w>>16)&63;s=(w>>10)&63;q=(N<<6)|((~s)&63);ln=q.bit_length()-1;lv=(1<<ln)-1;S=s&lv;R=r&lv;es=1<<ln;e=(1<<(S+1))-1;R%=es;e=((e>>R)|(e<<(es-R)))&((1<<es)-1);o=0
 for i in range(0,M,es):o|=e<<i
 return o
def target(a,imm,bits):return (a+sx(imm,bits)*4-START)//4
def rec(a,w):
 # record op,d,n,m,a,q,imm
 if (w&0xfc000000) in (0x14000000,0x94000000):
  if (w>>31)&1:return (42,0,0,0,0,0,0) # dirty helper only in retained range
  return (35,0,0,0,0,0,target(a,w&0x3ffffff,26))
 if w&0xff000010==0x54000000:return (36,0,0,0,0,w&15,target(a,(w>>5)&0x7ffff,19))
 if w&0x7e000000==0x34000000:return (37, w&31,0,0,(w>>24)&1,w>>31,target(a,(w>>5)&0x7ffff,19))
 if w&0x7e000000==0x36000000:return (38,w&31,0,0,(w>>24)&1,((w>>31)&1)*32+((w>>19)&31),target(a,(w>>5)&0x3fff,14))
 if w==0xd65f03c0:return (40,0,0,0,0,0,0)
 if w&0x1f800000==0x12800000:
  return ({2:1,3:2,0:3}[(w>>29)&3],w&31,0,0,w>>31,((w>>21)&3)*16,(w>>5)&0xffff)
 if w&0x1f000000==0x11000000:
  sf=w>>31;op=(w>>30)&1;S=(w>>29)&1;opc={(0,0):4,(1,0):5,(0,1):6,(1,1):7}[op,S];imm=((w>>10)&0xfff)<<(12 if (w>>22)&1 else 0)
  return (opc,w&31,(w>>5)&31,0,sf,0,imm)
 if w&0x1f800000==0x12000000:
  m=bm(w)
  if m>>32:raise Exception(('64mask',hex(a)))
  return (8+((w>>29)&3),w&31,(w>>5)&31,0,w>>31,0,m)
 if w&0x1f800000==0x13000000:
  sf=w>>31;opc=(w>>29)&3;R=(w>>16)&63;S=(w>>10)&63
  if opc==2 and S==(63 if sf else 31):return (12,w&31,(w>>5)&31,0,sf,R,0)
  if opc==0 and sf and R==0 and S==31:return (13,w&31,(w>>5)&31,0,0,0,0)
  raise Exception(('bf',hex(a)))
 if w&0x1f000000==0x0a000000:
  opc=(w>>29)&3;inv=(w>>21)&1
  # opcodes and/or/xor/ands; inversion encoded a bit1
  return ([14,15,16,17][opc],w&31,(w>>5)&31,(w>>16)&31,w>>31,(((w>>22)&3)<<6)|((w>>10)&63),inv)
 if w&0x1f000000==0x0b000000:
  op=(w>>30)&1;S=(w>>29)&1
  return ({(0,0):18,(1,0):19,(0,1):20,(1,1):21}[op,S],w&31,(w>>5)&31,(w>>16)&31,w>>31,(((w>>22)&3)<<6)|((w>>10)&63),0)
 if w&0x1f000000==0x1b000000:return (23 if (w>>15)&1 else 22,w&31,(w>>5)&31,(w>>16)&31,w>>31,(w>>10)&31,0)
 if w&0x1fe00000==0x1ac00000:
  mp={2:24,3:25,8:26,9:27,10:28,11:29};return (mp[(w>>10)&63],w&31,(w>>5)&31,(w>>16)&31,w>>31,0,0)
 if w&0x1fe00000==0x1a800000:
  subtype=(((w>>30)&1)<<1)|((w>>10)&1)
  return (30,w&31,(w>>5)&31,(w>>16)&31,w>>31,(subtype<<4)|((w>>12)&15),0)
 if w&0x3b000000==0x39000000:
  size=(w>>30)&3;load=(w>>22)&1;return (31 if load else 32,w&31,(w>>5)&31,0,size,0,((w>>10)&0xfff)<<size)
 if w&0x3b200000==0x38000000:
  size=(w>>30)&3;load=(w>>22)&1;return (31 if load else 32,w&31,(w>>5)&31,0,size,0,sx((w>>12)&0x1ff,9)&0xffffffff)
 if w&0x3b200c00==0x38200800:
  size=(w>>30)&3;load=(w>>22)&1;opt=(w>>13)&7;sc=(w>>12)&1;rn=(w>>5)&31
  assert load and size==2 and opt==6 and sc==1
  return (33,w&31,rn,(w>>16)&31,0 if rn==19 else 1,0,0)
 if w&0x3a000000==0x28000000:
  sf=w>>31;load=(w>>22)&1;assert load
  return (34,w&31,(w>>5)&31,(w>>10)&31,sf,0,sx((w>>15)&0x7f,7)*(8 if sf else 4)&0xffffffff)
 if w==0xd503201f:return (0,0,0,0,0,0,0)
 if a==0x552c:return (41,19,0,0,0,0,0)
 if a==0x5508:return (42,0,0,0,0,0,0)
 if a in (0x550c,0x5514):return (0,0,0,0,0,0,0)
 raise Exception(('unknown',hex(a),hex(w)))
R=[]
for a in range(START,END,4):R.append(rec(a,struct.unpack_from('<I',D,a)[0]))
raw=b''.join(struct.pack('<6BI',*r) for r in R)
rb64=base64.b64encode(raw).decode();tb64=base64.b64encode(D[0x2d0:0xfc0]).decode()
def lits(s):return '\n'.join('"'+x+'"' for x in textwrap.wrap(s,120))
src=r'''#include <stdint.h>
#include <stddef.h>
static const char T[]=
'''+lits(tb64)+r''';
static const char I[]=
'''+lits(rb64)+r''';
static unsigned vv(char x){return x>='A'&&x<='Z'?x-'A':x>='a'&&x<='z'?x-'a'+26:x>='0'&&x<='9'?x-'0'+52:x=='+'?62:63;}
static uint8_t q(const char*s,size_t k){unsigned g=(unsigned)(k/3)*4,r=(unsigned)(k%3),a=vv(s[g]),b=vv(s[g+1]),c=vv(s[g+2]),d=vv(s[g+3]);return r==0?(uint8_t)((a<<2)|(b>>4)):r==1?(uint8_t)((b<<4)|(c>>2)):(uint8_t)((c<<6)|d);}
static uint32_t tw(uint32_t n){size_t k=(size_t)n*4;return(uint32_t)q(T,k)|((uint32_t)q(T,k+1)<<8)|((uint32_t)q(T,k+2)<<16)|((uint32_t)q(T,k+3)<<24);}
static uint32_t L32(uint8_t*m,uint64_t a){return(uint32_t)m[a]|((uint32_t)m[a+1]<<8)|((uint32_t)m[a+2]<<16)|((uint32_t)m[a+3]<<24);}
static uint64_t L64(uint8_t*m,uint64_t a){return(uint64_t)L32(m,a)|((uint64_t)L32(m,a+4)<<32);}
static void S32(uint8_t*m,uint64_t a,uint32_t v){m[a]=v;m[a+1]=v>>8;m[a+2]=v>>16;m[a+3]=v>>24;}
static void S64(uint8_t*m,uint64_t a,uint64_t v){S32(m,a,(uint32_t)v);S32(m,a+4,(uint32_t)(v>>32));}
static uint64_t R(uint64_t*x,unsigned n,unsigned sf){return n==31?0:sf?x[n]:(uint32_t)x[n];}
static uint64_t SH(uint64_t v,unsigned z,unsigned sf){unsigned t=z>>6,n=z&63,b=sf?64:32;n&=b-1;v=sf?v:(uint32_t)v;if(!t)return sf?v<<n:(uint32_t)v<<n;if(t==1)return v>>n;if(t==2)return sf?(uint64_t)((int64_t)v>>n):(uint32_t)((int32_t)v>>n);return n?sf?(v>>n)|(v<<(64-n)):(uint32_t)(((uint32_t)v>>n)|((uint32_t)v<<(32-n))):v;}
static int CC(unsigned c,unsigned n,unsigned z,unsigned k,unsigned v){switch(c){case 0:return z;case 1:return!z;case 2:return k;case 3:return!k;case 4:return n;case 5:return!n;case 6:return v;case 7:return!v;case 8:return k&&!z;case 9:return!k||z;case 10:return n==v;case 11:return n!=v;case 12:return!z&&n==v;case 13:return z||n!=v;case 14:return 1;default:return 0;}}
uint32_t recovered(uint32_t a0,uint32_t a1,uint32_t a2,uint32_t a3){uint64_t x[31]={0},sp=0x3fd0,A,B,Y,ad;uint8_t m[0x5000]={0};uint32_t pc=0,im;unsigned o,d,n,r,f,z,N=0,Z=0,C=0,V=0,bits;int32_t si;x[29]=0x4000;x[19]=a3;x[20]=a2;x[21]=a1;x[22]=a0;
for(;;){size_t k=(size_t)pc*10;o=q(I,k);d=q(I,k+1);n=q(I,k+2);r=q(I,k+3);f=q(I,k+4);z=q(I,k+5);im=(uint32_t)q(I,k+6)|((uint32_t)q(I,k+7)<<8)|((uint32_t)q(I,k+8)<<16)|((uint32_t)q(I,k+9)<<24);pc++;bits=f?64:32;
#define W(v) do{if(d!=31)x[d]=f?(uint64_t)(v):(uint32_t)(v);}while(0)
#define FLAGS(v,aa,bb,sub) do{Y=f?(uint64_t)(v):(uint32_t)(v);N=(unsigned)(Y>>(bits-1));Z=!Y;if(sub){C=(aa)>=(bb);V=(unsigned)((((aa)^(bb))&((aa)^Y))>>(bits-1))&1;}else{C=Y<(aa);V=(unsigned)((~((aa)^(bb))&((aa)^Y))>>(bits-1))&1;}}while(0)
switch(o){case 0:break;case 1:W((uint64_t)im<<z);break;case 2:A=R(x,d,f);A=(A&~((uint64_t)0xffff<<z))|((uint64_t)im<<z);W(A);break;case 3:W(~((uint64_t)im<<z));break;
case 4:case 5:case 6:case 7:A=n==31?sp:R(x,n,f);B=im;Y=(o==5||o==7)?A-B:A+B;if(o>=6)FLAGS(Y,A,B,o==7);if(d==31){if(o<6)sp=Y;}else W(Y);break;
case 8:W(R(x,n,f)&im);break;case 9:W(R(x,n,f)|im);break;case 10:W(R(x,n,f)^im);break;case 11:Y=R(x,n,f)&im;W(Y);N=(unsigned)(Y>>(bits-1));Z=!Y;C=V=0;break;case 12:W(R(x,n,f)>>z);break;case 13:W((uint64_t)(int64_t)(int32_t)R(x,n,0));break;
case 14:case 15:case 16:case 17:A=R(x,n,f);B=SH(R(x,r,f),z,f);if(im)B=~B;Y=o==14||o==17?A&B:o==15?A|B:A^B;W(Y);if(o==17){N=(unsigned)((f?Y:(uint32_t)Y)>>(bits-1));Z=!(f?Y:(uint32_t)Y);C=V=0;}break;
case 18:case 19:case 20:case 21:A=R(x,n,f);B=SH(R(x,r,f),z,f);Y=(o==19||o==21)?A-B:A+B;if(o>=20)FLAGS(Y,A,B,o==21);W(Y);break;case 22:W(R(x,n,f)*R(x,r,f)+R(x,z,f));break;case 23:W(R(x,z,f)-R(x,n,f)*R(x,r,f));break;
case 24:A=R(x,n,f);B=R(x,r,f);W(B?A/B:0);break;case 25:A=R(x,n,f);B=R(x,r,f);if(!B)Y=0;else if(!f)Y=(uint32_t)((int64_t)(int32_t)A/(int64_t)(int32_t)B);else if(A==0x8000000000000000ULL&&B==~0ULL)Y=A;else Y=(uint64_t)((int64_t)A/(int64_t)B);W(Y);break;
case 26:case 27:case 28:case 29:A=R(x,n,f);B=R(x,r,f)&(bits-1);if(o==26)Y=A<<B;else if(o==27)Y=A>>B;else if(o==28)Y=f?(uint64_t)((int64_t)A>>B):(uint32_t)((int32_t)A>>B);else Y=B?(f?(A>>B)|(A<<(64-B)):(uint32_t)(((uint32_t)A>>B)|((uint32_t)A<<(32-B)))):A;W(Y);break;
case 30:A=R(x,n,f);B=R(x,r,f);switch(z>>4){case 1:B++;break;case 2:B=~B;break;case 3:B=(uint64_t)-B;}W(CC(z&15,N,Z,C,V)?A:B);break;
case 31:si=(int32_t)im;ad=(n==31?sp:x[n])+(int64_t)si;if(f==0)W(m[ad]);else if(f==1)W((uint16_t)(m[ad]|m[ad+1]<<8));else if(f==2)W(L32(m,ad));else W(L64(m,ad));break;case 32:si=(int32_t)im;ad=(n==31?sp:x[n])+(int64_t)si;A=R(x,d,f==3);if(f==0)m[ad]=(uint8_t)A;else if(f==1){m[ad]=A;m[ad+1]=A>>8;}else if(f==2)S32(m,ad,(uint32_t)A);else S64(m,ad,A);break;
case 33:W(f?L32(m,x[n]+(int64_t)(int32_t)R(x,r,0)*4):tw((uint32_t)R(x,r,0)));break;case 34:si=(int32_t)im;ad=(n==31?sp:x[n])+(int64_t)si;if(d!=31)x[d]=f?L64(m,ad):L32(m,ad);if(r!=31)x[r]=f?L64(m,ad+(f?8:4)):L32(m,ad+4);break;
case 35:pc=im;break;case 36:if(CC(z,N,Z,C,V))pc=im;break;case 37:if((R(x,d,z)==0)==(!f))pc=im;break;case 38:if((((R(x,d,z>>5)>>(z&63))&1)!=0)==(f!=0))pc=im;break;case 40:return(uint32_t)x[0];case 41:x[d]=0;break;default:return 0x800000ffu;}
#undef FLAGS
#undef W
}}
'''
open('compact.c','w').write(src)
print('records',len(R),'irbytes',len(raw),'source',len(src),'table64',len(tb64),'ir64',len(rb64))