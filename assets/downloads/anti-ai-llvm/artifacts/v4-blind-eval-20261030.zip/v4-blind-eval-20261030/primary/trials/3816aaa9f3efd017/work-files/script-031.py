def h(a):
 x=(a^0x87f7daef)&0xffffffff
 x=((x^(x>>16))*0x7feb352d)&0xffffffff
 x=((x^(x>>15))*0x846ca68b)&0xffffffff
 return (x^(x>>16))&0xffffffff
for a in [0,1,149,279,409,0xffffffff]:print(a,hex(h(a)))