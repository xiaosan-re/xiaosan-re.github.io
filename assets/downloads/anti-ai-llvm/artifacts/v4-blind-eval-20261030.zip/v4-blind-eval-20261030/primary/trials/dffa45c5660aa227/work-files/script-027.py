def adr(a,w):
 immlo=(w>>29)&3; immhi=(w>>5)&0x7ffff; imm=immhi<<2|immlo; imm-=1<<21 if imm&(1<<20) else 0
 return a+imm, w&31
for a,w in [(0x552c,0x10fd6d2f)]: print(adr(a,w))
w=0xb86cd9f0
print('size',w>>30,'opc',(w>>22)&3,'rm',(w>>16)&31,'option',(w>>13)&7,'S',(w>>12)&1,'rn',(w>>5)&31,'rt',w&31)
# Other unknowns frequency around handlers
import struct,collections
b=open('target.so','rb').read(); c=collections.Counter()
for a in range(0x551c,0x62a0,4): c[struct.unpack_from('<I',b,a)[0]&0xff000000]+=1
print(c)