# Static AArch64 decoder for instruction classes used by the exported range.
import struct
D=open('target.so','rb').read()
def sx(x,n): return x-(1<<n) if x>>(n-1) else x
def reg(n,sf=0,sp=False):
 if n==31:return ('sp' if sp else ('xzr' if sf else 'wzr'))
 return ('x' if sf else 'w')+str(n)
def dec(a,w):
 # branches
 if w&0xfc000000 in (0x14000000,0x94000000):
  dst=a+sx(w&0x3ffffff,26)*4; return ('bl' if w>>31 else 'b')+f' 0x{dst:x}'
 if w&0xff000010==0x54000000:
  cs=['eq','ne','cs','cc','mi','pl','vs','vc','hi','ls','ge','lt','gt','le','al','nv']; return f'b.{cs[w&15]} 0x{a+sx((w>>5)&0x7ffff,19)*4:x}'
 if w&0x7e000000==0x34000000:
  sf=w>>31; nz=(w>>24)&1; return f'cb{"n" if nz else ""}z {reg(w&31,sf)}, 0x{a+sx((w>>5)&0x7ffff,19)*4:x}'
 if w&0x7e000000==0x36000000:
  nz=(w>>24)&1; bit=((w>>31)&1)*32+((w>>19)&31); return f'tb{"n" if nz else ""}z {reg(w&31,w>>31)}, #{bit}, 0x{a+sx((w>>5)&0x3fff,14)*4:x}'
 if w==0xd65f03c0:return 'ret'
 # move wide
 if w&0x1f800000==0x12800000:
  sf=w>>31; opc=(w>>29)&3; names={0:'movn',2:'movz',3:'movk'}; imm=(w>>5)&0xffff; sh=((w>>21)&3)*16
  return f'{names.get(opc,"mov?")} {reg(w&31,sf)}, #0x{imm:x}, lsl #{sh}'
 # add/sub immediate
 if w&0x1f000000==0x11000000:
  sf=w>>31; op=(w>>30)&1; S=(w>>29)&1; imm=((w>>10)&0xfff) << (12 if (w>>22)&1 else 0); rn=(w>>5)&31; rd=w&31
  name=('sub' if op else 'add')+('s' if S else '')
  if S and rd==31:name='cmp'
  return f'{name} '+(f'{reg(rn,sf,True)}, #0x{imm:x}' if name=='cmp' else f'{reg(rd,sf,not S)}, {reg(rn,sf,True)}, #0x{imm:x}')
 # logical immediate (don't decode imm mask)
 if w&0x1f800000==0x12000000:
  sf=w>>31; opc=(w>>29)&3; rn=(w>>5)&31; rd=w&31; names=['and','orr','eor','ands']; name=names[opc]
  return f'{name} {reg(rd,sf)}, {reg(rn,sf)}, #BITMASK(N={(w>>22)&1},r={(w>>16)&63},s={(w>>10)&63})'
 # bitfield
 if w&0x1f800000==0x13000000:
  sf=w>>31; opc=(w>>29)&3; names={0:'sbfm',1:'bfm',2:'ubfm'}
  return f'{names.get(opc,"bfm?")} {reg(w&31,sf)}, {reg((w>>5)&31,sf)}, #{(w>>16)&63}, #{(w>>10)&63}'
 # extract
 if w&0x1f800000==0x13800000:
  sf=w>>31; return f'extr {reg(w&31,sf)}, {reg((w>>16)&31,sf)}, {reg((w>>5)&31,sf)}, #{(w>>10)&63}'
 # logical shifted register
 if w&0x1f000000==0x0a000000:
  sf=w>>31; opc=(w>>29)&3; N=(w>>21)&1; names={(0,0):'and',(0,1):'bic',(1,0):'orr',(1,1):'orn',(2,0):'eor',(2,1):'eon',(3,0):'ands',(3,1):'bics'}; name=names[opc,N]
  sh=['lsl','lsr','asr','ror'][(w>>22)&3]; imm=(w>>10)&63
  return f'{name} {reg(w&31,sf)}, {reg((w>>5)&31,sf)}, {reg((w>>16)&31,sf)}, {sh} #{imm}'
 # add/sub shifted register
 if w&0x1f000000==0x0b000000:
  sf=w>>31; op=(w>>30)&1; S=(w>>29)&1; name=('sub' if op else 'add')+('s' if S else ''); rd=w&31; rn=(w>>5)&31; rm=(w>>16)&31; sh=['lsl','lsr','asr','?'][(w>>22)&3]; imm=(w>>10)&63
  if S and rd==31:name='cmp'
  return f'{name} '+(f'{reg(rn,sf)}, {reg(rm,sf)}, {sh} #{imm}' if name=='cmp' else f'{reg(rd,sf)}, {reg(rn,sf)}, {reg(rm,sf)}, {sh} #{imm}')
 # madd/msub
 if w&0x1f000000==0x1b000000:
  sf=w>>31; sub=(w>>15)&1; return f'{"msub" if sub else "madd"} {reg(w&31,sf)}, {reg((w>>5)&31,sf)}, {reg((w>>16)&31,sf)}, {reg((w>>10)&31,sf)}'
 # data processing 2-source
 if w&0x1fe00000==0x1ac00000:
  sf=w>>31; op=(w>>10)&0x3f; names={2:'udiv',3:'sdiv',8:'lslv',9:'lsrv',10:'asrv',11:'rorv',16:'crc32b',17:'crc32h',18:'crc32w'}
  return f'{names.get(op,"dp2_"+str(op))} {reg(w&31,sf)}, {reg((w>>5)&31,sf)}, {reg((w>>16)&31,sf)}'
 # conditional select
 if w&0x1fe00000==0x1a800000:
  sf=w>>31; op=(w>>30)&1; o2=(w>>10)&1; names={(0,0):'csel',(0,1):'csinc',(1,0):'csinv',(1,1):'csneg'}; cs=['eq','ne','cs','cc','mi','pl','vs','vc','hi','ls','ge','lt','gt','le','al','nv']
  return f'{names[op,o2]} {reg(w&31,sf)}, {reg((w>>5)&31,sf)}, {reg((w>>16)&31,sf)}, {cs[(w>>12)&15]}'
 # ldr/str common unsigned immediate
 if w&0x3b000000==0x39000000:
  size=(w>>30)&3; load=(w>>22)&1; rn=(w>>5)&31; rt=w&31; imm=((w>>10)&0xfff)<<size
  return f'{"ldr" if load else "str"}{["b","h","",""][size]} {reg(rt,1 if size==3 else 0)}, [{reg(rn,1,True)}, #0x{imm:x}]'
 # unscaled/pre/post
 if w&0x3b200000==0x38000000:
  size=(w>>30)&3; load=(w>>22)&1; mode=(w>>10)&3; imm=sx((w>>12)&0x1ff,9); rn=(w>>5)&31; rt=w&31
  return f'{"ldr" if load else "str"}{["b","h","",""][size]} {reg(rt,1 if size==3 else 0)}, [{reg(rn,1,True)}, #{imm}] mode{mode}'
 # pair
 if w&0x3a000000==0x28000000:
  sf=(w>>31)&1; load=(w>>22)&1; imm=sx((w>>15)&0x7f,7)*(8 if sf else 4); return f'{"ldp" if load else "stp"} {reg(w&31,sf)}, {reg((w>>10)&31,sf)}, [{reg((w>>5)&31,1,True)}, #{imm}]'
 return f'.word 0x{w:08x}'
for a in range(0x4588,0x46f0,4):
 w=struct.unpack_from('<I',D,a)[0];print(f'{a:04x}: {dec(a,w)}')