#include <stdint.h>

typedef struct {
    uint8_t e, dst, a, b, c, bits, next, alt;
    uint32_t imm;
} Row;

static const uint32_t entry_state[13] = {
    0x33458947u,0x669d9c25u,0xe7e73955u,0xa9439f3cu,
    0x7795f82du,0x116765fau,0x4e535865u,0xae096f38u,
    0xb43114dau,0xbebf27bdu,0x7b3db69bu,0x002b7f9bu,
    0xf559507du
};

static const Row prog[92] = {
{ 0,33,25,25,25,32, 1, 0,0xffffff9bu},
{ 0,43,25,25,25,32, 2, 0,0xffffff9cu},
{ 0,19,25,25,25,32, 3, 0,0x00000002u},
{ 0,32,25,25,25,32, 4, 0,0x87f7daefu},
{ 0,38,25,25,25,32, 5, 0,0x00000010u},
{ 0, 5,25,25,25,32, 6, 0,0x7feb352du},
{ 0,41,25,25,25,32, 7, 0,0x0000000fu},
{ 0, 6,25,25,25,32, 8, 0,0x846ca68bu},
{ 0,55,25,25,25,32, 9, 0,0x00000001u},
{ 0,39,25,25,25,32,10, 0,0x000000f9u},
{ 0,44,25,25,25,32,11, 0,0x0000018fu},
{ 0, 9,25,25,25,32,12, 0,0x00000000u},
{ 0,50,25,25,25,32,13, 0,0x00000081u},
{ 0,45,25,25,25,32,14, 0,0x00000009u},
{ 0,59,25,25,25,32,15, 0,0x00000055u},
{ 0,67,25,25,25,32,16, 0,0x00000064u},
{ 0,14,25,25,25,32,17, 0,0x7f70ea69u},
{ 0, 2,25,25,25,32,18, 0,0x00000007u},
{ 0,22,25,25,25,32,19, 0,0x00000003u},
{ 0,63,25,25,25,32,20, 0,0x0000005fu},
{ 0,28,25,25,25,32,21, 0,0x80000001u},
{ 0,30,25,25,25,32,22, 0,0x80000002u},
{ 0,64,25,25,25,32,23, 0,0x80000003u},
{ 1,25,25,25,25,32,37, 0,0x00000000u},
{ 2,25,60,25,25,32,25, 0,0x00000000u},
{ 3,12,25,14,25,32,26, 0,0x00000000u},
{ 4, 0,12,38,25,32,27, 0,0x00000000u},
{ 5,52, 0,12,25,32,28, 0,0x00000000u},
{ 6,17,52, 5,25,32,29, 0,0x00000000u},
{ 4, 8,17,41,25,32,30, 0,0x00000000u},
{ 5,53, 8,17,25,32,31, 0,0x00000000u},
{ 6,11,53, 6,25,32,32, 0,0x00000000u},
{ 4,56,11,38,25,32,33, 0,0x00000000u},
{ 5,62,56,11,25,32,34, 0,0x00000000u},
{ 7,69,62, 2,25,32,35, 0,0x00000000u},
{ 8, 3,69,22,25,32,36, 0,0x00000020u},
{ 9,25, 3,25,25, 1,88,70,0x00000000u},
{ 3,48,54,33,25,32,38, 0,0x00000000u},
{ 8,10,48,43,25,32,39, 0,0x00000024u},
{ 9,25,10,25,25, 1,79,83,0x00000000u},
{ 6,47,57,59,25,32,41, 0,0x00000000u},
{10,46,47,67,25,32,42, 0,0x00000000u},
{ 1,25,25,25,25,32,67, 0,0x00000000u},
{ 8,34,58,55,25,32,44, 0,0x00000020u},
{11,61,34,39,44,32,45, 0,0x00000000u},
{ 8,20,58, 9,25,32,46, 0,0x00000020u},
{11,35,20,50,61,32,47, 0,0x00000000u},
{ 6,57,35,54,25,32,48, 0,0x00000000u},
{ 8,15,54,45,25,32,49, 0,0x00000022u},
{ 9,25,15,25,25, 1,82,89,0x00000000u},
{ 5,13,25,32,25,32,51, 0,0x00000000u},
{ 4,36,13,38,25,32,52, 0,0x00000000u},
{ 5,31,36,13,25,32,53, 0,0x00000000u},
{ 6,40,31, 5,25,32,54, 0,0x00000000u},
{ 4,66,40,41,25,32,55, 0,0x00000000u},
{ 5, 1,66,40,25,32,56, 0,0x00000000u},
{ 6, 4, 1, 6,25,32,57, 0,0x00000000u},
{ 4,16, 4,38,25,32,58, 0,0x00000000u},
{ 5,18,16, 4,25,32,59, 0,0x00000000u},
{ 8,24,29,18,25,32,60, 0,0x00000020u},
{ 9,25,24,25,25, 1,66,85,0x00000000u},
{ 8,65,58,19,25,32,62, 0,0x00000022u},
{ 9,25,65,25,25, 1,73,84,0x00000000u},
{ 6,26,23,63,25,32,64, 0,0x00000000u},
{10,68,26,67,25,32,65, 0,0x00000000u},
{ 1,25,25,25,25,32,76, 0,0x00000000u},
{ 1,25,25,25,25,32,43, 0,0x00000000u},
{12,27,46,25,25,32,68, 0,0x00000000u},
{12,23,27,25,25,32,69, 0,0x00000000u},
{ 1,25,25,25,25,32,25, 0,0x00000000u},
{12, 7,23,25,25,32,71, 0,0x00000000u},
{12,60, 7,25,25,32,72, 0,0x00000000u},
{ 1,25,25,25,25,32,24, 0,0x00000000u},
{12,51,30,25,25,32,74, 0,0x00000000u},
{12,60,51,25,25,32,75, 0,0x00000000u},
{ 1,25,25,25,25,32,24, 0,0x00000000u},
{12,49,68,25,25,32,77, 0,0x00000000u},
{12,60,49,25,25,32,78, 0,0x00000000u},
{ 1,25,25,25,25,32,24, 0,0x00000000u},
{12,37,28,25,25,32,80, 0,0x00000000u},
{12,60,37,25,25,32,81, 0,0x00000000u},
{ 1,25,25,25,25,32,24, 0,0x00000000u},
{ 1,25,25,25,25,32,40, 0,0x00000000u},
{ 1,25,25,25,25,32,61, 0,0x00000000u},
{ 1,25,25,25,25,32,50, 0,0x00000000u},
{12,21,64,25,25,32,86, 0,0x00000000u},
{12,60,21,25,25,32,87, 0,0x00000000u},
{ 1,25,25,25,25,32,24, 0,0x00000000u},
{ 1,25,25,25,25,32,63, 0,0x00000000u},
{12,42,57,25,25,32,90, 0,0x00000000u},
{12,23,42,25,25,32,91, 0,0x00000000u},
{ 1,25,25,25,25,32,25, 0,0x00000000u}
};

static uint32_t asr32(uint32_t x, uint32_t n) {
    n &= 31u;
    if (!n) return x;
    return (x >> n) | ((0u - (x >> 31)) << (32u - n));
}

static uint32_t sxlow(uint32_t x, uint32_t n) {
    n &= 31u;
    if (!n) return x;
    {
        uint32_t s = 1u << (n - 1u);
        return (x ^ s) - s;
    }
}

uint32_t recovered(uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3) {
    uint32_t v[72] = {0};
    uint32_t state = 0xe4a7252eu, dispatch = state;
    uint32_t q = 0, result = 0;
    uint32_t x0v = 0, x13 = 0, x14 = 0, x10 = 0, x11 = 0, x16 = 0;
    uint32_t dst = 0, bits = 0, next = 0, alt = 0;

    v[25] = a0;
    v[54] = a1;
    v[58] = a2;
    v[29] = a3;

    for (;;) {
        uint32_t den, n;
        int64_t sq;
        switch (dispatch) {
        case 0xe4a7252eu: {
            const Row *r;
            if (q >= 92u) return 0x800000ffu;
            r = &prog[q];
            dst = r->dst;
            x14 = v[r->a];
            x13 = v[r->b];
            x16 = v[r->c];
            bits = r->bits;
            next = r->next;
            alt = r->alt;
            x0v = r->imm;
            x11 = sxlow(x14, bits);
            x10 = sxlow(x13, bits);
            dispatch = entry_state[r->e];
            continue;
        }
        case 0x8d141411u:
            den = x13 ? x13 : 1u; result = x14 / den;
            state ^= 0x6862be53u; break;
        case 0xa4aafb03u:
            switch (x0v) {
            case 32: result = (x14 == x13); break;
            case 33: result = (x14 != x13); break;
            case 34: result = (x14 >  x13); break;
            case 35: result = (x14 >= x13); break;
            case 36: result = (x14 <  x13); break;
            case 37: result = (x14 <= x13); break;
            case 38: result = ((int32_t)x11 >  (int32_t)x10); break;
            case 39: result = ((int32_t)x11 >= (int32_t)x10); break;
            case 40: result = ((int32_t)x11 <  (int32_t)x10); break;
            case 41: result = ((int32_t)x11 <= (int32_t)x10); break;
            default: result = 0; break;
            }
            state ^= 0x41dc5141u; break;
        case 0xa5af7ad0u: result = x14 ^ x13; state ^= 0x40d9d092u; break;
        case 0xc3b21eb9u: result = x14 + x13; state ^= 0x26c4b4fbu; break;
        case 0xd5c9fd7fu: return x14;
        case 0xd845e9c0u: result = x14 * x13; state ^= 0x3d334382u; break;
        case 0xd89da86fu: result = sxlow(x14, x0v); state ^= 0x3deb022du; break;
        case 0xdb645777u: q = next; state ^= 0x3fc37259u; break;
        case 0xe576aa42u:
            n = bits & 31u;
            v[dst] = result & (n ? ((1u << n) - 1u) : 0xffffffffu);
            q = next;
            state ^= 0x01d18f6cu;
            break;
        case 0xe8352f77u: result = x14 << (x13 & 31u); state ^= 0x0d438535u; break;
        case 0xf07e66ecu: result = x14 >> (x13 & 31u); state ^= 0x1508ccaeu; break;
        case 0xf2f756afu: result = x14 & x13; state ^= 0x1781fcedu; break;
        case 0xfb105caeu: q = x14 ? next : alt; state ^= 0x1fb77980u; break;
        case 0x02b508d0u: result = x14 - x13; state ^= 0xe7c3a292u; break;
        case 0x101b3929u: result = asr32(x11, x13); state ^= 0xf56d936bu; break;
        case 0x19eef2f7u:
            den = x13 ? x13 : 1u; result = x14 % den;
            state ^= 0xfc9858b5u; break;
        case 0x1b209ed8u:
            den = x10;
            if (!den || (x11 == 0x80000000u && den == 0xffffffffu)) den = 1u;
            sq = (int64_t)(int32_t)x11 / (int64_t)(int32_t)den;
            result = x11 - (uint32_t)(sq * (int64_t)(int32_t)den);
            state ^= 0xfe56349au; break;
        case 0x1f0a6b75u: result = x14 | x13; state ^= 0xfa7cc137u; break;
        case 0x26140179u: result = x0v; state ^= 0xc362ab3bu; break;
        case 0x34b8620eu:
            den = x10;
            if (!den || (x11 == 0x80000000u && den == 0xffffffffu)) den = 1u;
            sq = (int64_t)(int32_t)x11 / (int64_t)(int32_t)den;
            result = (uint32_t)sq;
            state ^= 0xd1cec84cu; break;
        case 0x4d4cb924u: result = x14; state ^= 0xa83a1366u; break;
        case 0x4dc6ca5bu: result = x14 ? x13 : x16; state ^= 0xa8b06019u; break;
        case 0x69d12894u: result = x14; state ^= 0x8ca782d6u; break;
        case 0x7aad0288u: return 0x800000ffu;

        case 0x90c77a34u: state ^= 0x0c920a59u; break;
        case 0x9cdfc8d2u: state ^= 0xfd49d7d9u; break;
        case 0xa9439f3cu: state ^= 0x27153b97u; break;
        case 0xa9f33573u: state ^= 0xff87bbf6u; break;
        case 0xae096f38u: state ^= 0x16507381u; break;
        case 0xb43114dau: state ^= 0x400dde2du; break;
        case 0xb6494ff0u: state ^= 0x3c3a8d41u; break;
        case 0xbebf27bdu: state ^= 0x1fb77980u; break;
        case 0xc4f5d477u: state ^= 0xe6122dfeu; break;
        case 0xe7e73955u: state ^= 0x316ed851u; break;
        case 0xeeadd132u: state ^= 0xd01f4720u; break;
        case 0xf559507du: state ^= 0xa9eb9c0au; break;
        case 0x002b7f9bu: state ^= 0xa961ef75u; break;
        case 0x0fa18f72u: state ^= 0x8d760dbau; break;
        case 0x116765fau: state ^= 0x41085ffeu; break;
        case 0x33458947u: state ^= 0xc2b32457u; break;
        case 0x4e535865u: state ^= 0x3ce2cceeu; break;
        case 0x56f3e31eu: state ^= 0xf4bc1c07u; break;
        case 0x5d495bc8u: state ^= 0xfbad4e5bu; break;
        case 0x669d9c25u: state ^= 0x3fc37259u; break;
        case 0x7795f82du: state ^= 0x14d943c2u; break;
        case 0x7b3db69bu: state ^= 0x69b3313fu; break;
        default: return 0x800000ffu;
        }
        dispatch = state;
    }
}