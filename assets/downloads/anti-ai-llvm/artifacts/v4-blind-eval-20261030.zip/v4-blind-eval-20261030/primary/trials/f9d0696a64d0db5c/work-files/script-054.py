from unicorn import *
from unicorn.arm64_const import *
import random
blob=open('target.so','rb').read()
def mix(a,seed):
 x=(a^seed)&0xffffffff;x^=x>>16;x=(x*0x7feb352d)&0xffffffff;x^=x>>15;x=(x*0x846ca68b)&0xffffffff;x^=x>>16;return x
def M(a,b,c,d):
 if ((b-1)&0xffffffff)>=100:return 0x80000001
 if c>=3:return 0x80000002
 if d!=mix(a,0x838d31dc):return 0x80000003
 v=b*[129,249,399][c]
 if b>=10:v=v*85//100
 if mix(a,0x4c55a6ee)%7==3:v=v*95//100
 return v
def E(A):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
 for i,x in enumerate(A):u.reg_write(UC_ARM64_REG_X0+i,x)
 u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000)
 def h(u,x,s,z):
  if x==0x6e74:u.reg_write(UC_ARM64_REG_X0,0);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=100000);return u.reg_read(UC_ARM64_REG_W0)
random.seed(11)
for i in range(500):
 a=random.getrandbits(32);b=random.choice([0,1,2,9,10,11,13,17,21,50,100,101,random.getrandbits(32)]);c=random.choice([0,1,2,3,4,0xffffffff]);d=mix(a,0x838d31dc) if random.randrange(2) else random.getrandbits(32);A=(a,b,c,d)
 e=E(A);m=M(*A)
 if e!=m:print('BAD',i,tuple(hex(x) for x in A),hex(e),hex(m),mix(a,0x4c55a6ee)%7);break
else:print('all 500 matched')