import shutil
for x in ['llvm-objdump','aarch64-linux-gnu-objdump','objdump','readelf','nm']:
 print(x,shutil.which(x))