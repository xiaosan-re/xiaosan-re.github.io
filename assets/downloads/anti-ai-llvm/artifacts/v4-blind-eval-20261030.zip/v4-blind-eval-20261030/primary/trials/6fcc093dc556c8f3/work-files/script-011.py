import struct
from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f); s=e.get_section_by_name('.text'); d=s.data(); a=s['sh_addr']
for off in range(0,len(d),32):
 ws=struct.unpack_from('<'+'I'*min(8,(len(d)-off)//4),d,off)
 print(f'{a+off:04x}: '+' '.join(f'{x:08x}' for x in ws))