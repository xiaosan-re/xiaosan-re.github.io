import runpy,struct,collections
ns=runpy.run_path('script-015.py'); dec=ns['dec']; D=open('target.so','rb').read()
unk=collections.Counter()
for a in range(0x456c,0x62d4,4):
 w=struct.unpack_from('<I',D,a)[0]; s=dec(a,w)
 if s.startswith('.word'): unk[w&0xffe00000]+=1
print('unknown',sum(unk.values()),'patterns',len(unk))
for k,v in unk.most_common():print(hex(k),v)
