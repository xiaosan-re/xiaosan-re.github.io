c=open('ir.lz','rb').read();o=bytearray();v=0
while len(o)<18610:
 t=c[v];v+=1
 if t<128:o.extend(c[v:v+t+1]);v+=t+1
 else:
  n=(t&127)+3;d=c[v]|c[v+1]<<8;v+=2
  for _ in range(n):o.append(o[-d])
import runpy,contextlib,io,hashlib
with contextlib.redirect_stdout(io.StringIO()):ns=runpy.run_path('script-040.py')
print(len(o),v,len(c),o==ns['raw'],hashlib.sha256(o).hexdigest())