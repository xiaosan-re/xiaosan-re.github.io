try:
 import capstone; print('capstone',capstone.__version__)
except Exception as ex: print(ex)
from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 f.seek(0x456c); b=f.read(0x1d68)
from capstone import *
md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN); md.detail=True
for i,x in enumerate(md.disasm(b,0x456c)):
 print(f'{x.address:06x}: {x.mnemonic:8} {x.op_str}')
 if i>300: break
