from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
import struct
B=0x1000000;S=0x2000000;T=0x3000000
with open('target.so','rb') as f:raw=f.read();f.seek(0);e=ELFFile(f);ps=[p for p in e.iter_segments() if p['p_type']=='PT_LOAD']
def P(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0xe000);u.mem_map(S,0x10000);u.mem_map(T,0x1000)
 for p in ps:u.mem_write(B+p['p_vaddr'],raw[p['p_offset']:p['p_offset']+p['p_filesz']])
 u.mem_write(B+0xd410,struct.pack('<II',1,0));u.reg_write(UC_ARM64_REG_SP,S+0xf000);u.reg_write(UC_ARM64_REG_LR,T)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 def h(uc,ad,sz,d):
  if ad==B+0x3be4:uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(B+0x38cc,T,count=5000)
 fp=u.reg_read(UC_ARM64_REG_X29)
 return tuple(struct.unpack('<I',u.mem_read(fp-o,4))[0] for o in (0x14,0x18,0x1c,0x20,0x24))+(u.reg_read(UC_ARM64_REG_X28)&0xffffffff,)
def vary(pos,vals):
 last=None
 for x in vals:
  a=[0,1,0,0];a[pos]=x;p=P(a)
  if p!=last:print('arg',pos,'at',x,tuple(hex(y) for y in p));last=p
vals=list(range(0,201))+[255,256,999,1000,9999,10000,10001,65535,0x7fffffff,0x80000000,0xffffffff]
for pos in range(4):vary(pos,vals)
print('DA grid')
for a in [0,1,100,1000,0x7fffffff,0xffffffff]:
 for d in [0,1,100,1000,9300,10000,0xffffffff]:
  print(a,d,hex(P((a,1,0,d))[2]))