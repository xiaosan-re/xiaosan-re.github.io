from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
import random,collections
B=0x100000;ST=0x200000;END=0x300000
with open('target.so','rb') as f:
 e=ELFFile(f); segs=[(x.header.p_vaddr,x.data()) for x in e.iter_segments() if x.header.p_type=='PT_LOAD']
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000);u.mem_map(ST,0x10000);u.mem_map(END,0x1000)
for v,d in segs:u.mem_write(B+v,d)
def run(vals):
 u.reg_write(UC_ARM64_REG_SP,ST+0x8000);u.reg_write(UC_ARM64_REG_X30,END)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),vals):u.reg_write(r,v)
 u.emu_start(B+0x32c,END,count=10000)
 return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
sets=[0,1,2,3,4,5,7,8,9,10,15,16,31,32,63,64,99,100,127,128,255,256,999,1000,0x7fffffff,0x80000000,0xffffffff]
for pos in range(4):
 print('POS',pos)
 for x in sets:
  a=[0,0,0,0];a[pos]=x;print(hex(x),hex(run(a)),end='; ')
 print()
c=collections.Counter(); ex={}
for _ in range(5000):
 a=tuple(random.getrandbits(32) for _ in range(4));o=run(a);c[o]+=1;ex.setdefault(o,a)
print('random',[(hex(k),v,tuple(hex(x) for x in ex[k])) for k,v in c.most_common(20)])
c=collections.Counter()
for _ in range(10000):
 a=tuple(random.randrange(0,101) for _ in range(4));o=run(a);c[o]+=1;ex.setdefault(o,a)
print('small',[(hex(k),v,ex[k]) for k,v in c.most_common(20)])
