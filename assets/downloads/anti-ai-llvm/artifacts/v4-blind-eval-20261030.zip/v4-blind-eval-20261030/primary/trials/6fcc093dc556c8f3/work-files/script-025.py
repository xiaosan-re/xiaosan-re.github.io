# Run one initialized emulator per quantity and print result/ratio for valid tier 0
from unicorn import *
from unicorn.arm64_const import *
B=0x100000;S=0x200000;T=0x300000;blob=open('target.so','rb').read();rr=[UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3]
def cs(a):
 x=(a^0x838d31dc)&0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x&0xffffffff
def go(q,c=0):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000);u.mem_write(B,blob[:2032]);u.mem_write(B+0x47f0,blob[0x7f0:0x8e0]);u.mem_map(S,0x10000);u.mem_map(T,0x1000);u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_LR,T)
 for r,v in zip(rr,[0,q,c,cs(0)]):u.reg_write(r,v)
 u.emu_start(B+0x32c,T,count=10000);return u.reg_read(UC_ARM64_REG_W0)
for c in range(3):
 print('tier',c)
 last=None
 for q in range(1,101):
  o=go(q,c); unit=[129,249,399][c]; ratio=o/(q*unit)
  key=round(ratio,3)
  if key!=last or q in [1,8,9,10,11,19,20,21,49,50,51,52,53,54,89,90,91,99,100]:print(q,o,f'{ratio:.6f}');last=key
