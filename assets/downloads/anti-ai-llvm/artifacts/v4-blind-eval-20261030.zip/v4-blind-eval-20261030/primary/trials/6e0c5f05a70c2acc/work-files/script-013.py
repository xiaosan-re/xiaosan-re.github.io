import subprocess
r=subprocess.run(['/usr/bin/objdump','-d','target.so'],capture_output=True,text=True)
print(r.returncode); print(r.stdout[:10000]); print(r.stderr)