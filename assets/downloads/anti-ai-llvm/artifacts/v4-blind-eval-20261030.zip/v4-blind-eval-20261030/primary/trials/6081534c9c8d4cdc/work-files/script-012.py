import ctypes
lib=ctypes.CDLL('/opt/homebrew/lib/libcapstone.dylib')
class Insn(ctypes.Structure):
 _fields_=[('id',ctypes.c_uint),('address',ctypes.c_uint64),('size',ctypes.c_uint16),('bytes',ctypes.c_ubyte*24),('mnemonic',ctypes.c_char*32),('op_str',ctypes.c_char*160),('detail',ctypes.c_void_p)]
h=ctypes.c_size_t(); print('open',lib.cs_open(1,0,ctypes.byref(h)),h.value)
with open('target.so','rb') as f:f.seek(0x38cc); data=f.read(1704)
buf=(ctypes.c_ubyte*len(data)).from_buffer_copy(data); p=ctypes.POINTER(Insn)()
lib.cs_disasm.restype=ctypes.c_size_t
n=lib.cs_disasm(h,buf,len(data),0x38cc,0,ctypes.byref(p));print('n',n)
for i in range(n):
 x=p[i]; print(f'{x.address:04x}: {x.mnemonic.decode():8} {x.op_str.decode()}')
lib.cs_free(p,n);lib.cs_close(ctypes.byref(h))