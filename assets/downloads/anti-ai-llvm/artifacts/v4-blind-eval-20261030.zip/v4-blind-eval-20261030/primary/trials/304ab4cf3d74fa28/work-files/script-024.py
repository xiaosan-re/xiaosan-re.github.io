from pathlib import Path
import struct
D=Path('target.so').read_bytes()[0x38cc:0x3f74]
conds=['eq','ne','cs','cc','mi','pl','vs','vc','hi','ls','ge','lt','gt','le','al','nv']
shifts=['lsl','lsr','asr','ror']
def reg(r,sf=0,sp=False):
 if r==31:return ('sp' if sp else ('xzr' if sf else 'wzr'))
 return ('x' if sf else 'w')+str(r)
def sx(x,n): return x-(1<<n) if x>>(n-1) else x
def dec(w,pc):
 sf=(w>>31)&1
 # B/BL
 if (w>>26) in (5,37):
  im=sx(w&0x3ffffff,26)*4; return ('bl' if w>>26==37 else 'b')+f' 0x{pc+im:x}'
 # b.cond
 if w&0xff000010==0x54000000:
  im=sx((w>>5)&0x7ffff,19)*4; return f'b.{conds[w&15]} 0x{pc+im:x}'
 # cbz/cbnz
 if w&0x7e000000==0x34000000:
  im=sx((w>>5)&0x7ffff,19)*4; nz=(w>>24)&1
  return f"cb{'n' if nz else ''}z {reg(w&31,sf)},0x{pc+im:x}"
 # move wide
 if w&0x1f800000==0x12800000:
  opc=(w>>29)&3; names={0:'movn',2:'movz',3:'movk'}; hw=(w>>21)&3; imm=(w>>5)&0xffff
  return f"{names.get(opc,'mov?')} {reg(w&31,sf)},#0x{imm:x}"+(f',lsl #{hw*16}' if hw else '')
 # logical shifted
 if w&0x1f000000==0x0a000000:
  opc=(w>>29)&3; N=(w>>21)&1; names={(0,0):'and',(0,1):'bic',(1,0):'orr',(1,1):'orn',(2,0):'eor',(2,1):'eon',(3,0):'ands',(3,1):'bics'}
  rd=w&31;rn=(w>>5)&31;rm=(w>>16)&31; sh=(w>>22)&3; amt=(w>>10)&63
  if names[opc,N]=='orr' and rn==31 and sh==0 and amt==0:return f'mov {reg(rd,sf)},{reg(rm,sf)}'
  return f'{names[opc,N]} {reg(rd,sf)},{reg(rn,sf)},{reg(rm,sf)}'+(f',{shifts[sh]} #{amt}' if amt else '')
 # add/sub imm
 if w&0x1f000000==0x11000000:
  sub=(w>>30)&1; S=(w>>29)&1; imm=(w>>10)&0xfff; imm <<= (12 if (w>>22)&1 else 0); rn=(w>>5)&31;rd=w&31
  if S and rd==31:return f'cmp {reg(rn,sf,True)},#0x{imm:x}'
  return f"{'sub' if sub else 'add'}{'s' if S else ''} {reg(rd,sf,True)},{reg(rn,sf,True)},#0x{imm:x}"
 # add/sub shifted reg
 if w&0x1f200000==0x0b000000:
  sub=(w>>30)&1; S=(w>>29)&1; rd=w&31;rn=(w>>5)&31;rm=(w>>16)&31;sh=(w>>22)&3;amt=(w>>10)&63
  if S and rd==31:return f'cmp {reg(rn,sf)},{reg(rm,sf)}'+(f',{shifts[sh]} #{amt}' if amt else '')
  return f"{'sub' if sub else 'add'}{'s' if S else ''} {reg(rd,sf)},{reg(rn,sf)},{reg(rm,sf)}"+(f',{shifts[sh]} #{amt}' if amt else '')
 # ldr/str unsigned imm
 if w&0x3b000000==0x39000000:
  size=(w>>30)&3; opc=(w>>22)&3; scale=size; imm=((w>>10)&0xfff)<<scale;rn=(w>>5)&31;rt=w&31
  nm={0:'str',1:'ldr',2:'ldrsw'}.get(opc,'ldst?'); rsf=1 if size==3 else 0
  return f'{nm} {reg(rt,rsf)},[{reg(rn,1,True)},#0x{imm:x}]'
 # ld/st unscaled/pre/post 32/64
 if w&0x3b200000==0x38000000:
  size=(w>>30)&3; opc=(w>>22)&3; imm=sx((w>>12)&0x1ff,9);mode=(w>>10)&3;rn=(w>>5)&31;rt=w&31
  nm={0:'str',1:'ldr',2:'ldrs'}.get(opc,'ldst?'); suffix={0:'ur',1:' post',3:' pre',2:' reg'}[mode]
  return f'{nm}{suffix} {reg(rt,1 if size==3 else 0)},[{reg(rn,1,True)},#{imm}]'
 # pair
 if w&0x3a000000==0x28000000:
  opc=(w>>30)&3; load=(w>>22)&1; mode=(w>>23)&3; imm=sx((w>>15)&0x7f,7)*(8 if opc==2 else 4);rt=w&31;rn=(w>>5)&31;rt2=(w>>10)&31
  return f"{'ldp' if load else 'stp'} {reg(rt,1 if opc==2 else 0)},{reg(rt2,1 if opc==2 else 0)},[{reg(rn,1,True)},#{imm}] mode{mode}"
 # madd/msub 32
 if w&0x7fe00000==0x1b000000:
  rm=(w>>16)&31;sub=(w>>15)&1;ra=(w>>10)&31;rn=(w>>5)&31;rd=w&31
  if ra==31:return f"{'mneg' if sub else 'mul'} {reg(rd,sf)},{reg(rn,sf)},{reg(rm,sf)}"
  return f"{'msub' if sub else 'madd'} {reg(rd,sf)},{reg(rn,sf)},{reg(rm,sf)},{reg(ra,sf)}"
 # ccmp imm
 if w&0x7fe00c10==0x7a400800:
  rn=(w>>5)&31;imm=(w>>16)&31;nzcv=w&15;cond=(w>>12)&15
  return f'ccmp {reg(rn,sf)},#{imm},#{nzcv},{conds[cond]}'
 # logical immediate / bitfield generic
 if w&0x1f800000==0x12000000:return f'logical_imm 0x{w:08x}'
 if w&0x1f800000==0x13000000:return f'bitfield 0x{w:08x}'
 if w&0xff000000==0xd3000000:return f'bitfield64 0x{w:08x}'
 # ldr literal
 if w&0x3b000000==0x18000000:
  im=sx((w>>5)&0x7ffff,19)*4;return f'ldr_lit {reg(w&31,sf)},[0x{pc+im:x}]'
 # ret/br/blr
 if w&0xfffffc1f==0xd65f0000:return f'ret {reg((w>>5)&31,1)}'
 if w&0xfffffc1f==0xd61f0000:return f'br {reg((w>>5)&31,1)}'
 if w&0xfffffc1f==0xd63f0000:return f'blr {reg((w>>5)&31,1)}'
 return f'.word 0x{w:08x}'
for off in range(0,len(D),4):
 w=struct.unpack_from('<I',D,off)[0]; pc=0x38cc+off
 print(f'{pc:04x}: {dec(w,pc)}')