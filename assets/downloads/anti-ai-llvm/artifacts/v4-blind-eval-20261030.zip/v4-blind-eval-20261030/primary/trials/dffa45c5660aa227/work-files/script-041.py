# Cross-check the reduced formula against a compact recovered-VM evaluator over many derived test points.
import random,struct
bdat=open('target.so','rb').read(); Cs=[0xbc479312,0x39ac5979,0xb79007c4,0x2d84cc53,0xabe8babe,0x21dd6705,0x9fc12d90,0x15351bff,0x9319c04a]
u=lambda x:x&0xffffffff
def mix(x):x=u(x^(x>>16));x=u(x*0x7feb352d);x=u(x^(x>>15));x=u(x*0x846ca68b);return u(x^(x>>16))
R=[[struct.unpack_from('<I',bdat,0x2d0+36*i+4*j)[0]^mix(u(i*0x9e3779b9)^Cs[j]) for j in range(9)] for i in range(92)]
def vm(a,b,c,d):
 r=[0]*70;r[58]=u(a);r[23]=u(b);r[27]=u(c);r[14]=u(d);p=0
 for _ in range(200):
  op,z,ai,bi,ci,im,w,nx,al=R[p];A=r[ai];B=r[bi];C=r[ci]
  if op==0x31ef8a34:o=im
  elif op==0x432b31fa:o=A
  elif op==0xa9050067:o=u(B+A)
  elif op==0x778380a7:o=u(B*A)
  elif op==0xc179bd02:o=B^A
  elif op==0xcc213f3b:o=B&A
  elif op==0x68a9af5d:o=A>>(B&31)
  elif op==0x2d296d65:
   den=1 if B==0 else C;o=0 if den==0 else A//den
  elif op==0xfd23a89f:o={32:A==B,33:A!=B,34:A>B,35:A>=B,36:A<B,37:A<=B}[im]
  elif op==0x86b9c54f:o=B if A else C
  elif op==0xd515b9c4:p=nx;continue
  elif op==0x9153976a:p=nx if A else al;continue
  elif op==0xe9855c9d:return A
  bits=w&31;r[z]=u(int(o))&(0xffffffff if bits==0 else (1<<bits)-1);p=nx
 raise RuntimeError
def direct(a,b,c,d):
 a=u(a);b=u(b);c=u(c);d=u(d)
 if not 1<=b<=100:return 0x80000001
 if c>2:return 0x80000002
 if d!=mix(a^0x838d31dc):return 0x80000003
 x=u((129 if c==0 else 249 if c==1 else 0xffffff9b)+b)
 if b>9:
  num=u(x*85);x=0 if a==0 else num//a
 if (mix(u(a+0x4c55a6ee))&7)==3:
  num=u(x*95);x=0 if a==0 else num//a
 return u(x)
qs=[]
for _ in range(10000):
 a=random.randrange(2**32);bb=random.randrange(0,130);c=random.randrange(0,6);d=mix(a^0x838d31dc) if random.randrange(2) else random.randrange(2**32);qs.append((a,bb,c,d))
for q in qs:
 x,y=vm(*q),direct(*q)
 if x!=y: print('MISMATCH',q,hex(x),hex(y));break
else: print('all matched',len(qs))
# Show several valid outputs, including zero divisor and special branch examples.
n=0
for a in range(30):
 d=mix(a^0x838d31dc)
 for bb in [1,9,10,100]:
  for c in range(3):
   if (mix(u(a+0x4c55a6ee))&7)==3 or a in (0,1,10):
    print(a,bb,c,hex(d),hex(direct(a,bb,c,d)),'special',mix(u(a+0x4c55a6ee))&7==3);n+=1
    if n>=18:raise SystemExit