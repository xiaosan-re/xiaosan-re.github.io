from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f)
 print([(s.name,hex(s['sh_addr']),hex(s['sh_offset']),s['sh_size']) for s in e.iter_sections()])
 syms=e.get_section_by_name('.dynsym').get_symbol_by_name('demo_evaluate'); print([(hex(x['st_value']),x['st_size']) for x in syms])
 s=syms[0]
 for seg in e.iter_segments():
  if seg['p_type']=='PT_LOAD' and seg['p_vaddr']<=s['st_value']<seg['p_vaddr']+seg['p_filesz']:
   f.seek(seg['p_offset']+s['st_value']-seg['p_vaddr']); d=f.read(s['st_size']); print(d.hex()); break