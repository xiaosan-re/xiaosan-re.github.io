import struct
b=open('target.so','rb').read();C=[0xbc479312,0x39ac5979,0xb79007c4,0x2d84cc53,0xabe8babe,0x21dd6705,0x9fc12d90,0x15351bff,0x9319c04a]
u=lambda x:x&0xffffffff
def h(x):x=u(x^(x>>16));x=u(x*0x7feb352d);x=u(x^(x>>15));x=u(x*0x846ca68b);return u(x^(x>>16))
for i in range(60,92):
 v=[struct.unpack_from('<I',b,0x2d0+36*i+4*j)[0]^h(u(i*0x9e3779b9)^C[j]) for j in range(9)]
 print(i,' '.join(f'{x:08x}' for x in v))