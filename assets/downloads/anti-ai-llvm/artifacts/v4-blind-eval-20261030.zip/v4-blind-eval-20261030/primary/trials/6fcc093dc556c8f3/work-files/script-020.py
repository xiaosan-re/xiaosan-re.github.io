from unicorn import *
from unicorn.arm64_const import *
BASE=0x100000;STACK=0x200000;STOP=0x300000;blob=open('target.so','rb').read();R=[getattr(__import__('unicorn.arm64_const',fromlist=['x']),f'UC_ARM64_REG_X{i}') for i in range(31)]
def em(a,stopinit=False):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0x10000);u.mem_write(BASE,blob[:2032]);u.mem_write(BASE+0x47f0,blob[0x7f0:0x8e0]);u.mem_map(STACK,0x10000);u.mem_map(STOP,0x1000);u.reg_write(UC_ARM64_REG_SP,STACK+0x8000);u.reg_write(UC_ARM64_REG_LR,STOP)
 for r,v in zip(R[:4],a):u.reg_write(r,v)
 ss=[]
 def h(uc,x,z,d):
  if x==BASE+0x4fc:
   ss.append(uc.reg_read(UC_ARM64_REG_W4))
   if stopinit and len(ss)==1:uc.emu_stop()
  if x==STOP:uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,h)
 try:u.emu_start(BASE+0x32c,STOP+4,count=10000)
 except UcError as e:return None,ss,u,e
 return u.reg_read(UC_ARM64_REG_W0),ss,u,None
for a in [0,1,2,3,4,5,0x12345678,0xffffffff]:
 _,_,u,_=em((a,1,0,0),True); d=u.reg_read(UC_ARM64_REG_W23);print('a',hex(a),'d',hex(d))
 for b in [1,10,100]:
  for c in [0,1,2,3]:
   o,s,_,e=em((a,b,c,d));print(' ',b,c,hex(o) if o is not None else e,[hex(x) for x in s])
