D=open('target.so','rb').read();
for pat in [b'/rustc',b'{"module"',b'/proc/self/status']:
 print(pat,hex(D.find(pat)),D.find(pat)-0x2d0)
# Find long printable runs after base
start=0x2d0
for i in range(start,0x452c):
 if 32<=D[i]<127 and (i==start or not(32<=D[i-1]<127)):
  j=i
  while j<0x452c and 32<=D[j]<127:j+=1
  if j-i>=20:print(hex(i),j-i,D[i:i+50]);
