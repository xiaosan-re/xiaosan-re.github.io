from unicorn import *
from unicorn.arm64_const import *
import struct,itertools,time,random
raw=open('target.so','rb').read();B=0x100000;ST=0x800000;SENT=0x900000
mu=Uc(UC_ARCH_ARM64,UC_MODE_ARM);mu.mem_map(B,0x10000);mu.mem_write(B,raw[:0x7200]);mu.mem_write(B+0xb200,raw[0x7200:0x72f0]);mu.mem_write(B+0xb2e8,struct.pack('<Q',B+0x456c));mu.mem_map(ST,0x20000);mu.mem_map(SENT,0x1000)
def hook(mu,a,s,u):
 if a==B+0x6e74:
  mu.reg_write(UC_ARM64_REG_X0,0);mu.reg_write(UC_ARM64_REG_PC,mu.reg_read(UC_ARM64_REG_LR))
 elif a==SENT:mu.emu_stop()
mu.hook_add(UC_HOOK_CODE,hook)
regs=[UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3]
def run(v):
 mu.reg_write(UC_ARM64_REG_SP,ST+0x10000);mu.reg_write(UC_ARM64_REG_LR,SENT)
 for r,x in zip(regs,v):mu.reg_write(r,x)
 mu.emu_start(B+0x456c,SENT,count=200000)
 return mu.reg_read(UC_ARM64_REG_X0)&0xffffffff
vals=[0,1,2,3,4,5,6,7,16,17,18,47,48,64,100,149,279,409,9300,10000,0xffffffff]
tests=[(x,0,0,0) for x in vals]+[(0,x,0,0) for x in vals]+[(0,0,x,0) for x in vals]+[(0,0,0,x) for x in vals]
tests += list(itertools.product([0,1,2,47],[0,1,6],[149,279,409,9300],[17,18,64,9300]))
t0=time.time();seen={}
for v in tests:
 o=run(v);seen.setdefault(o,[]).append(v)
print('time',time.time()-t0,'outputs')
for o,vs in seen.items():print(hex(o),len(vs),vs[:20])
