#include <stdint.h>

static uint32_t mul32(uint32_t a, uint32_t b)
{
    return (uint32_t)((uint64_t)a * (uint64_t)b);
}

static uint32_t div100(uint32_t x)
{
    return (uint32_t)(((uint64_t)x * UINT64_C(0x51eb851f)) >> 37);
}

uint32_t recovered(uint32_t a, uint32_t b, uint32_t c, uint32_t d)
{
    uint32_t x = a + UINT32_C(0x4c55a6ee);
    x ^= x >> 16;
    x = mul32(x, UINT32_C(0x7feb352d));
    x ^= x >> 15;
    uint32_t gate = mul32(x, UINT32_C(0x846ca68b));

    if (gate < UINT32_C(0xffffff9c))
        return UINT32_C(0x80000001);

    if (c > UINT32_C(2))
        return UINT32_C(0x80000002);

    x = a ^ UINT32_C(0x838d31dc);
    x ^= x >> 16;
    x = mul32(x, UINT32_C(0x7feb352d));
    x ^= x >> 15;
    x = mul32(x, UINT32_C(0x846ca68b));
    x ^= x >> 16;

    if (d != x)
        return UINT32_C(0x80000003);

    uint32_t price = (c == 0) ? UINT32_C(129)
                   : (c == 1) ? UINT32_C(249)
                              : UINT32_C(399);
    uint32_t result = mul32(price, b);

    if (b > UINT32_C(9))
        result = div100(mul32(result, UINT32_C(85)));

    if (((gate ^ (gate >> 16)) & UINT32_C(7)) == UINT32_C(3))
        result = div100(mul32(result, UINT32_C(95)));

    return result;
}
