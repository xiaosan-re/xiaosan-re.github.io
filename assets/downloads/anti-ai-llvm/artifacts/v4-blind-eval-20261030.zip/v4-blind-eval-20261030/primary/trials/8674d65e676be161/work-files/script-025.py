from unicorn import *
from unicorn.arm64_const import *
import struct,itertools,collections,time
raw=open('target.so','rb').read();B=0x100000;ST=0x800000;SENT=0x900000
mu=Uc(UC_ARCH_ARM64,UC_MODE_ARM);mu.mem_map(B,0x10000);mu.mem_write(B,raw[:0x7200]);mu.mem_write(B+0xb200,raw[0x7200:0x72f0]);mu.mem_write(B+0xb2e8,struct.pack('<Q',B+0x456c));mu.mem_map(ST,0x20000);mu.mem_map(SENT,0x1000)
def hook(mu,a,s,u):
 if a==B+0x6e74:mu.reg_write(UC_ARM64_REG_X0,0);mu.reg_write(UC_ARM64_REG_PC,mu.reg_read(UC_ARM64_REG_LR))
 elif a==SENT:mu.emu_stop()
mu.hook_add(UC_HOOK_CODE,hook);regs=[UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3]
def run(v):
 mu.reg_write(UC_ARM64_REG_SP,ST+0x10000);mu.reg_write(UC_ARM64_REG_LR,SENT)
 for r,x in zip(regs,v):mu.reg_write(r,x)
 mu.emu_start(B+0x456c,SENT,count=200000)
 return mu.reg_read(UC_ARM64_REG_X0)&0xffffffff
names=['stage','state','base','disc','epoch']
found=[]; cnt=collections.Counter();t=time.time()
for i in range(48):
 fs=[i,i%7,149+130*(i%3),9300,17+i]
 for inds in itertools.permutations(range(5),4):
  v=tuple(fs[k] for k in inds);o=run(v);cnt[o]+=1
  if o<0x80000000:found.append((i,tuple(names[k] for k in inds),v,o))
print('time',time.time()-t,'found',len(found));print(found[:50]);print([(hex(k),v) for k,v in cnt.most_common(10)])
