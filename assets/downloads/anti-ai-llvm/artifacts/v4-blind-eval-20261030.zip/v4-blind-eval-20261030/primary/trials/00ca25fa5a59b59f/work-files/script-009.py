from pathlib import Path
p=Path('target.so')
b=p.read_bytes()
print(len(b), b[:4].hex())
try:
 import capstone
 print('capstone',capstone.__version__)
except Exception as e: print('no capstone',e)
