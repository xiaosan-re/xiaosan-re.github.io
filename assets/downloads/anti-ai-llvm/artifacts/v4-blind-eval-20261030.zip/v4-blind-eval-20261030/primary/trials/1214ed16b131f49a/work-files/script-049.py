# Differential-check the recovered high-level model against clean-path instruction emulation.
import random
from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
B=0x100000;S=0x200000;E=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x['p_vaddr'],x.data()) for x in e.iter_segments() if x['p_type']=='PT_LOAD']
def auth(a):
 x=(a^0x9b05606f)&0xffffffff;x=((x^(x>>16))*0x7feb352d)&0xffffffff;x=((x^(x>>15))*0x846ca68b)&0xffffffff;return (x^(x>>16))&0xffffffff
def model(a,b,c,d):
 if not (1<=b<=100):return 0x80000001
 if c>=3:return 0x80000002
 if d!=auth(a):return 0x80000003
 v=(129,249,399)[c]*b
 if b>=10:v=(v*85)//100
 x=(a+0x7188bda9)&0xffffffff;x=((x^(x>>16))*0x7feb352d)&0xffffffff;x=((x^(x>>15))*0x846ca68b)&0xffffffff;x^=x>>16
 if (x&7)==3:v=(v*95)//100
 return v
def emu(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000)
 for v,d in segs:u.mem_write(B+v,d)
 u.mem_write(B+0x4f9c,b'\x00\x00\x80\x52\xc0\x03\x5f\xd6');u.mem_map(S,0x10000);u.mem_map(E,0x1000);u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 u.emu_start(B+0x38cc,E,count=100000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
random.seed(7); tests=[]
for _ in range(80):
 a=random.getrandbits(32);b=random.choice([0,1,9,10,100,101,random.getrandbits(32)]);c=random.choice([0,1,2,3,random.getrandbits(32)]);d=auth(a) if random.randrange(2) else random.getrandbits(32);tests.append((a,b,c,d))
mis=[]
for t in tests:
 m=model(*t);q=emu(t)
 if m!=q:mis.append((t,hex(m),hex(q)))
print('tested',len(tests),'mismatches',mis[:10])
for t in [(0,1,0,auth(0)),(2,100,2,auth(2)),(0,0,0,0),(1,1,3,auth(1)),(1,1,0,0)]:print(t,hex(model(*t)),hex(emu(t)))