#include <stdint.h>

static uint32_t mix32(uint32_t x)
{
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

static uint32_t arm_udiv(uint32_t numerator, uint32_t denominator)
{
    /* AArch64 UDIV defines a zero divisor to produce zero. */
    return denominator != 0 ? numerator / denominator : 0;
}

uint32_t recovered(uint32_t a, uint32_t b, uint32_t c, uint32_t d)
{
    uint32_t value;
    uint32_t base;

    if (b < 1 || b > 100)
        return UINT32_C(0x80000001);

    if (c > 2)
        return UINT32_C(0x80000002);

    if (d != mix32(a ^ UINT32_C(0x838d31dc)))
        return UINT32_C(0x80000003);

    if (c == 0)
        base = 129;
    else if (c == 1)
        base = 249;
    else
        base = 399;

    value = base * b;

    if (b > 9)
        value = arm_udiv(value * UINT32_C(85), a);

    if ((mix32(a + UINT32_C(0x4c55a6ee)) & 7u) == 3u)
        value = arm_udiv(value * UINT32_C(95), a);

    return value;
}
