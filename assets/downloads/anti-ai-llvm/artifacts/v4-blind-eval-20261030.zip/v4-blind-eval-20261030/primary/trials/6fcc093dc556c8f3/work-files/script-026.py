a=2347398911
x=(a^0x838d31dc)&0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16
print(hex(a),hex(x),x)
