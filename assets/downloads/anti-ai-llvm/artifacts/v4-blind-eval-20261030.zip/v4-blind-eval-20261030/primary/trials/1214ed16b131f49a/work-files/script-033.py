import ctypes,struct
from elftools.elf.elffile import ELFFile
class Insn(ctypes.Structure):
 _fields_=[('id',ctypes.c_uint),('address',ctypes.c_uint64),('size',ctypes.c_uint16),('bytes',ctypes.c_ubyte*24),('mnemonic',ctypes.c_char*32),('op_str',ctypes.c_char*160),('is_alias',ctypes.c_bool),('alias_id',ctypes.c_uint64),('usesAliasDetails',ctypes.c_bool),('detail',ctypes.c_void_p)]
c=ctypes.CDLL('/opt/homebrew/lib/libcapstone.dylib');h=ctypes.c_size_t();print('open',c.cs_open(1,0,ctypes.byref(h)),h.value,'sz',ctypes.sizeof(Insn))
with open('target.so','rb') as f:e=ELFFile(f);s=e.get_section_by_name('.text');d=s.data();b=s['sh_addr'];blob=d[0x3950-b:0x3f74-b]
buf=(ctypes.c_ubyte*len(blob)).from_buffer_copy(blob);p=ctypes.POINTER(Insn)();c.cs_disasm.restype=ctypes.c_size_t;c.cs_disasm.argtypes=[ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint64,ctypes.c_size_t,ctypes.POINTER(ctypes.POINTER(Insn))]
n=c.cs_disasm(h,buf,len(blob),0x3950,0,ctypes.byref(p));print('n',n)
for i in range(min(n,20)):
 x=p[i];print(hex(x.address),x.size,x.mnemonic.decode(),x.op_str.decode())
c.cs_free(p,n);c.cs_close(ctypes.byref(h))