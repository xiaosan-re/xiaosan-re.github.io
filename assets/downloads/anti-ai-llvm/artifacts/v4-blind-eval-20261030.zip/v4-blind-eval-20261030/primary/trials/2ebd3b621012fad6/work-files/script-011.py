import ctypes.util, importlib.util
for x in ['capstone','opcodes','bfd','LLVM','llvm','udis86']:
 print(x,ctypes.util.find_library(x))
mods=['keystone','unicorn','angr','lief','elftools']
for m in mods: print(m,importlib.util.find_spec(m))