import pkgutil
mods=sorted(m.name for m in pkgutil.iter_modules())
print([x for x in mods if any(k in x.lower() for k in ['cap','disasm','arm','asm','elf','bin'])])