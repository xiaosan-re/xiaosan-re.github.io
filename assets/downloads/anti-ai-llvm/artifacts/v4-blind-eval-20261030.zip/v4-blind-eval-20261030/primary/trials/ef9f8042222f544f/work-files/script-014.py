import ctypes,ctypes.util
lib=ctypes.CDLL(ctypes.util.find_library('capstone'))
print(lib.cs_version(None,None))
class I(ctypes.Structure):
 _fields_=[('id',ctypes.c_uint),('address',ctypes.c_uint64),('size',ctypes.c_uint16),('bytes',ctypes.c_ubyte*24),('mnemonic',ctypes.c_char*32),('op_str',ctypes.c_char*160),('detail',ctypes.c_void_p)]
h=ctypes.c_size_t(); print('open',lib.cs_open(1,0,ctypes.byref(h)),h.value)
from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 f.seek(0x32c); d=f.read(1140)
buf=(ctypes.c_ubyte*len(d)).from_buffer_copy(d); out=ctypes.POINTER(I)()
lib.cs_disasm.restype=ctypes.c_size_t
n=lib.cs_disasm(h,buf,len(d),0x32c,0,ctypes.byref(out)); print('n',n)
for j in range(n):
 i=out[j]; print(f'{i.address:04x}: {i.mnemonic.decode():8} {i.op_str.decode()}')
lib.cs_free(out,n); lib.cs_close(ctypes.byref(h))