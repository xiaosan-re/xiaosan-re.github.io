from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
B=0x100000;S=0x200000;E=0x300000
raw=open('target.so','rb').read()
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x.header.p_vaddr,x.data()) for x in e.iter_segments() if x.header.p_type=='PT_LOAD']
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000);u.mem_map(S,0x10000);u.mem_map(E,0x1000)
for v,d in segs:u.mem_write(B+v,d)
u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),(0x11111111,0x22222222,0x33333333,0x44444444)):u.reg_write(r,v)
regs=[UC_ARM64_REG_X0+i for i in range(31)]+[UC_ARM64_REG_SP,UC_ARM64_REG_NZCV]
last=[u.reg_read(r) for r in regs];prev=[None]
def h(uc,addr,size,user):
 p=addr-B; cur=[uc.reg_read(r) for r in regs]
 if prev[0] is not None:
  ch=[]
  for i,(a,b) in enumerate(zip(last,cur)):
   if a!=b: ch.append((('x'+str(i)) if i<31 else ('sp' if i==31 else 'NZCV'))+'='+hex(b))
  q=prev[0];w=int.from_bytes(raw[q:q+4],'little');print(f'{q:04x} {w:08x}: '+', '.join(ch))
 last[:]=cur;prev[0]=p
 if p==0x4d4:uc.emu_stop()
u.hook_add(UC_HOOK_CODE,h);u.emu_start(B+0x32c,E,count=1000)
