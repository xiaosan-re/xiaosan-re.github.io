#include <stdint.h>

static uint32_t mix32(uint32_t x) {
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

static uint32_t divide_by_100(uint32_t x) {
    return (uint32_t)(((uint64_t)x * UINT64_C(0x51eb851f)) >> 37);
}

uint32_t recovered(uint32_t a, uint32_t b, uint32_t c, uint32_t d) {
    uint32_t coupon_hash = mix32(a + UINT32_C(0x7188bda9));
    uint32_t expected = mix32(a ^ UINT32_C(0x9b05606f));
    uint32_t unit;
    uint32_t total;

    if (b == 0)
        return UINT32_C(0x80000001);
    if (c > 2)
        return UINT32_C(0x80000002);
    if (d != expected)
        return UINT32_C(0x80000003);

    unit = (c == 0) ? UINT32_C(129)
         : (c == 1) ? UINT32_C(249)
                    : UINT32_C(399);

    total = b * unit;
    if (b > 9)
        total = divide_by_100(total * UINT32_C(85));
    if ((coupon_hash & 7u) == 3u)
        total = divide_by_100(total * UINT32_C(95));

    return total;
}
