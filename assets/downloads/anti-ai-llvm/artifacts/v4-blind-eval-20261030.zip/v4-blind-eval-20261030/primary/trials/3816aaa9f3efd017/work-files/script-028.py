import ctypes,struct
from elftools.elf.elffile import ELFFile
class Insn(ctypes.Structure):
 _fields_=[('id',ctypes.c_uint),('address',ctypes.c_uint64),('size',ctypes.c_uint16),('bytes',ctypes.c_ubyte*24),('mnemonic',ctypes.c_char*32),('op_str',ctypes.c_char*160),('detail',ctypes.c_void_p)]
print('size',ctypes.sizeof(Insn))
lib=ctypes.CDLL('/opt/homebrew/lib/libcapstone.dylib'); h=ctypes.c_size_t();print('open',lib.cs_open(1,0,ctypes.byref(h)),h.value)
lib.cs_disasm.restype=ctypes.c_size_t
lib.cs_disasm.argtypes=[ctypes.c_size_t,ctypes.POINTER(ctypes.c_ubyte),ctypes.c_size_t,ctypes.c_uint64,ctypes.c_size_t,ctypes.POINTER(ctypes.POINTER(Insn))]
with open('target.so','rb') as f:e=ELFFile(f);t=e.get_section_by_name('.text');d=t.data();b=t['sh_addr'];blob=d[0x38cc-b:0x3f74-b]
a=(ctypes.c_ubyte*len(blob)).from_buffer_copy(blob);p=ctypes.POINTER(Insn)();n=lib.cs_disasm(h,a,len(blob),0x38cc,0,ctypes.byref(p));print('n',n)
for i in range(n):print(f'{p[i].address:04x}: {p[i].mnemonic.decode():8} {p[i].op_str.decode()}')
lib.cs_free(p,n);lib.cs_close(ctypes.byref(h))