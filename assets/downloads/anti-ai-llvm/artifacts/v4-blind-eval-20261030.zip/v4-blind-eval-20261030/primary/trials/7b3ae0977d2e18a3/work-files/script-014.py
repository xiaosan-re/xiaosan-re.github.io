from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE,UC_HOOK_MEM_INVALID
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
BASE=0x100000; STACK=0x200000; STOP=0x300000
with open('target.so','rb') as f:
 e=ELFFile(f); segs=[]
 for s in e.iter_segments():
  if s.header.p_type=='PT_LOAD': segs.append((s.header.p_vaddr,s.data(),s.header.p_memsz))
def run(a,b,c,d):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM); u.mem_map(BASE,0x10000); u.mem_map(STACK,0x10000); u.mem_map(STOP,0x1000)
 for va,data,ms in segs:u.mem_write(BASE+va,data)
 u.reg_write(UC_ARM64_REG_SP,STACK+0x8000); u.reg_write(UC_ARM64_REG_X30,STOP)
 for r,v in zip([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3],[a,b,c,d]):u.reg_write(r,v)
 tr=[]
 def hook(uc,addr,size,user): tr.append(addr-BASE)
 def bad(uc,typ,addr,size,val,user): print('BAD',typ,hex(addr), 'pc',hex(uc.reg_read(UC_ARM64_REG_PC)-BASE)); return False
 u.hook_add(UC_HOOK_CODE,hook);u.hook_add(UC_HOOK_MEM_INVALID,bad)
 try:u.emu_start(BASE+0x32c,STOP,count=100000)
 except Exception as ex: print('ERR',ex)
 print('in',a,b,c,d,'ret',hex(u.reg_read(UC_ARM64_REG_X0)&0xffffffff),'steps',len(tr),'last',[hex(x) for x in tr[-30:]])
run(0,0,0,0)
run(1,2,3,4)
run(0xffffffff,0xffffffff,0xffffffff,0xffffffff)
