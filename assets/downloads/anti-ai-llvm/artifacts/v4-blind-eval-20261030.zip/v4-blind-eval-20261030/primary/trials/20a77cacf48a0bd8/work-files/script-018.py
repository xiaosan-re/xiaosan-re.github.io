from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
with open('target.so','rb') as f:
 e=ELFFile(f);seg=[(p['p_vaddr'],p['p_memsz'],p.data()) for p in e.iter_segments() if p['p_type']=='PT_LOAD']
def trace(q):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
 for a,m,b in seg:
  try:u.mem_map(a&~4095,((a+m+4095)&~4095)-(a&~4095))
  except:pass
  u.mem_write(a,b)
 u.mem_map(0x100000,4096);u.mem_map(0x200000,0x20000);u.reg_write(UC_ARM64_REG_SP,0x21fff0);u.reg_write(UC_ARM64_REG_LR,0x100000)
 for r,v in zip([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3],q):u.reg_write(r,v)
 prev=[None];runs=[];start=[None];n=[0]
 def h(uc,a,s,d):
  n[0]+=1
  if a==0x45ac:uc.reg_write(UC_ARM64_REG_X0,0);uc.reg_write(UC_ARM64_REG_PC,0x45b0)
  if prev[0] is None or a!=prev[0]+4:
   if prev[0] is not None:runs.append((start[0],prev[0],a))
   start[0]=a
  prev[0]=a
  if a==0x100000:uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x100004,count=1000000)
 print('result',hex(u.reg_read(UC_ARM64_REG_W0)),'instructions',n[0],'runs',len(runs))
 for z in runs[:300]:print('%06x-%06x -> %06x'%z)
trace((1,2,3,4))