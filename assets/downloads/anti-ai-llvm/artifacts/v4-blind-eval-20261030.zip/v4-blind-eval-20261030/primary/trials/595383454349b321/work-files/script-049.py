import zlib,runpy,contextlib,io,base64
with contextlib.redirect_stdout(io.StringIO()):ns=runpy.run_path('script-040.py')
r=ns['raw']
for w in [9]:
 c=zlib.compress(r,9,wbits=-15);print(len(c),len(base64.b64encode(c)))