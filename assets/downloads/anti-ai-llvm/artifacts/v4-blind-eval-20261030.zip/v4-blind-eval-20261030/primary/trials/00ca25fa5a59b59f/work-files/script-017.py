u=lambda x:x&0xffffffff
w19=0xbb686f72;w20=0x2318fa58
y=0x0ab58f4d^0x7053cae9
s0=u((w19^y)+w20)
print(hex(y),hex(s0))
