from unicorn import *
from unicorn.arm64_const import *
import struct
blob=open('target.so','rb').read()
def run(A):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
 for i,x in enumerate(A):u.reg_write(UC_ARM64_REG_X0+i,x)
 u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000)
 it=[-1]; rec=[]
 def h(u,a,s,z):
  if a==0x6e74:u.reg_write(UC_ARM64_REG_X0,0);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
  if a==0x530c:
   it[0]+=1;sp=u.reg_read(UC_ARM64_REG_SP); w=struct.unpack('<184I',u.mem_read(sp,736));rec.append([w,None])
   if it[0]==70:
    print('decoded at 70')
    for j in range(0xe0,0x270,16):print(f'{j:03x}',*[f'{x:08x}' for x in w[j//4:j//4+4]])
  elif it[0]>=70 and rec[-1][1] is None and not (0x530c<=a<=0x59b0):rec[-1][1]=a
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=100000)
 print('A',A,'ret',hex(u.reg_read(UC_ARM64_REG_W0)))
 for i,(w,p) in enumerate(rec[70:],70):print(i,hex(p or 0), ' '.join(f'{o:02x}={w[o//4]:08x}' for o in [0x10,0x30,0x40,0x50,0x60,0x70,0x80,0x90,0xa0,0xb0,0xc0,0xd0]))
run((1,2,3,4))