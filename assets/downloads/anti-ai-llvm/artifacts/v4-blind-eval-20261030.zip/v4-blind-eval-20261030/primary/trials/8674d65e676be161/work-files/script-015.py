from elftools.elf.elffile import ELFFile
f=open('target.so','rb');e=ELFFile(f)
for x in e.get_section_by_name('.eh_frame').iter_CEs():
 print(type(x).__name__,getattr(x,'header',None))
