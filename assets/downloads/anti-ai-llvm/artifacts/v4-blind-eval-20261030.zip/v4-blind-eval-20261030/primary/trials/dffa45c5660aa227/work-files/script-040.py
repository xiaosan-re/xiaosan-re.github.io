# Compact recovered VM semantics with corrected comparisons; print paths/results for representative inputs.
import struct
b=open('target.so','rb').read();C=[0xbc479312,0x39ac5979,0xb79007c4,0x2d84cc53,0xabe8babe,0x21dd6705,0x9fc12d90,0x15351bff,0x9319c04a];u=lambda x:x&0xffffffff
def h(x):x=u(x^(x>>16));x=u(x*0x7feb352d);x=u(x^(x>>15));x=u(x*0x846ca68b);return u(x^(x>>16))
R=[[struct.unpack_from('<I',b,0x2d0+36*i+4*j)[0]^h(u(i*0x9e3779b9)^C[j]) for j in range(9)] for i in range(92)]
def sx(v,bits):
 n=bits&31
 if n==0:n=32
 v&=(1<<n)-1;m=1<<(n-1);return (v^m)-m
def run(a,bb,c,d,path=False):
 q=[0]*70;q[58]=u(a);q[23]=u(bb);q[27]=u(c);q[14]=u(d);pc=0; ps=[]
 for st in range(500):
  ps.append(pc);op,dst,aa,bi,ci,im,w,nx,al=R[pc];A=q[aa];B=q[bi];C=q[ci];o=None
  if op==0x31ef8a34:o=im
  elif op==0x432b31fa:o=A
  elif op==0xa9050067:o=u(B+A)
  elif op==0x778380a7:o=u(B*A)
  elif op==0xc179bd02:o=B^A
  elif op==0xcc213f3b:o=B&A
  elif op==0x68a9af5d:o=A>>(B&31)
  elif op==0x2d296d65:o=A//(1 if B==0 else C)
  elif op==0xfd23a89f:
   if im==32:o=int(A==B)
   elif im==33:o=int(A!=B)
   elif im==34:o=int(A>B)
   elif im==35:o=int(A>=B)
   elif im==36:o=int(A<B)
   elif im==37:o=int(A<=B)
   elif im==38:o=int(sx(A,w)>sx(B,w))
   elif im==39:o=int(sx(A,w)>=sx(B,w))
   elif im==40:o=int(sx(A,w)<sx(B,w))
   elif im==41:o=int(sx(A,w)<=sx(B,w))
  elif op==0x86b9c54f:o=B if A else C
  elif op==0xd515b9c4:pc=nx;continue
  elif op==0x9153976a:pc=nx if A else al;continue
  elif op==0xe9855c9d:return A,ps
  else:raise ValueError(hex(op))
  n=w&31;mask=0xffffffff if n==0 else (1<<n)-1;q[dst]=u(o)&mask;pc=nx
 raise ValueError('loop')
qs=[(0,0,0,0),(1,1,1,1),(100,9300,17,0),(149,9300,17,0),(1000,10,5,2),(0xffffffff,0xffffffff,0xffffffff,0xffffffff),(100,5,3,1),(100,101,3,1),(100,100,3,1)]
for x in qs:
 try:
  z,p=run(*x);print(x,hex(z),'path',p[23:])
 except Exception as e: print(x,type(e).__name__,e)