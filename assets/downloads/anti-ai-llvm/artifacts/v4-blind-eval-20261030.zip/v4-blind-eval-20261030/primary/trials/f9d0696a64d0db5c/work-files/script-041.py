x=0x838db250;y=0x7feb352d
ops={'add':(x+y)&0xffffffff,'xor':x^y,'mul':(x*y)&0xffffffff,'sub':(x-y)&0xffffffff,'rol':((x<<13)|(x>>19))&0xffffffff}
print({k:hex(v) for k,v in ops.items()})
# next shift by15 output 0x1aa85 likely >>15 yes
print(hex(0xd542e810>>15))
# xor with old => d5434295 yes
print(hex(0x1aa85^0xd542e810))
# mul 0x846ca68b => expected 538dc4e7
print(hex((0xd5434295*0x846ca68b)&0xffffffff))
print(hex(0x538dc4e7>>16),hex((0x538d^0x538dc4e7)&0xffffffff))