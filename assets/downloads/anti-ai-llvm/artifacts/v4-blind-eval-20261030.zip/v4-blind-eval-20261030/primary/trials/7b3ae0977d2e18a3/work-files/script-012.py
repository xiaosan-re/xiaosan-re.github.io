from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f); s=e.get_section_by_name('.text'); d=s.data(); b=s.header.sh_addr
 for o in range(0,len(d),32): print(f'{b+o:04x}: '+d[o:o+32].hex(' '))