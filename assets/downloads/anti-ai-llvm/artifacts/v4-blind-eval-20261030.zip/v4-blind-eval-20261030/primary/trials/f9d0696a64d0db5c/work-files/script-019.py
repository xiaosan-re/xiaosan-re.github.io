from unicorn import *
from unicorn.arm64_const import *
blob=open('target.so','rb').read()
def R(a,b,c,d):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
 for i,x in enumerate((a,b,c,d)):u.reg_write(UC_ARM64_REG_X0+i,x)
 u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000)
 def h(u,x,s,z):
  if x==0x6e74:u.reg_write(UC_ARM64_REG_X0,1);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=10000)
 return u.reg_read(UC_ARM64_REG_W0)
base=[1,2,3,4]
for pos in range(4):
 print('POS',pos)
 out=[]
 for x in list(range(0,21))+[47,48,49,63,64,65,99,100,127,128,149,279,409,9299,9300,9301,9999,10000,0xffffffff]:
  q=base.copy();q[pos]=x;out.append((x,R(*q)))
 print(' '.join(f'{x}:{y:#x}' for x,y in out))
print('a rows fixed rest 0')
for a in range(64):print(a,hex(R(a,0,0,0)))