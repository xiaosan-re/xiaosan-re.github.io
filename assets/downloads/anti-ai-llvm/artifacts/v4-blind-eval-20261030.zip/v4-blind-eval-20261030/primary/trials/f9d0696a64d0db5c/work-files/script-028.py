from unicorn import *
from unicorn.arm64_const import *
import random
blob=open('target.so','rb').read()
def E(A):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
 for i,x in enumerate(A):u.reg_write(UC_ARM64_REG_X0+i,x)
 u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000)
 def h(u,x,s,z):
  if x==0x6e74:u.reg_write(UC_ARM64_REG_X0,1);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=10000);return u.reg_read(UC_ARM64_REG_W0)
C=[0x91e573ab,0x9308b912,0x942bfe79,0x954f43e0,0x96728947]
def H(x,dep=4,fn=0):
 x=((x^C[fn])*0x9e3779b9)&0xffffffff
 if dep==0:return x
 nxt=(fn+1 if x&1 else fn+2)%5
 return H(x^(x>>13),dep-1,nxt)
def M(a,b,c,d):
 h=H(a^d);v=0;s=h&3
 for i in range(6):
  if s==0:v=(130*(c%3)+149)&0xffffffff;s=1
  elif s==1:v=(v*(b%100+1))&0xffffffff;s=2
  elif s==2:v=((93*v)&0xffffffff)//100;s=3
  else:v^=h&15;s=0
  h=((h<<7)|(h>>25))&0xffffffff
 return v&0x7fffffff
random.seed(1)
for i in range(100):
 A=tuple(random.getrandbits(32) for _ in range(4));e=E(A);m=M(*A)
 if e!=m:print('BAD',A,hex(e),hex(m));break
else:print('100 random matched')
for A in [(1,2,3,4),(0,0,0,0),(0xffffffff,)*4]:print(A,hex(E(A)),hex(M(*A)),hex(H(A[0]^A[3])))