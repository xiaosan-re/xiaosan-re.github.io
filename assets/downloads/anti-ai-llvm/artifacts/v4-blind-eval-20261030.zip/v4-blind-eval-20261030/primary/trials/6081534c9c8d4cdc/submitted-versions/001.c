#include <stdint.h>

static uint32_t mix_value(uint32_t x)
{
    static const uint32_t key[5] = {
        UINT32_C(0x91e573ab), UINT32_C(0x9308b912),
        UINT32_C(0x942bfe79), UINT32_C(0x954f43e0),
        UINT32_C(0x96728947)
    };
    uint32_t index = 0;
    uint32_t depth = 4;

    for (;;) {
        uint32_t v = (x ^ key[index]) * UINT32_C(0x9e3779b9);
        if (depth == 0)
            return v;
        x = v ^ (v >> 13);
        index = (index + ((v & 1u) ? 1u : 2u)) % 5u;
        --depth;
    }
}

uint32_t recovered(uint32_t a, uint32_t b, uint32_t c, uint32_t d)
{
    uint32_t h = mix_value(a ^ d);
    uint32_t score = 0;
    uint32_t state = h & 3u;
    uint32_t i;

    for (i = 0; i < 6; ++i) {
        switch (state) {
        case 0:
            score = 130u * (c % 3u) + 149u;
            state = 1;
            break;
        case 1:
            score *= b % 100u + 1u;
            state = 2;
            break;
        case 2:
            score = (93u * score) / 100u;
            state = 3;
            break;
        default:
            score ^= h & 15u;
            state = 0;
            break;
        }
        h = (h >> 25) | (h << 7);
    }

    return score & UINT32_C(0x7fffffff);
}
