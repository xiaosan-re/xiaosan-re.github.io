# Reuse audited Unicorn setup; probe discount arithmetic across three base classes and quantities.
from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
B=0x100000;S=0x200000;E=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x['p_vaddr'],x.data()) for x in e.iter_segments() if x['p_type']=='PT_LOAD']
def run(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000)
 for v,d in segs:u.mem_write(B+v,d)
 u.mem_write(B+0x4f9c,b'\xc0\x03\x5f\xd6');u.mem_map(S,0x10000);u.mem_map(E,0x1000);u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 u.emu_start(B+0x38cc,E,count=100000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
for a,d in [(1,0),(2,0),(3,0),(4,0),(10,0),(1,2),(7,5),(47,11),(0xffffffff,0xffffffff)]:
 print((a,d),[[run((a,b,c,d)) for b in [0,1,2,9]] for c in [0,1,2]])