from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
B=0x100000;S=0x200000;E=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x.header.p_vaddr,x.data()) for x in e.iter_segments() if x.header.p_type=='PT_LOAD']
def run(vals):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000);u.mem_map(S,0x10000);u.mem_map(E,0x1000)
 for v,d in segs:u.mem_write(B+v,d)
 u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),vals):u.reg_write(r,v)
 prev=[None]
 def h(uc,addr,size,user):
  p=addr-B
  if p==0x4d4:
   print('INIT',vals)
   for j in range(29):print(f'x{j}={uc.reg_read(UC_ARM64_REG_X0+j):08x}',end=' ')
   print()
  if p==0x4fc:
   fp=uc.reg_read(UC_ARM64_REG_X29); acc=int.from_bytes(uc.mem_read(fp-4,4),'little')
   print(f'DISPATCH state(x4)={uc.reg_read(UC_ARM64_REG_X4)&0xffffffff:08x} acc={acc:08x}')
  # identify jumps into body regions after dispatcher
  if prev[0] is not None and p not in (prev[0]+4,): print(f' jump {prev[0]:04x}->{p:04x}')
  prev[0]=p
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(B+0x32c,E,count=1000)
 print('RET',hex(u.reg_read(UC_ARM64_REG_X0)&0xffffffff))
for a in [(0,0,0,0),(36,82,74,59),(36,15,1,66),(1,2,3,4)]:run(a)
