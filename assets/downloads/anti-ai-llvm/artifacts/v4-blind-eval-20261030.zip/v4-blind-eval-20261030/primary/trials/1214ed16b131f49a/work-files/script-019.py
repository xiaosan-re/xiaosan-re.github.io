w=0x12000913
print('N',w>>22&1,'immr',w>>16&63,'imms',w>>10&63,'rn',w>>5&31,'rd',w&31)
w=0x7a401800
print('ccmp fields rm/imm5',(w>>16)&31,'cond',(w>>12)&15,'rn',(w>>5)&31,'nzcv',w&15)