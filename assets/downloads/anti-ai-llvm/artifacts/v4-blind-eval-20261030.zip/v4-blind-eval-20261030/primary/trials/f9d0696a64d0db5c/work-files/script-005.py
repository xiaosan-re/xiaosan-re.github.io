from elftools.elf.elffile import ELFFile
from capstone import *
p='target.so'
with open(p,'rb') as f:
 e=ELFFile(f)
 print('entry',hex(e.header.e_entry))
 for s in e.iter_sections():
  print(s.name,hex(s['sh_addr']),hex(s['sh_offset']),hex(s['sh_size']),s['sh_flags'])
 dyn=e.get_section_by_name('.dynsym')
 for sym in dyn.iter_symbols():
  if sym.name: print('SYM',sym.name,hex(sym['st_value']),sym['st_size'],sym['st_info']['type'])
 text=e.get_section_by_name('.text'); data=text.data(); base=text['sh_addr']
 off=0x456c-base
 b=data[off:off+256]
 md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN)
 for i in md.disasm(b,0x456c): print(f'{i.address:08x}: {i.bytes.hex():8} {i.mnemonic:8} {i.op_str}')