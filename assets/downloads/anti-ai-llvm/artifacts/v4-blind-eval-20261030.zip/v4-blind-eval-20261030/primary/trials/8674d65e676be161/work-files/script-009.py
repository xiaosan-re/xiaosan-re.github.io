from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
import struct
B=0x100000; STACK=0x800000; SENT=0x900000
with open('target.so','rb') as f:
 raw=f.read(); f.seek(0); e=ELFFile(f); segs=[dict(p.header) for p in e.iter_segments() if p['p_type']=='PT_LOAD']
mu=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
mu.mem_map(B,0x10000); mu.mem_write(B,raw[:0x72f0]); mu.mem_map(B+0xb000,0x5000); mu.mem_write(B+0xb200,raw[0x7200:0x72f0])
# relocation plt demo
mu.mem_write(B+0xb2e8,struct.pack('<Q',B+0x456c))
mu.mem_map(STACK,0x20000); mu.mem_map(SENT,0x1000)
mu.reg_write(UC_ARM64_REG_SP,STACK+0x10000);mu.reg_write(UC_ARM64_REG_LR,SENT)
for r,v in zip([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3],[1,2,3,4]):mu.reg_write(r,v)
trace=[]
def hc(mu,a,s,u):
 if len(trace)<10000: trace.append(a-B)
 if a==SENT: mu.emu_stop()
def hi(mu,intno,u):
 print('interrupt',intno,'pc',hex(mu.reg_read(UC_ARM64_REG_PC)-B),'x8',mu.reg_read(UC_ARM64_REG_X8),'args',[mu.reg_read(x) for x in [UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3]])
 # return errors
 mu.reg_write(UC_ARM64_REG_X0,(-1)&((1<<64)-1))
def inv(mu,typ,addr,size,val,u): print('INVALID',typ,hex(addr),size,hex(mu.reg_read(UC_ARM64_REG_PC)-B)); return False
mu.hook_add(UC_HOOK_CODE,hc);mu.hook_add(UC_HOOK_INTR,hi);mu.hook_add(UC_HOOK_MEM_INVALID,inv)
try: mu.emu_start(B+0x456c,SENT,count=1000000)
except Exception as ex: print('ERR',ex,'pc',hex(mu.reg_read(UC_ARM64_REG_PC)-B))
print('ret',hex(mu.reg_read(UC_ARM64_REG_X0)),'ntrace',len(trace),'last',list(map(hex,trace[-30:])))
print('unique',len(set(trace)),list(map(hex,sorted(set(trace))[:100])))
