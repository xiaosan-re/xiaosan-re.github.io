import struct
b=open('target.so','rb').read();u=lambda a:struct.unpack_from('<I',b,a)[0]
def mc(a):
 w=u(a);v=((w>>5)&65535)<<(((w>>21)&3)*16);w2=u(a+4);sh=((w2>>21)&3)*16;return ((v&~(0xffff<<sh))|(((w2>>5)&65535)<<sh))&0xffffffff
D={}
for a in list(range(0x5310,0x5500,0x14))+list(range(0x5878,0x5a30,0x14)):
 wb=u(a+12);im=(wb>>5)&0x7ffff;im-=1<<19 if im>>18 else 0;D[mc(a)]=a+12+4*im
T={}
for h in set(D.values()):
 for a in range(h,min(h+0x180,0x62a0),4):
  if (u(a)&0x7f80001f)==0x5280000c and u(a+8)==0x4a0c0129 and u(a+12)==0xb9000089:T[h]=mc(a);break
  if u(a)&0x7c000000==0x14000000:break
T[0x5a34]=0x1d18f6c
def fm(x):
 x&=0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x
salts=[0x6ce1a125,0xe90a6b4e,0x673635f3,0xfd22fe64,0x7b4e8889,0xf17b5532,0x4f671fa7,0xc59329c8,0x43bff27d]
def vals(q):
 g=q*0x9e3779b9&0xffffffff;return [u(0x2d0+4*(q*9+j))^fm(g^salts[j]) for j in range(9)]
q=0
for row in range(60):
 vs=vals(q); storage=0xe4a7252e;d=vs[0];chain=[]
 for z in range(20):
  h=D.get(d);chain.append(h)
  if h in (None,0x606c,0x5508,0x551c,0x5a34):break
  storage^=T[h];d=storage
 print('iter',row,'q',q,'cols',vs[1:],'chain',' '.join('?' if h is None else hex(h) for h in chain))
 if chain[-1] in (None,0x606c,0x5508):break
 q=vs[7]
 if q>=48:print('OOB next',q);break