# Clean-path grid: hold a=1,b=1,d=0 and vary c, then vary b.
from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
B=0x100000;S=0x200000;E=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x['p_vaddr'],x.data()) for x in e.iter_segments() if x['p_type']=='PT_LOAD']
def run(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000)
 for v,d in segs:u.mem_write(B+v,d)
 u.mem_write(B+0x4f9c,b'\x00\x00\x80\x52\xc0\x03\x5f\xd6');u.mem_map(S,0x10000);u.mem_map(E,0x1000);u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 path=[]
 def h(uc,ad,sz,x):
  o=ad-B
  if o in (0x3be8,0x3c5c,0x3cb0,0x3d00,0x3d5c,0x3dac,0x3de8,0x3e24,0x3e44,0x3e64,0x3e94,0x3eb0,0x3ecc,0x3ef8,0x3f04,0x3f38,0x3f50):path.append(o)
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(B+0x38cc,E,count=100000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff,tuple(path)
vals=list(range(0,21))+[99,100,148,149,150,278,279,280,408,409,410,9299,9300,9301,0x7fffffff,0xffffffff]
print('vary c')
for c in vals:print(c,hex(run((1,1,c,0))[0]),[hex(x) for x in run((1,1,c,0))[1]])
print('vary b')
for b in list(range(0,11))+[99,100,0xffffffff]:print(b,hex(run((1,b,9300,0))[0]),[hex(x) for x in run((1,b,9300,0))[1]])