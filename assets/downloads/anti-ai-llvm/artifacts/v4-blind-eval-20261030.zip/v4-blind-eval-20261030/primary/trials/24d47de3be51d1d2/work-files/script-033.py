from elftools.elf.elffile import ELFFile
import struct
with open('target.so','rb') as f:
 s=ELFFile(f).get_section_by_name('.text'); D=s.data(); B=s['sh_addr']
def sx(x,n): return x-(1<<n) if x>>(n-1) else x
def reg(n,w=True): return ('w' if w else 'x')+str(n) if n<31 else ('wzr' if w else 'xzr')
def dec(a,w):
 rd=w&31; rn=(w>>5)&31; rm=(w>>16)&31
 if (w&0x7f800000)==0x52800000: return f'movz w{rd},#{(w>>5)&0xffff:#x},lsl#{((w>>21)&3)*16}'
 if (w&0x7f800000)==0x72800000: return f'movk w{rd},#{(w>>5)&0xffff:#x},lsl#{((w>>21)&3)*16}'
 if (w&0x7f200000)==0x2a000000: return f'orr {reg(rd)},{reg(rn)},{reg(rm)},shift{(w>>22)&3}#{(w>>10)&63}'
 if (w&0x7f200000)==0x4a000000: return f'eor {reg(rd)},{reg(rn)},{reg(rm)},shift{(w>>22)&3}#{(w>>10)&63}'
 if (w&0xffe0fc00)==0x1b007c00: return f'mul w{rd},w{rn},w{rm}'
 if (w&0xffe08000)==0x1b000000: return f'madd w{rd},w{rn},w{rm},w{(w>>10)&31}'
 if (w&0xffc00000)==0xb9000000:return f'str w{rd},[x{rn},#{((w>>10)&0xfff)*4}]'
 if (w&0xffc00000)==0xb9400000:return f'ldr w{rd},[x{rn},#{((w>>10)&0xfff)*4}]'
 if (w&0xffe00c00)==0xb8000000:return f'stur w{rd},[x{rn},#{sx((w>>12)&0x1ff,9)}]'
 if (w&0xffe00c00)==0xb8400000:return f'ldur w{rd},[x{rn},#{sx((w>>12)&0x1ff,9)}]'
 if (w&0x7f00001f)==0x6b00001f:return f'cmp w{rn},w{rm},shift{(w>>22)&3}#{(w>>10)&63}'
 if (w&0x7f00001f)==0x7100001f:return f'cmp w{rn},#{(w>>10)&0xfff:#x}'
 if (w&0xff000010)==0x54000000:
  cs=['eq','ne','cs','cc','mi','pl','vs','vc','hi','ls','ge','lt','gt','le','al','nv']; return f'b.{cs[w&15]} {a+sx((w>>5)&0x7ffff,19)*4:#x}'
 if (w&0x7e000000)==0x34000000:return f'{"cbnz" if (w>>24)&1 else "cbz"} {reg(rd,not bool(w>>31))},{a+sx((w>>5)&0x7ffff,19)*4:#x}'
 if w>>26 in (5,37): return f'{"bl" if w>>31 else "b"} {a+sx(w&0x3ffffff,26)*4:#x}'
 if (w&0xffe0fc00)==0x9ba07c00:return f'umulh x{rd},x{rn},x{rm}'
 return '?'
for a in range(0x3950,0x3f74,4):
 w=struct.unpack_from('<I',D,a-B)[0]
 print(f'{a:04x} {w:08x} {dec(a,w)}')
