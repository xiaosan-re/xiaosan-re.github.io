from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
import random
B=0x100000;S=0x200000;E=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x.header.p_vaddr,x.data()) for x in e.iter_segments() if x.header.p_type=='PT_LOAD']
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000);u.mem_map(S,0x10000);u.mem_map(E,0x1000)
for v,d in segs:u.mem_write(B+v,d)
def run(v):
 u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
 for r,x in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),v):u.reg_write(r,x)
 u.emu_start(B+0x32c,E,count=1000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
def mix(x):
 x&=0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x&0xffffffff
def tok(a):return mix(a^0x9b05606f)
def bucket(a):return mix(a+0x7188bda9)&7
def pred(a,b,c,d):
 if not 1<=b<=100:return 0x80000001
 if c>2:return 0x80000002
 if d!=tok(a):return 0x80000003
 z=(129,249,399)[c]*b
 if b>=10:z=z*85//100
 if bucket(a)==3:z=z*95//100
 return z
As=list(range(64))+[random.getrandbits(32) for _ in range(36)]
n=0
for a in As:
 d=tok(a)
 for b in range(1,101):
  for c in range(3):
   actual=run((a,b,c,d));want=pred(a,b,c,d);n+=1
   if actual!=want:raise Exception(('valid',hex(a),b,c,hex(actual),hex(want),bucket(a)))
print(n,'valid checks passed')
for i in range(10000):
 v=tuple(random.getrandbits(32) for _ in range(4));actual=run(v);want=pred(*v)
 if actual!=want:raise Exception(('random',tuple(hex(x) for x in v),hex(actual),hex(want)))
print('10000 arbitrary checks passed')
