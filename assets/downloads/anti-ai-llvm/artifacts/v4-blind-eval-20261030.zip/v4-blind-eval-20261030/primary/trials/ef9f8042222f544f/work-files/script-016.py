from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:blob=f.read()
regs=[UC_ARM64_REG_W0,UC_ARM64_REG_W1,UC_ARM64_REG_W2,UC_ARM64_REG_W3,UC_ARM64_REG_W4,UC_ARM64_REG_W13,UC_ARM64_REG_W16,UC_ARM64_REG_W17,UC_ARM64_REG_W19,UC_ARM64_REG_W20,UC_ARM64_REG_W23,UC_ARM64_REG_W26,UC_ARM64_REG_W30]
watch=set(range(0x4d0,0x780,4))
def run(args):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x10000);u.reg_write(UC_ARM64_REG_SP,0x108000);u.reg_write(UC_ARM64_REG_X30,0x9000)
 for r,a in zip(regs[:4],args):u.reg_write(r,a)
 seen=[]
 def hook(uc,a,s,z):
  if a in [0x4d0,0x4d4,0x4d8,0x4fc,0x52c,0x570,0x57c,0x5ac,0x5e8,0x610,0x644,0x678,0x694,0x6a4,0x6b4,0x6d4,0x6f0,0x700,0x71c,0x72c,0x74c,0x75c,0x76c,0x780]: seen.append((a,[uc.reg_read(r) for r in regs]))
 u.hook_add(UC_HOOK_CODE,hook);u.emu_start(0x32c,0x9000,count=10000)
 print('ARGS',args,'OUT',hex(u.reg_read(UC_ARM64_REG_W0)))
 for a,v in seen: print(hex(a),*[hex(x) for x in v])
for x in [(0,0,0,0),(1,2,3,4),(0,1,0,0),(1,1,1,1),(0,2,0,0),(0,3,0,0),(0,9,0,0),(0,10,0,0),(0,100,0,0),(0,101,0,0),(0,0,2,0),(0,0,3,0)]:run(x)