for w in [0x1ac92589,0x1ac90989,0x1ac9218c,0x1ac9298c,0x1acc25ec]:
 print(hex(w), 'rn',(w>>5)&31,'rm',(w>>16)&31,'rd',w&31,'op',hex(w&0x7fe0fc00))