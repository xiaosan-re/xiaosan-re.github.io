#include <stdint.h>

static uint32_t mix_add(uint32_t x)
{
    x += UINT32_C(0x4c55a6ee);
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

static uint32_t mix_xor(uint32_t x)
{
    x ^= UINT32_C(0x838d31dc);
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

static uint32_t divide_100(uint32_t x)
{
    return (uint32_t)(((uint64_t)x * UINT64_C(0x51eb851f)) >> 37);
}

uint32_t recovered(uint32_t a, uint32_t b, uint32_t c, uint32_t d)
{
    uint32_t base;
    uint32_t value;

    if (b == 0 || b > 100)
        return UINT32_C(0x80000001);
    if (c > 2)
        return UINT32_C(0x80000002);
    if (d != mix_xor(a))
        return UINT32_C(0x80000003);

    base = (c == 0) ? 129u : (c == 1) ? 249u : 399u;
    value = c;

    if (b > 9) {
        value = base * UINT32_C(0xe4a7252e);
        value *= 85u;
        value = divide_100(value);
    }

    if ((mix_add(a) & 7u) == 3u) {
        value *= 95u;
        value = divide_100(value);
    }

    return value;
}
