import ctypes.util,glob,os
print('capstone lib',ctypes.util.find_library('capstone'))
print('llvm libs',glob.glob('/usr/lib/*LLVM*')[:20],glob.glob('/opt/homebrew/lib/*capstone*')[:20])
print('bin dirs', [x for x in glob.glob('/usr/bin/*objdump*')])
