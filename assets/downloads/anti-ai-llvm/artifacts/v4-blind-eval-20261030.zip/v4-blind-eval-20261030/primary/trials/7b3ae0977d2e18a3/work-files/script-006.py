from elftools.elf.elffile import ELFFile
with open('target.so','rb') as f:
 e=ELFFile(f)
 print('entry',hex(e.header.e_entry),'machine',e.header.e_machine)
 for s in e.iter_sections(): print('SEC',s.name,hex(s.header.sh_addr),hex(s.header.sh_offset),hex(s.header.sh_size),s.header.sh_type)
 for seg in e.iter_segments(): print('SEG',seg.header.p_type,hex(seg.header.p_vaddr),hex(seg.header.p_offset),hex(seg.header.p_filesz),hex(seg.header.p_memsz),seg.header.p_flags)
 for secname in ['.dynsym','.symtab']:
  sec=e.get_section_by_name(secname)
  if sec:
   for sym in sec.iter_symbols():
    if sym.name: print('SYM',sym.name,hex(sym.entry.st_value),sym.entry.st_size,sym.entry.st_info.type)
