from unicorn import *
from unicorn.arm64_const import *
import struct
blob=open('target.so','rb').read()
def run(A):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
 for i,x in enumerate(A):u.reg_write(UC_ARM64_REG_X0+i,x)
 u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000)
 it=[-1];recs=[]
 def h(u,a,s,z):
  if a==0x6e74:u.reg_write(UC_ARM64_REG_X0,0);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
  if a==0x530c:
   it[0]+=1;sp=u.reg_read(UC_ARM64_REG_SP); w=struct.unpack('<56I',u.mem_read(sp,224));recs.append([list(w),None])
  elif it[0]>=69 and recs[-1][1] is None and not (0x530c<=a<=0x59b0):recs[-1][1]=a
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=100000)
 print('A',tuple(hex(x) for x in A),'ret',hex(u.reg_read(UC_ARM64_REG_W0)))
 for i in range(69,len(recs)):
  w,p=recs[i]; old=recs[i-1][0] if i else [0]*56
  dif=[f'{j*4:02x}:{old[j]:08x}>{w[j]:08x}' for j in range(56) if old[j]!=w[j]]
  print(i,hex(p or 0),' '.join(dif))
for A in [(1,2,3,4),(0,0,0,0),(0x11,0x22,0x33,0x44)]:run(A)