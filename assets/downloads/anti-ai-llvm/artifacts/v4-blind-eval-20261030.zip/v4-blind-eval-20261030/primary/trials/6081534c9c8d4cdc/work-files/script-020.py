from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
import random
blob=open('target.so','rb').read()
def emu(a,b,c,d):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x10000)
 u.reg_write(UC_ARM64_REG_SP,0x108000);u.reg_write(UC_ARM64_REG_X30,0x8000)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),(a,b,c,d)):u.reg_write(r,v)
 u.hook_add(UC_HOOK_CODE,lambda uc,addr,size,user: uc.emu_stop() if addr==0x8000 else None)
 u.emu_start(0x4410,0x8004,count=100000)
 return u.reg_read(UC_ARM64_REG_W0)
K=[0x91e573ab,0x9308b912,0x942bfe79,0x954f43e0,0x96728947]
def rec(a):
 idx=0
 for dep in range(4,-1,-1):
  v=((a^K[idx])*0x9e3779b9)&0xffffffff
  if dep==0:return v
  a=(v^(v>>13))&0xffffffff
  idx=(idx+(1 if v&1 else 2))%5
def calc(a,b,c,d):
 h=rec((a^d)&0xffffffff); val=0; state=h&3
 for _ in range(6):
  if state==0: val=130*(c%3)+149;state=1
  elif state==1:val=(val*(b%100+1))&0xffffffff;state=2
  elif state==2:val=((93*val)&0xffffffff)//100;state=3
  else:val^=h&15;state=0
  h=((h>>25)|(h<<7))&0xffffffff
 return val&0x7fffffff
T=[(0,0,0,0),(1,2,3,4),(0xffffffff,0xffffffff,0xffffffff,0xffffffff),(0x80000000,100,3,0x7fffffff)]
random.seed(1);T += [tuple(random.getrandbits(32) for _ in range(4)) for i in range(20)]
for x in T:
 e=emu(*x);q=calc(*x);print(tuple(hex(z) for z in x),hex(e),hex(q),e==q)