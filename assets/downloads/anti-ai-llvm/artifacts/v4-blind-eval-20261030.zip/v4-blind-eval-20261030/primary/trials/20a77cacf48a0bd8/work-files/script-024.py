# compact cross-check at unsigned edges against candidate rule
from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm64_const import *
with open('target.so','rb') as f:
 e=ELFFile(f);seg=[(p['p_vaddr'],p['p_memsz'],p.data()) for p in e.iter_segments() if p['p_type']=='PT_LOAD']
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
for a,m,z in seg:
 try:u.mem_map(a&~4095,((a+m+4095)&~4095)-(a&~4095))
 except:pass
 u.mem_write(a,z)
u.mem_map(0x100000,4096);u.mem_map(0x200000,0x20000)
def hk(uc,a,s,d):
 if a==0x45ac:uc.reg_write(UC_ARM64_REG_X0,0);uc.reg_write(UC_ARM64_REG_PC,0x45b0)
 if a==0x100000:uc.emu_stop()
u.hook_add(UC_HOOK_CODE,hk)
def run(q):
 u.reg_write(UC_ARM64_REG_SP,0x21fff0);u.reg_write(UC_ARM64_REG_LR,0x100000)
 for r,v in zip([UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3],q):u.reg_write(r,v)
 u.emu_start(0x456c,0x100004,count=1000000);return u.reg_read(UC_ARM64_REG_W0)
B=[0,1,2,99,100,101,102,0x7fffffff,0x80000000,0xfffffffe,0xffffffff]
C=[0,1,2,3,4,0x7fffffff,0x80000000,0xfffffffe,0xffffffff]
for b in B:
 print(hex(b),[hex(run((0xabcdef01,b,c,0x13579bdf))) for c in C])