import pkgutil
mods=sorted(x.name for x in pkgutil.iter_modules())
for q in ['capstone','angr','r2pipe','keystone','lief','binaryninja','pwn','pwntools','unicorn','llvmlite']:
 print(q,q in mods)
print([x for x in mods if any(k in x.lower() for k in ['arm','disasm','elf','cap','llvm'])])