import struct
D=open('target.so','rb').read();e_shoff=struct.unpack_from('<Q',D,40)[0]; es, n, si=struct.unpack_from('<HHH',D,58); sh=[]
for i in range(n):sh.append(struct.unpack_from('<IIQQQQIIQQ',D,e_shoff+i*es))
strtab=D[sh[si][4]:sh[si][4]+sh[si][5]]
for x in sh:
 no=x[0];name=strtab[no:strtab.find(b'\0',no)].decode();print(name,hex(x[3]),hex(x[4]),hex(x[5]),hex(x[2]))