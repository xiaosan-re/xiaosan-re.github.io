from unicorn import *
from unicorn.arm64_const import *
import itertools
blob=open('target.so','rb').read()
def R(A):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
 for i,x in enumerate(A):u.reg_write(UC_ARM64_REG_X0+i,x)
 u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000)
 def h(u,x,s,z):
  if x==0x6e74:u.reg_write(UC_ARM64_REG_X0,0);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=100000);return u.reg_read(UC_ARM64_REG_W0)
# stage,state,epoch, fourth candidates and permutations
for i in [0,1,2,3,7,17,47]:
 vals=(i,i%7,17+i,1)
 print('stage',i,'canonical',vals,hex(R(vals)))
for p in itertools.permutations((0,0,17,1)):
 x=R(p)
 if x<0x80000000:print('VALID?',p,hex(x))
# vary each input canonical stage 0 and 1
for i in [0,1,2]:
 print('ROW',i)
 for d in [0,1,2,10,100,149,279,409,9299,9300,10000,0xffffffff]:
  print(d,hex(R((i,i%7,17+i,d))),end=';')
 print()