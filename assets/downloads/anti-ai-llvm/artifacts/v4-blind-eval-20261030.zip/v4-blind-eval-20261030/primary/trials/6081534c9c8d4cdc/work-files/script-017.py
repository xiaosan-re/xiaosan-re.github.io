import ctypes
lib=ctypes.CDLL('/opt/homebrew/lib/libcapstone.dylib')
class I(ctypes.Structure): _fields_=[('id',ctypes.c_uint),('address',ctypes.c_uint64),('size',ctypes.c_uint16),('bytes',ctypes.c_ubyte*24),('mnemonic',ctypes.c_char*32),('op_str',ctypes.c_char*160),('detail',ctypes.c_void_p)]
h=ctypes.c_size_t();lib.cs_open(1,0,ctypes.byref(h));lib.cs_disasm.restype=ctypes.c_size_t
with open('target.so','rb') as f:data=f.read()
for base in range(0x4560,0x4b41,0xbc):
 b=data[base:base+0xbc];buf=(ctypes.c_ubyte*len(b)).from_buffer_copy(b);p=ctypes.POINTER(I)();n=lib.cs_disasm(h,buf,len(b),base,0,ctypes.byref(p))
 print('\nFUNC',hex(base), 'n',n)
 for j in range(n):
  x=p[j]; m=x.mnemonic.decode();o=x.op_str.decode()
  if m in ('mov','movk','adr','csel','bl','br','blr') or x.address in (base+0x44,base+0x48,base+0x7c,base+0x80,base+0x84,base+0x88):print(f'{x.address:x}: {m} {o}')
 lib.cs_free(p,n)
lib.cs_close(ctypes.byref(h))