S=0xe4a7252e
for base in [129,249,399]:
 p=(base*S)&0xffffffff
 x=(p*85)&0xffffffff
 q=(x*0x51eb851f)>>37
 x95=(q*95)&0xffffffff
 q95=(x95*0x51eb851f)>>37
 print(base,hex(p),hex(x),q,q95)
