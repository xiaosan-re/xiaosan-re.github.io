from elftools.elf.elffile import ELFFile
from capstone import *
P='target.so'
with open(P,'rb') as f:
 e=ELFFile(f)
 print('machine',e['e_machine'],'entry',hex(e['e_entry']))
 for s in e.iter_sections():
  print(s.name,hex(s['sh_addr']),hex(s['sh_offset']),hex(s['sh_size']),s['sh_flags'])
 sym=e.get_section_by_name('.dynsym')
 for x in sym.iter_symbols():
  if x.name: print('SYM',x.name,hex(x['st_value']),x['st_size'],x['st_info']['type'])
 text=e.get_section_by_name('.text'); data=text.data(); base=text['sh_addr']
 md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN)
 off=0x456c-base
 for i in md.disasm(data[off:off+512],0x456c): print(f'{i.address:08x}: {i.mnemonic:8} {i.op_str}')