from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
import collections,random
B=0x100000;ST=0x200000;END=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x.header.p_vaddr,x.data()) for x in e.iter_segments() if x.header.p_type=='PT_LOAD']
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000);u.mem_map(ST,0x10000);u.mem_map(END,0x1000)
for v,d in segs:u.mem_write(B+v,d)
def R(a):
 u.reg_write(UC_ARM64_REG_SP,ST+0x8000);u.reg_write(UC_ARM64_REG_X30,END)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 u.emu_start(B+0x32c,END,count=1000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
base=[36,82,74,59]
for pos in range(4):
 groups=[];last=None;start=0
 for x in range(0,301):
  a=base.copy();a[pos]=x;o=R(a)
  if o!=last:
   if last is not None:groups.append((start,x-1,last))
   start=x;last=o
 groups.append((start,300,last))
 print('pos',pos,[(a,b,hex(o)) for a,b,o in groups])
# all small tuples search outputs and examples
c=collections.Counter();ex={}
for _ in range(100000):
 a=tuple(random.randrange(0,256) for _ in range(4));o=R(a);c[o]+=1;ex.setdefault(o,a)
print('dist unique',len(c)); print([(hex(o),n,ex[o]) for o,n in c.most_common(30)])
