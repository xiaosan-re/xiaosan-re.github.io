import struct
b=open('target.so','rb').read()
for a in range(0x32c,0x7a0,4):
 w=struct.unpack_from('<I',b,a)[0]
 print(f'{a:04x} {w:08x}')