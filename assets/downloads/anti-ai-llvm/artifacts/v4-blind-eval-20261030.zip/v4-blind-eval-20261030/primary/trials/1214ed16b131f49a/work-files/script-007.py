from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
p='target.so'
with open(p,'rb') as f:
 e=ELFFile(f)
 print([(s.name,hex(s['sh_addr']),hex(s['sh_offset']),hex(s['sh_size'])) for s in e.iter_sections()])
 sec=e.get_section_by_name('.text'); data=sec.data(); base=sec['sh_addr']
 md=Cs(CS_ARCH_ARM64,CS_MODE_ARM)
 start=0x38cc; blob=data[start-base:start-base+1704]
 for i in md.disasm(blob,start): print(f'{i.address:04x}: {i.mnemonic:8} {i.op_str}')