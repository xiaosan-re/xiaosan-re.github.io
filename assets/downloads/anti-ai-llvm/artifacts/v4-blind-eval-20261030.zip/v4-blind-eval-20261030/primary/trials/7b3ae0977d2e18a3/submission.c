#include <stdint.h>

static uint32_t mix32(uint32_t x) {
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

uint32_t recovered(uint32_t a, uint32_t b, uint32_t c, uint32_t d) {
    uint32_t token;
    uint32_t bucket;
    uint32_t value;
    static const uint32_t price[3] = { 129u, 249u, 399u };

    if (b < 1u || b > 100u)
        return UINT32_C(0x80000001);
    if (c > 2u)
        return UINT32_C(0x80000002);

    token = mix32(a ^ UINT32_C(0x9b05606f));
    if (d != token)
        return UINT32_C(0x80000003);

    value = b * price[c];
    if (b >= 10u)
        value = (value * 85u) / 100u;

    bucket = mix32(a + UINT32_C(0x7188bda9)) & 7u;
    if (bucket == 3u)
        value = (value * 95u) / 100u;

    return value;
}
