import struct
b=open('target.so','rb').read()
for a in range(0x5008,0x52d4,4):print(f'{a:04x} {struct.unpack_from("<I",b,a)[0]:08x}')