import struct
b=open('target.so','rb').read()
for a in range(0x5a34,0x5b0c,4):print(f'{a:04x} {struct.unpack_from("<I",b,a)[0]:08x}')