from unicorn import *
from unicorn.arm64_const import *
BASE=0x100000;STACK=0x200000;STOP=0x300000; blob=open('target.so','rb').read(); R=[getattr(__import__('unicorn.arm64_const',fromlist=['x']),f'UC_ARM64_REG_X{i}') for i in range(31)]
def run(args):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(BASE,0x10000);u.mem_write(BASE,blob[:2032]);u.mem_write(BASE+0x47f0,blob[0x7f0:0x8e0]);u.mem_map(STACK,0x10000);u.mem_map(STOP,0x1000);u.reg_write(UC_ARM64_REG_SP,STACK+0x8000);u.reg_write(UC_ARM64_REG_LR,STOP)
 for r,v in zip(R[:4],args):u.reg_write(r,v)
 states=[]
 def hk(uc,a,z,d):
  if a==BASE+0x4fc:states.append(uc.reg_read(UC_ARM64_REG_W4))
  if a==STOP:uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,hk)
 try:u.emu_start(BASE+0x32c,STOP+4,count=10000)
 except: return None,states
 return u.reg_read(UC_ARM64_REG_W0),states
vals=[0,1,2,3,4,5,8,9,10,15,16,31,32,63,64,99,100,101,102,255,256,0x7fffffff,0x80000000,0xffffffff]
for pos in range(4):
 print('POS',pos)
 old=None
 for v in vals:
  a=[0,0,0,0];a[pos]=v; out,st=run(a); key=(out,tuple(st))
  if key!=old: print(hex(v),'->',hex(out) if out is not None else None,[hex(x) for x in st]);old=key
