from unicorn import *
from unicorn.arm64_const import *
blob=open('target.so','rb').read(); u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
for i,x in enumerate((0x11,0x22,0x33,0x44)):u.reg_write(UC_ARM64_REG_X0+i,x)
u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000)
def h(u,a,s,d):
 if a==0x6e74:u.reg_write(UC_ARM64_REG_X0,1);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
 if a in (0x62a0,0x62e8,0x6318,0x62b4): print(hex(a),*[hex(u.reg_read(UC_ARM64_REG_X0+i)) for i in range(4)])
u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=10000)
print('ret',hex(u.reg_read(UC_ARM64_REG_W0)))