# Recovered VM-level model (not native instruction emulation), using plaintext records decrypted statically.
import struct
b=open('target.so','rb').read(); C=[0xbc479312,0x39ac5979,0xb79007c4,0x2d84cc53,0xabe8babe,0x21dd6705,0x9fc12d90,0x15351bff,0x9319c04a]
u=lambda x:x&0xffffffff
def mix(x):x=u(x^(x>>16));x=u(x*0x7feb352d);x=u(x^(x>>15));x=u(x*0x846ca68b);return u(x^(x>>16))
R=[]
for i in range(92):R.append([struct.unpack_from('<I',b,0x2d0+36*i+4*j)[0]^mix(u(i*0x9e3779b9)^C[j]) for j in range(9)])
def sx(v,bits):
 bits &=31
 if bits==0:return v if v<0x80000000 else v-0x100000000
 m=1<<(bits-1);v&=(1<<bits)-1;return (v^m)-m
def run(a,bv,c,d,trace=False):
 reg=[0]*70;reg[58]=u(a);reg[23]=u(bv);reg[27]=u(c);reg[14]=u(d);pc=0
 for step in range(1000):
  op,dst,A,B,Cc,imm,width,nxt,alt=R[pc]; av=reg[A];bv2=reg[B];cv=reg[Cc]
  if trace: print(step,pc,f'{op:08x}',dst,A,B,Cc,hex(imm),width,nxt,alt,'vals',hex(av),hex(bv2),hex(cv))
  out=None
  if op==0x31ef8a34: out=imm
  elif op==0x432b31fa: out=av
  elif op==0xa9050067: out=u(bv2+av)
  elif op==0x778380a7: out=u(bv2*av)
  elif op==0xc179bd02: out=bv2^av
  elif op==0xcc213f3b: out=bv2&av
  elif op==0x68a9af5d: out=av>>(bv2&31)
  elif op==0x2d296d65: out=av//(1 if bv2==0 else cv)
  elif op==0xfd23a89f:
   if imm==32:out=int(bv2==av)
   elif imm==33:out=int(cv!=av)
   elif imm==34:out=int(cv>av)
   elif imm==35:out=int(cv>=av)
   elif imm==36:out=int(cv<av)
   elif imm==37:out=int(cv<=av)
   elif imm==38:out=int(sx(bv2,width)>sx(av,width))
   elif imm==39:out=int(sx(bv2,width)>=sx(av,width))
   elif imm==40:out=int(sx(bv2,width)<sx(av,width))
   elif imm==41:out=int(sx(bv2,width)<=sx(av,width))
   else: out=0
  elif op==0x86b9c54f: out=bv2 if av!=0 else cv
  elif op==0xd515b9c4: pc=nxt;continue
  elif op==0x9153976a: pc=nxt if av!=0 else alt;continue
  elif op==0xe9855c9d: return av,step
  else: raise Exception(hex(op))
  bits=width&31;mask=0xffffffff if bits==0 else (1<<bits)-1
  reg[dst]=u(out)&mask;pc=nxt
 raise Exception('loop')
for q in [(0,0,0,0),(1,1,1,1),(100,9300,17,0),(149,9300,17,0),(1000,10,5,2),(0xffffffff,0xffffffff,0xffffffff,0xffffffff),(100,5,3,1)]:
 try: print(q,run(*q))
 except Exception as e:print(q,e)
print('trace sample');run(100,9300,17,0,True)