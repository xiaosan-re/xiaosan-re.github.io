from elftools.elf.elffile import ELFFile
from capstone import *
with open('target.so','rb') as f:
 e=ELFFile(f); s=e.get_section_by_name('.text'); code=s.data(); base=s.header.sh_addr
 md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN)
 for i in md.disasm(code,base): print(f'{i.address:04x}: {i.mnemonic:8} {i.op_str}')
