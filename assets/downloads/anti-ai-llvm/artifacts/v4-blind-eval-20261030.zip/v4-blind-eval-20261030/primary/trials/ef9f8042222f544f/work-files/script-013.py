import ctypes.util, pkgutil
print('capstone lib',ctypes.util.find_library('capstone'))
print([m.name for m in pkgutil.iter_modules() if any(x in m.name.lower() for x in ['disasm','arm','binary','elf','pwntools','lief'])])