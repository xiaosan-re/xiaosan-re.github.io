from unicorn import *
from unicorn.arm64_const import *
import struct
blob=open('target.so','rb').read()
def vals(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x10000);u.mem_write(0,blob);u.mem_map(0x100000,0x20000);u.mem_map(0x200000,0x1000)
 for i,x in enumerate((a,1,0,0)):u.reg_write(UC_ARM64_REG_X0+i,x)
 u.reg_write(UC_ARM64_REG_SP,0x118000);u.reg_write(UC_ARM64_REG_X30,0x200000);it=[-1];o=[]
 def h(u,x,s,z):
  if x==0x6e74:u.reg_write(UC_ARM64_REG_X0,0);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_X30))
  if x==0x530c:
   it[0]+=1
   if 87<=it[0]<=119:
    sp=u.reg_read(UC_ARM64_REG_SP);w=struct.unpack('<56I',u.mem_read(sp,224));o.append((it[0],w[0x80//4],w[0x90//4],w[0x10//4]))
 u.hook_add(UC_HOOK_CODE,h);u.emu_start(0x456c,0x200000,count=100000);return o
for a in [1,2,100,0x12345678,0xffffffff]:
 print('A',hex(a));print(vals(a))