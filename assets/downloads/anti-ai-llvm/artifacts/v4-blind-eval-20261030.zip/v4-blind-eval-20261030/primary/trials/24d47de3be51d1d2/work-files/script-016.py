from elftools.elf.elffile import ELFFile
import struct
with open('target.so','rb') as f:
 e=ELFFile(f); s=e.get_section_by_name('.text'); d=s.data(); base=s['sh_addr']
 for a in range(0x38cc,0x3f74,4):
  w=struct.unpack_from('<I',d,a-base)[0]
  if w>>26 in (0b000101,0b100101):
   imm=w&0x3ffffff
   if imm&(1<<25):imm-=1<<26
   print(hex(a), 'BL' if w>>26==0b100101 else 'B',hex(a+imm*4),hex(w))
