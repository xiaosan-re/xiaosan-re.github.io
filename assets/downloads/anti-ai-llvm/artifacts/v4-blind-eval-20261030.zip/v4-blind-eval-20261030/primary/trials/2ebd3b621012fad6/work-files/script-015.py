u=lambda x:x&0xffffffff
C={
'w14':0xbb686f72^0x7ae645a4,
'w13':0xbb686f72^0x40991e6f,
'w12':0x2318fa58,
}
for k,v in C.items(): print(k,hex(v))
print('initial',hex(u(C['w14']+C['w12'])))
print('w16',hex(u(C['w13']+C['w12'])))
# state IDs from disassembly
states=[0x8d141411,0xa5af7ad0,0xf2f756ae,0x02b508d0,0x101b3928,0x4d4cb923,0x4d4cb924,0xe4a7252d,0xe576aa42,0xd1cec84c,0xc3b21eb8,0xc3b21eb9,0xd845e9c0,0xe8352f76,0xe8352f77,0xf07e66ec,0x1f0a6b75,0x26140178,0x26140179,0x34b8620e]
print('\nstates sorted signed:')
for x in sorted(states,key=lambda x:(x>=0x80000000,x if x<0x80000000 else x-2**32)): print(hex(x))
# handler XOR outputs
pairs=[(0xa5af7ad0,0xbaa511a5),(0xe576aa42,0xd1cec84c),(0xd845e9c0,0xc74f82b5),(0xf07e66ec,None),(0x1f0a6b75,None),(0x26140179,0x12ac6377),(0x8d141411,0xb9ac761f),(0xe4a7252d,None),(0xc3b21eb9,0xf70a7cb7),(0x4d4cb924,None)]
for a,x in pairs:
 if x is not None: print(hex(a),'xor',hex(x),'=',hex(a^x))