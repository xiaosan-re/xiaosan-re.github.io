# Static disassembly only: anti-analysis gate range 0x4f9c..0x5310
import ctypes,ctypes.util
from pathlib import Path
L=ctypes.CDLL(ctypes.util.find_library('capstone'))
class I(ctypes.Structure): _fields_=[('id',ctypes.c_uint),('address',ctypes.c_uint64),('size',ctypes.c_uint16),('bytes',ctypes.c_ubyte*24),('mnemonic',ctypes.c_char*32),('op_str',ctypes.c_char*160),('detail',ctypes.c_void_p)]
L.cs_open.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.POINTER(ctypes.c_size_t)];L.cs_disasm.argtypes=[ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint64,ctypes.c_size_t,ctypes.POINTER(ctypes.POINTER(I))];L.cs_disasm.restype=ctypes.c_size_t
h=ctypes.c_size_t();L.cs_open(1,0,ctypes.byref(h));r=Path('target.so').read_bytes();a=0x4f9c;z=0x5310;buf=ctypes.create_string_buffer(r[a:z]);p=ctypes.POINTER(I)();n=L.cs_disasm(h,buf,z-a,a,0,ctypes.byref(p))
for j in range(n):
 x=p[j];print(f'{x.address:04x}: {x.mnemonic.decode():8} {x.op_str.decode()}')
