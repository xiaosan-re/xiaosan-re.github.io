# Probe large subtotals to expose the exact basis-point rate.
from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
B=0x100000;S=0x200000;E=0x300000
with open('target.so','rb') as f:e=ELFFile(f);segs=[(x['p_vaddr'],x.data()) for x in e.iter_segments() if x['p_type']=='PT_LOAD']
def run(a):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(B,0x10000)
 for v,d in segs:u.mem_write(B+v,d)
 u.mem_write(B+0x4f9c,b'\xc0\x03\x5f\xd6');u.mem_map(S,0x10000);u.mem_map(E,0x1000);u.reg_write(UC_ARM64_REG_SP,S+0x8000);u.reg_write(UC_ARM64_REG_X30,E)
 for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),a):u.reg_write(r,v)
 u.emu_start(B+0x38cc,E,count=100000);return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
for b in [99,999,9999,65535,1000000]:
 print('b',b)
 for a,d in [(1,0),(2,0),(3,0),(4,0),(5,0),(10,0),(1,2),(7,5),(47,11),(123456789,987654321)]:
  o=run((a,b,0,d)); sub=(149*(b+1))&0xffffffff
  print(a,d,o,sub, (o*10000//sub if sub else None), 'diff', (sub-o)&0xffffffff)
# invalid boundary candidates for quantity
for b in [0x7ffffffe,0x7fffffff,0x80000000,0xfffffffe,0xffffffff]:print('bound',b,run((10,b,0,0)))