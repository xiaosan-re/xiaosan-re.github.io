from elftools.elf.elffile import ELFFile
from capstone import *
with open('target.so','rb') as f:
 e=ELFFile(f)
 print([(s.name,hex(s['sh_addr']),hex(s['sh_offset']),s['sh_size']) for s in e.iter_sections()])
 sym=e.get_section_by_name('.dynsym').get_symbol_by_name('demo_evaluate')[0]
 print('sym',hex(sym['st_value']),sym['st_size'])
 for seg in e.iter_segments():
  if seg['p_type']=='PT_LOAD' and seg['p_vaddr']<=sym['st_value']<seg['p_vaddr']+seg['p_filesz']:
   f.seek(seg['p_offset']+sym['st_value']-seg['p_vaddr']); data=f.read(sym['st_size']); break
md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN)
for i in md.disasm(data,sym['st_value']): print(f'{i.address:04x}: {i.mnemonic:8} {i.op_str}')