M=0xffffffff
u=lambda x:x&M
C={}
C['hstate']=u((0xbb686f72^0x7ae645a4)+0x2318fa58)
C['w16']=u((0xbb686f72^0x40991e6f)+0x2318fa58)
print({k:hex(v) for k,v in C.items()})
# map fixed xor transitions
trans={
0xa5af7ad0:0xbaa511a5,
0xd845e9c0:0xc74f82b5,
0xe576aa42:0xd1cec84c,
0x7aad0288:None,
0x26140179:0x12ac6377,
0x8d141411:0xb9ac761f,
0xe4a7252e:None,
0xc3b21eb9:0xf70a7cb7,
0x4d4cb924:None,
0xe8352f77:0x184b499b,
0x101b3929:0x9d0f2d38,
}
for s,x in trans.items(): print(hex(s),'->',hex(s^x) if x else 'dynamic')
# dynamic XOR option destinations values
states=set(trans)|{0x34b8620e,0xf2f756af,0x02b508d0,0x1f0a6b75,0xf07e66ec}
opts=[0x5cb903f1,0x37e1bbac,0x4ff9b1f4,0x8efea79d,0x01d18f6c,0x9e0a27a6,0xe0655fc5,0x7d6a72fd,0xf73f4402,0xef740d99,C['w16']]
for s in [0x7aad0288,0xe4a7252e,0x4d4cb924,0xf07e66ec,0x1f0a6b75,0x02b508d0]:
 print('\n',hex(s))
 for o in opts+[0xa71a7200,0xdaf0e110]:
  d=s^o
  if d in states: print(hex(o),'->',hex(d))
print('initial',hex(C['hstate']), 'in states?',C['hstate'] in states)
