import glob
print(glob.glob('/opt/homebrew/lib/python*/site-packages/capstone*'))
print(glob.glob('/opt/homebrew/Cellar/capstone/**/*',recursive=True)[:20])