import shutil
for x in ['llvm-objdump','aarch64-linux-gnu-objdump','objdump','clang','llvm-mc']:
 print(x,shutil.which(x))