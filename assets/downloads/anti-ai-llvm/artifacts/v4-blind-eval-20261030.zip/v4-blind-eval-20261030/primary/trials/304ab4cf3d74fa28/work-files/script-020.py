import pkgutil
print([m.name for m in pkgutil.iter_modules() if any(s in m.name.lower() for s in ['capstone','arm','disasm','opcode','aarch'])][:100])