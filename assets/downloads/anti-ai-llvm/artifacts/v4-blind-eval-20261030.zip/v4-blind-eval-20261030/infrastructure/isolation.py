"""macOS Seatbelt worker boundary. Trusted broker/controller stay outside it."""
import json, os, pathlib, resource, signal, subprocess, threading, tempfile


def quote(path):
    return json.dumps(str(path))


def profile(workdir, python):
    workdir = pathlib.Path(workdir).resolve()
    pyroot = pathlib.Path(python).absolute().parent.parent
    # No home directory, project root, network, process inspection or credential access.
    reads = ['/usr', '/bin', '/sbin', '/System', '/Library/Apple', '/opt/homebrew',
             '/private/var/db/dyld', str(pyroot), str(workdir)]
    return '\n'.join(['(version 1)', '(deny default)', '(allow process-exec)',
        '(allow sysctl-read)',
        '(allow file-read-metadata)', '(allow file-read* (literal "/"))',
        '(allow file-read* ' + ' '.join('(subpath '+quote(p)+')' for p in reads) + ')',
        '(allow file-read* file-write* (literal "/dev/null") (literal "/dev/urandom") (literal "/dev/random"))',
        '(allow file-write* (subpath '+quote(workdir)+'))'])


def run(workdir, python, args, timeout=30, memory_mb=2048, cpu_seconds=30):
    workdir = pathlib.Path(workdir).resolve()
    # The profile is passed as an argument, never placed where an attacker can modify it.
    def limits():
        os.setsid()
        resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds))
        resource.setrlimit(resource.RLIMIT_FSIZE, (32*1024**2, 32*1024**2))
        resource.setrlimit(resource.RLIMIT_NOFILE, (128, 128))
    env = {'PATH':'/opt/homebrew/bin:/usr/bin:/bin', 'HOME':str(workdir),
           'TMPDIR':str(workdir), 'PYTHONDONTWRITEBYTECODE':'1', 'PYTHONNOUSERSITE':'1',
           'LANG':'en_US.UTF-8', 'LC_ALL':'en_US.UTF-8'}
    stdout_file=tempfile.TemporaryFile(); stderr_file=tempfile.TemporaryFile()
    proc = subprocess.Popen(['/usr/bin/sandbox-exec', '-p', profile(workdir, python), *args],
        cwd=workdir, env=env, stdin=subprocess.DEVNULL, stdout=stdout_file, stderr=stderr_file, preexec_fn=limits)
    stop = threading.Event()
    memory_exceeded = []
    def watch_memory():
        while not stop.wait(0.2):
            try:
                rows=subprocess.check_output(["/bin/ps","-axo","pgid=,rss="], text=True)
                rss=sum(int(row.split()[1]) for row in rows.splitlines() if row.split() and int(row.split()[0])==proc.pid)
                if rss > memory_mb*1024:
                    memory_exceeded.append(True); os.killpg(proc.pid,signal.SIGKILL); return
            except (ProcessLookupError,subprocess.SubprocessError):return
    watcher=threading.Thread(target=watch_memory,daemon=True);watcher.start()
    try:
        out, err = proc.communicate(timeout=timeout)
        timed_out=False
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        out, err = proc.communicate()
        timed_out=True
    try: os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError: pass
    stop.set(); watcher.join(timeout=1)
    stdout_file.seek(0);stderr_file.seek(0);out=stdout_file.read(200000);err=stderr_file.read(200000)
    stdout_file.close();stderr_file.close()
    return {'returncode':proc.returncode, 'timed_out':timed_out, 'memory_exceeded':bool(memory_exceeded),
            'stdout':out[:200000].decode(errors='replace'), 'stderr':err[:200000].decode(errors='replace')}
