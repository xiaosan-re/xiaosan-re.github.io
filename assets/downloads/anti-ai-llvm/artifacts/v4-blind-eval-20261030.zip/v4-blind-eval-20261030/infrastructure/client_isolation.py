"""Outer Seatbelt boundary for trusted inference CLI and its fixed MCP subtree.

Inner isolation.py further restricts attacker-written Python. This outer policy
exists because a residual native image tool must not read arbitrary host files.
The controller/oracle remains outside both sandboxes.
"""
import json
import pathlib


def _q(value):
    return json.dumps(str(value))


def profile(work, private, here):
    work = pathlib.Path(work).resolve()
    private = pathlib.Path(private).resolve()
    here = pathlib.Path(here).resolve()
    if work == pathlib.Path('/') or private == pathlib.Path('/') or work == private:
        raise ValueError('invalid isolation roots')
    reads = [
        '/usr', '/bin', '/sbin', '/System', '/Library/Apple',
        '/Library/Developer/CommandLineTools', '/Library/Keychains',
        '/opt/homebrew', '/private/etc', '/private/var/db/dyld',
        '/Applications/IDA Professional 9.4.app',
        '/Applications/IDA Professional 9.5.app',
        str(pathlib.Path.home()/'.idapro/venv'),
        '/private/tmp/anti-rev-ida-pro-mcp',
    ]
    read_files = [here/'broker.py', here/'isolation.py', here/'relay.py',
                  private/'broker.json', private/'rea.json']
    rw_roots = [work, private/'cli-home', private/'ida']
    rw_files = [private/name for name in [
        'fixed-target.so', 'tools.jsonl', 'submission.c',
        'agent.jsonl', 'agent.stderr']]
    return '\n'.join([
        '(version 1)', '(deny default)',
        # Only trusted CLI/backend code can exercise these broad capabilities;
        # arbitrary Python is intersected with the stricter inner sandbox.
        '(allow process-exec process-fork)',
        '(allow process-info*)', '(allow signal)',
        '(allow sysctl-read)', '(allow mach-lookup)',
        '(allow network*)',
        '(allow file-read-metadata)',
        '(allow file-read* (literal "/"))',
        '(allow file-read* '+' '.join('(subpath '+_q(p)+')'for p in reads)+')',
        '(allow file-read* '+' '.join('(literal '+_q(p)+')'for p in read_files)+')',
        '(allow file-read* file-write* '+' '.join('(subpath '+_q(p)+')'for p in rw_roots)+')',
        '(allow file-read* file-write* '+' '.join('(literal '+_q(p)+')'for p in rw_files)+')',
        '(allow file-read* file-write* (literal "/dev/null"))',
        '(allow file-read* (literal "/dev/random") (literal "/dev/urandom"))',
    ])
