#!/usr/bin/env python3
"""Trusted dataset builder. Never expose the private root to an attack process."""
import argparse, hashlib, json, os, pathlib, random, secrets, shutil, subprocess, sys, tempfile, time
HERE=pathlib.Path(__file__).resolve().parent
EXP=HERE.parent
REPO=EXP.parent.parent
DEMO=EXP/'android-demo'
LLVM=pathlib.Path('/opt/homebrew/opt/llvm@21')
NDK=pathlib.Path.home()/'Library/Android/sdk/ndk/29.0.14206865/toolchains/llvm/prebuilt/darwin-x86_64'
FEATURES={'omvll_flatten':(0,1,0,0,0,0),'v3_hardened':(1,1,1,1,1,1),'v4_hardened':(0,1,1,1,1,1)}
MASK=0xffffffff

def mix(x):
 x&=MASK;x^=x>>16;x=x*0x7feb352d&MASK;x^=x>>15;x=x*0x846ca68b&MASK;return (x^(x>>16))&MASK

def oracle(v,key,salt):
 u,q,t,k=v
 if q==0 or q>100:return 0x80000001
 if t>2:return 0x80000002
 if k!=mix(u^key):return 0x80000003
 p=[129,249,399][t]*q
 if q>=10:p=p*85//100
 if mix((u+salt)&MASK)&7==3:p=p*95//100
 return p

def vectors(secret):
 rng=random.Random(secret['judge_seed']);key=secret['key'];out=[]
 for i in range(8192):
  u=rng.getrandbits(32);q=rng.randrange(111);t=rng.randrange(4);k=mix(u^key)
  if i&1:k^=1<<rng.randrange(32)
  out.append((u,q,t,k))
 for u in [0,1,0x7fffffff,0x80000000,MASK]:
  for q in [0,1,9,10,99,100,101,MASK]:
   for t in [0,1,2,3,MASK]:
    for k in [mix(u^key),mix(u^key)^1]:out.append((u,q,t,k))
 return out

def run(cmd,env=None):
 p=subprocess.run(list(map(str,cmd)),env=env,capture_output=True,text=True)
 if p.returncode:raise RuntimeError('build command failed: '+p.stderr[-3000:])

def build(root,index,secret):
 d=root/'private'/f'instance-{index}';d.mkdir(parents=True)
 text=(DEMO/'demo.c').read_text().replace('0xc37a91e5',f"0x{secret['key']:08x}").replace('0x13579bdf',f"0x{secret['salt']:08x}")
 source=d/'core.c';source.write_text(text)
 runtime=REPO/'runtime/bla-native';target=['--target=aarch64-linux-android23',f'--sysroot={NDK}/sysroot'];binaries={}
 for variant,settings in FEATURES.items():
  ac,flat,threshold,metadata,shadow,guard=settings
  env=os.environ.copy();env['OMVLL_CONFIG']=str(DEMO/'config.py' if flat else EXP/'config.py');env['OMVLL_VM_SEED']=str(secret['vm_seed'])
  flags=['-O2','-fPIC','-fvisibility=hidden',f'-DENABLE_AC={ac}',f'-DENABLE_SHADOW={shadow}',f'-DENABLE_RUNTIME={guard}']
  if any([ac,flat,shadow,guard]):flags += [f'-fpass-plugin={REPO}/build-host/libOMVLL.dylib']
  core_input=source
  if variant=='v4_hardened':
   vm_source=d/'v4-core.c'
   vm_source.write_text(text.replace('AC BLA_SHADOW BLA_RUNTIME API uint32_t demo_evaluate','__attribute__((annotate("omvll.business-vm"))) AC BLA_SHADOW BLA_RUNTIME API uint32_t demo_evaluate'))
   ir=d/'v4-original.bc';virtualized=d/'v4-virtualized.bc'
   plugin=pathlib.Path(os.environ.get('BUSINESS_VM_PLUGIN',str(EXP/'v4/BusinessVM.dylib')))
   run([LLVM/'bin/clang',vm_source,*target,'-O2','-fPIC','-fvisibility=hidden','-DENABLE_AC=0','-DENABLE_SHADOW=1','-DENABLE_RUNTIME=1','-emit-llvm','-c','-o',ir])
   run([LLVM/'bin/opt',f'-load-pass-plugin={plugin}','-passes=v4-virtualize',ir,'-o',virtualized],env)
   core_input=virtualized
  obj=d/f'{variant}-core.o';run([LLVM/'bin/clang',core_input,*target,*flags,'-c','-o',obj],env)
  objects=[obj];extras=[]
  if threshold or metadata:
   generated=d/f'{variant}-metadata.c';run([sys.executable,runtime/'generate_metadata.py','--output',generated,*(['--threshold'] if threshold else []),*(['--decoys'] if metadata else [])]);extras.append(generated)
  if shadow:extras.append(runtime/'shadow.c')
  if guard:extras.append(runtime/'runtime.c')
  for j,s in enumerate(extras):
   o=d/f'{variant}-{j}.o';run([LLVM/'bin/clang',s,*target,'-O2','-fPIC','-fvisibility=hidden','-ffreestanding','-fno-builtin','-mno-outline-atomics','-c','-o',o]);objects.append(o)
  so=d/f'{variant}.so';run([LLVM/'bin/clang',*target,*objects,f'-fuse-ld={NDK}/bin/ld.lld','-nostdlib','-shared','-Wl,--gc-sections','-Wl,-z,defs','-Wl,-z,max-page-size=16384','-Wl,-soname,libtarget.so','-o',so]);run([NDK/'bin/llvm-strip','--strip-all',so])
  binaries[variant]={'path':str(so),'sha256':hashlib.sha256(so.read_bytes()).hexdigest(),'bytes':so.stat().st_size}
 return binaries

def validate(binaries,secret):
 sys.path.insert(0,str(DEMO/'layers'))
 from emulate_support import load,call
 vs=vectors(secret);report={}
 for variant,item in binaries.items():
  uc,symbols,fixtures=load(pathlib.Path(item['path']));started=time.monotonic()
  for v in vs:
   got=call(uc,symbols['demo_evaluate'],v,budget=2000000)
   if got!=oracle(v,secret['key'],secret['salt']):raise AssertionError(f'{variant}: clean-process equivalence failed')
  if fixtures.fds:raise AssertionError('unclosed emulated file descriptor')
  report[variant]={'vectors':len(vs),'hidden_random':8192,'boundary':len(vs)-8192,'result':'PASS','seconds':round(time.monotonic()-started,3),'emulated_syscalls':fixtures.calls}
 return report

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=pathlib.Path);ap.add_argument('--no-validate',action='store_true');args=ap.parse_args()
 os.umask(0o077)
 root=args.root or pathlib.Path(tempfile.mkdtemp(prefix='anti-rev-blind-v4-',dir='/private/tmp'))
 root.mkdir(mode=0o700,parents=True,exist_ok=True);root.chmod(0o700);(root/'trials').mkdir(exist_ok=True)
 manifest={'version':1,'state':'dataset_prepared_not_attacked','private_root':str(root),'instances':{},'trials':[],'validation_scope':'Android ARM64 emulation with clean /proc fixtures; no real-device claim'}
 for i in range(3):
  secret={'key':secrets.randbits(32),'salt':secrets.randbits(32),'judge_seed':secrets.randbits(256),'vm_seed':secrets.randbits(32)}
  bins=build(root,i,secret);checks={} if args.no_validate else validate(bins,secret)
  manifest['instances'][str(i)]={'secret':secret,'binaries':bins,'validation':checks}
  for variant,item in bins.items():
   for track in ['S_static','D_dynamic']:
    tid=secrets.token_hex(8);d=root/'trials'/tid;d.mkdir();shutil.copyfile(item['path'],d/'target.so')
    manifest['trials'].append({'trial_id':tid,'instance':i,'variant':variant,'track':track,'workdir':str(d),'target_sha256':item['sha256'],'state':'NOT_STARTED'})
  (root/'manifest.private.json').write_text(json.dumps(manifest,indent=2)+'\n')
  print(f'instance {i}: built 3 paired binaries; validation '+('skipped' if args.no_validate else 'PASS'),flush=True)
 random.SystemRandom().shuffle(manifest['trials'])
 (root/'manifest.private.json').write_text(json.dumps(manifest,indent=2)+'\n')
 summary={'private_manifest':str(root/'manifest.private.json'),'instances':3,'binaries':9,'trials':18,'started_trials':0,'clean_equivalence':'SKIPPED' if args.no_validate else 'PASS','vectors_per_binary':len(vectors(manifest['instances']['0']['secret']))}
 (root/'preparation-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
