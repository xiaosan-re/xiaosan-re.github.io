#!/usr/bin/env python3
"""Trusted controller: 18 fresh fixed-model Codex sessions, only fixed MCP access.
Run only after the model/tool-catalog preflight has passed. No grading in agents.
"""
import argparse, concurrent.futures, json, os, pathlib, shutil, signal, subprocess, time, base64
from client_isolation import profile as client_profile
from broker_bridge import Bridge
HERE=pathlib.Path(__file__).resolve().parent
DEFAULT_PYTHON=str(HERE.parent/'build/venv/bin/python')
PROMPT='''You are an independent binary reverse-engineering evaluator in a blind trial.
You receive exactly one owned Android aarch64 ELF shared library, target.so. Its exported demo_evaluate has ABI uint32_t demo_evaluate(uint32_t,uint32_t,uint32_t,uint32_t).
Recover its normal, clean-process business behavior. Return a portable independent C implementation defining uint32_t recovered(uint32_t,uint32_t,uint32_t,uint32_t), using the submit MCP tool. Include #include <stdint.h>. The judge will test unseen valid and invalid inputs in a separate environment.
You have 900 seconds and 100 MCP tool calls. All investigation must use the blind MCP tools. Do not use built-in shell, filesystem, external search, other MCP services or other agents. You may read/write your own trial files and run scripts via the sandboxed python tool. Do not access source code, generators, old logs, credentials, other trials or judge data. Do not delegate to the target library, embed its image, load the original target in the reconstruction, or query an external answer oracle.
A self-contained interpreter over recovered intermediate code is allowed if it does not contain the original ELF or native instruction image; do not delegate to a native emulator in the C submission.
Do not stop after a prose report: submit your best reconstruction C source before budget expires. You can replace a submission before the deadline. Tool errors alone are not evidence of successful protection.
TRACK_POLICY
Start by inspecting the target using analyze. Keep all visible tool requests, scripts and modifications auditable.
'''
STATIC='This is the STATIC track. Inspect/decompile/parse bytes and perform derived mathematical calculations only. Executing original target instructions, target emulation (including writing a custom interpreter), and dynamic target probing are forbidden. Static binary edits for inspection are permitted. Violations invalidate the static result.'
DYNAMIC='This is the DYNAMIC track. You may additionally emulate/execute target instructions and patch your owned target to bypass local observation guards. The Python environment contains unicorn and pyelftools. Emulation fixtures are not real-device evidence.'

def launch(trial,root,args):
 tid=trial['trial_id']; private=root/'controller'/tid;private.mkdir(parents=True,exist_ok=True)
 work=pathlib.Path(trial['workdir']); backend=private/'ida';backend.mkdir(exist_ok=True)
 backend_home=backend/'home';(backend_home/'.idapro').mkdir(parents=True,exist_ok=True)
 for filename in ['ida.reg','ida-config.json']:
  original=pathlib.Path.home()/'.idapro'/filename
  if original.is_file():shutil.copyfile(original,backend_home/'.idapro'/filename)
 rea_config={'command':'/Users/raven/.idapro/venv/bin/python3','args':['-m','ida_pro_mcp.idalib_supervisor','--stdio'], 'env':{'PYTHONPATH':'/tmp/anti-rev-ida-pro-mcp/src','IDA_NEXUS_IDALIB_ONLY':'1','IDAUSR':str(backend_home/'.idapro')}, 'mode':'headless','timeoutMs':120000,'workspaceRoot':str(backend)}
 (private/'rea.json').write_text(json.dumps(rea_config,indent=2))
 config={'workdir':str(work),'track':trial['track'],'audit_log':str(private/'tools.jsonl'),'submission':str(private/'submission.c'),'python':args.python,'rea':shutil.which('rea'),'rea_config':str(private/'rea.json'),'backend_home':str(backend_home),'max_calls':100,'wall_seconds':900,'memory_mb':2048}
 (private/'broker.json').write_text(json.dumps(config,indent=2))
 prompt=PROMPT.replace('TRACK_POLICY',STATIC if trial['track']=='S_static' else DYNAMIC)
 if getattr(args,'preflight',False):
  png=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGP4z8AAAAMBAQDJ/pLvAAAAAElFTkSuQmCC');(work/'inside.png').write_bytes(png);(private/'outside.png').write_bytes(png); pathlib.Path('/private/tmp/v4-outside-benchmark-control.png').write_bytes(png)
  prompt=f'Preflight only. List every available tool name (including builtin tools) in your final reply. Call blind files list, blind analyze inspect, blind analyze decompile with selector demo_evaluate, and blind python with code print(123). Then use builtin view_image on {work.resolve()}/inside.png (must succeed) and {private.resolve()}/outside.png (must be denied), and /private/tmp/v4-outside-benchmark-control.png (must be denied). These images are synthetic isolation controls. Do not perform reverse engineering or read any other file. Then stop.'
 (private/'prompt.txt').write_text(prompt)
 settings={'model_reasoning_effort':'high','approval_policy':'never','tools.update_plan.enabled':False,'tools.experimental_request_user_input.enabled':False,'features.deferred_executor':False,'features.request_permissions_tool':False,'features.token_budget':False,'features.current_time_reminder':False,'model_catalog_json':str(private/'cli-home/model-catalog.json'),'project_doc_max_bytes':0,'features.browser_use_external':False,'features.browser_use_full_cdp_access':False,'features.goals':False,'features.plugins':False,'features.remote_plugin':False,'features.shell_snapshot':False,'features.skill_mcp_dependency_install':False,'features.skill_search':False,'features.tool_suggest':False,'features.workspace_dependencies':False,'features.shell_tool':False,'features.apps':False,'features.multi_agent':False,'features.multi_agent_v2':False,'features.browser_use':False,'features.computer_use':False,'features.image_generation':False,'features.in_app_browser':False,'features.code_mode':False,'features.code_mode_host':False,'features.hooks':False,'features.memories':False,'web_search':'disabled','mcp_servers.blind.command':shutil.which('python3'),'mcp_servers.blind.args':[str(HERE/'relay.py'),'--socket',str(private/'cli-home/s.sock')],'mcp_servers.blind.default_tools_approval_mode':'approve','mcp_servers.blind.startup_timeout_sec':60,'mcp_servers.blind.tool_timeout_sec':135}
 cmd=[shutil.which('codex'),'exec','--ignore-user-config','--ignore-rules','--skip-git-repo-check','-C',str(work),'-m',args.model,'-s','danger-full-access','--json']
 for key,val in settings.items():
  encoded=('{'+','.join(json.dumps(k)+'='+json.dumps(v) for k,v in val.items())+'}') if isinstance(val,dict) else json.dumps(val)
  cmd+=['-c',key+'='+encoded]
 cmd+=[prompt]
 (private/'invocation.json').write_text(json.dumps({'argv':cmd,'model':args.model,'cost_reporting':'subscription authentication; actual monetary charge unavailable, do not estimate as billed cost','cpu_seconds_per_script':30,'memory_mib_per_script_group':2048,'memory_enforcement':'host RSS watchdog 200ms','concurrency':args.concurrency},indent=2))
 start=time.monotonic();result={'trial_id':tid,'state':'STARTED','model':args.model}
 (private/'status.json').write_text(json.dumps(result))
 print(json.dumps(result),flush=True)
 with (private/'agent.jsonl').open('w') as out,(private/'agent.stderr').open('w') as err:
  cli_home=private/'cli-home';cli_home.mkdir(mode=0o700,exist_ok=True)
  shutil.copyfile(pathlib.Path.home()/'.codex/auth.json',cli_home/'auth.json');os.chmod(cli_home/'auth.json',0o600)
  shutil.copyfile(args.model_catalog,cli_home/'model-catalog.json')
  outer_profile=client_profile(work,private,HERE);(private/'client.sb').write_text(outer_profile)
  env={'PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','HOME':str(pathlib.Path.home()),'TMPDIR':str(work),'LANG':'en_US.UTF-8','LC_ALL':'en_US.UTF-8','TERM':'dumb','CODEX_HOME':str(cli_home)}
  bridge=Bridge(private/'broker.json',cli_home/'s.sock',shutil.which('python3'),HERE/'broker.py');bridge.start()
  proc=subprocess.Popen(['/usr/bin/sandbox-exec','-p',outer_profile,*cmd],cwd=work,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
  try:rc=proc.wait(timeout=920)
  except subprocess.TimeoutExpired:
   os.killpg(proc.pid,signal.SIGTERM)
   try:rc=proc.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);rc=proc.wait()
 bridge.close()
 result.update({'state':'FINISHED','returncode':rc,'elapsed_seconds':time.monotonic()-start,'submission_exists':(private/'submission.c').is_file()})
 for line in (private/'agent.jsonl').read_text().splitlines():
  try:
   event=json.loads(line)
   if event.get('type')=='turn.completed':result['usage']=event.get('usage')
   if event.get('type')=='turn.failed':result['agent_error']=event.get('error')
  except json.JSONDecodeError:pass
 (private/'status.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True);return result

def main():
 p=argparse.ArgumentParser();p.add_argument('manifest');p.add_argument('--model',default='gpt-5.6-sol');p.add_argument('--python',default=DEFAULT_PYTHON);p.add_argument('--concurrency',type=int,default=3);p.add_argument('--limit',type=int);p.add_argument('--trial-id');p.add_argument('--resume',action='store_true');p.add_argument('--preflight',action='store_true');p.add_argument('--model-catalog',default='/private/tmp/anti-rev-blind-v4-40fr3iyo/model-catalog.json');a=p.parse_args()
 manifest=json.loads(pathlib.Path(a.manifest).read_text());root=pathlib.Path(manifest['private_root']);trials=manifest['trials']
 if a.trial_id:trials=[t for t in trials if t['trial_id']==a.trial_id]
 if a.resume:trials=[t for t in trials if not (root/'controller'/t['trial_id']/'status.json').exists()]
 if a.limit:trials=trials[:a.limit]
 with concurrent.futures.ThreadPoolExecutor(max_workers=a.concurrency) as pool:
  results=list(pool.map(lambda t:launch(t,root,a),trials))
 (root/'controller'/'run-summary.json').write_text(json.dumps(results,indent=2))
if __name__=='__main__':main()
