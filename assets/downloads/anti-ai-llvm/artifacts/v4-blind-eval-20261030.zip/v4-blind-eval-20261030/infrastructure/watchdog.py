#!/usr/bin/env python3
"""Supplemental controller watchdog; pass the private manifest path."""
import pathlib,json,time,subprocess,os,signal,sys
manifest_path=pathlib.Path(sys.argv[1]).resolve();root=manifest_path.parent;manifest=json.loads(manifest_path.read_text());stopped=set()
while True:
 finished=0
 for t in manifest['trials']:
  d=root/'controller'/t['trial_id'];sp=d/'status.json'
  if not sp.exists():continue
  try:s=json.loads(sp.read_text())
  except:continue
  if s.get('state')=='FINISHED':finished+=1;continue
  n=0
  for f in (d/'cli-home/sessions').rglob('*.jsonl'):
   for l in f.read_text().splitlines():
    try:
     x=json.loads(l);p=x.get('payload',{})
     if x.get('type')=='response_item' and p.get('type')in['function_call','custom_tool_call']:n+=1
    except:pass
  if n>100 and t['trial_id'] not in stopped:
   rows=subprocess.check_output(['ps','-axo','pid=,pgid=,command='],text=True).splitlines()
   for row in rows:
    a=row.strip().split(None,2)
    if len(a)==3 and '--ignore-user-config' in a[2] and t['workdir'] in a[2]:
     try:os.killpg(int(a[1]),signal.SIGTERM)
     except ProcessLookupError:pass
   (d/'total-tool-budget.json').write_text(json.dumps({'total_function_calls':n,'action':'terminated_at_first_observed_call_over_100','classification':'BUDGET_EXHAUSTED','poll_seconds':0.25}))
   stopped.add(t['trial_id'])
 if finished==18:break
 time.sleep(.25)
