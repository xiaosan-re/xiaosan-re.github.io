"""Trusted controller-owned stdio MCP broker reached through one private socket.

The broker is spawned BEFORE the inference client enters Seatbelt. This keeps
its stricter script sandbox independent of macOS's nested sandbox limitation.
No target-selection API or grading capability is added by the bridge.
"""
import os
import pathlib
import signal
import socket
import subprocess
import threading


class Bridge:
    def __init__(self, config_path, socket_path, python, broker_path):
        self.config_path = pathlib.Path(config_path).resolve()
        self.socket_path = pathlib.Path(socket_path).resolve()
        self.python = str(python)
        self.broker_path = str(pathlib.Path(broker_path).resolve())
        self.server = None
        self.connection = None
        self.proc = None
        self.stderr = None
        self.threads = []
        self.closed = threading.Event()

    def start(self):
        if len(os.fsencode(self.socket_path)) >= 103:
            raise ValueError('Unix socket path too long')
        self.socket_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        if self.socket_path.exists():
            raise ValueError('refusing existing bridge socket path')
        self.server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.server.bind(str(self.socket_path))
        os.chmod(self.socket_path, 0o600)
        self.server.listen(1)
        self.server.settimeout(0.5)
        self.stderr = (self.config_path.parent/'bridge.stderr').open('wb')
        env = {'PATH':'/opt/homebrew/bin:/usr/bin:/bin',
               'HOME':str(self.config_path.parent),
               'TMPDIR':str(self.config_path.parent),
               'LANG':'en_US.UTF-8', 'LC_ALL':'en_US.UTF-8',
               'PYTHONDONTWRITEBYTECODE':'1', 'PYTHONNOUSERSITE':'1'}
        self.proc = subprocess.Popen(
            [self.python, self.broker_path, '--config', str(self.config_path)],
            cwd=self.config_path.parent, env=env,
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.stderr,
            start_new_session=True)
        t = threading.Thread(target=self._accept, daemon=True)
        t.start()
        self.threads.append(t)
        return self

    def _accept(self):
        while not self.closed.is_set():
            try:
                conn, _ = self.server.accept()
                break
            except socket.timeout:
                if self.proc.poll() is not None:
                    return
            except OSError:
                return
        else:
            return
        self.connection = conn
        outbound = threading.Thread(target=self._responses, args=(conn,), daemon=True)
        outbound.start()
        self.threads.append(outbound)
        try:
            stream = conn.makefile('rb')
            for line in stream:
                if self.closed.is_set() or self.proc.poll() is not None:
                    break
                self.proc.stdin.write(line)
                self.proc.stdin.flush()
        except (OSError, BrokenPipeError):
            pass
        finally:
            # Client EOF stops requests; let the broker flush pending responses.
            try:
                self.proc.stdin.close()
            except OSError:
                pass

    def _responses(self, conn):
        try:
            for line in self.proc.stdout:
                if self.closed.is_set():
                    break
                conn.sendall(line)
        except OSError:
            pass
        finally:
            try:
                conn.shutdown(socket.SHUT_WR)
            except OSError:
                pass
            conn.close()

    def close(self):
        if self.closed.is_set():
            return
        self.closed.set()
        if self.connection is not None:
            try:
                self.connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self.connection.close()
        if self.server is not None:
            self.server.close()
        if self.proc is not None and self.proc.poll() is None:
            try:
                os.killpg(self.proc.pid, signal.SIGTERM)
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(self.proc.pid, signal.SIGKILL)
                self.proc.wait(timeout=3)
            except (ProcessLookupError, PermissionError):
                # EOF can reap the broker/group between poll and signal.
                # Fallback addresses the owned child rather than a stale PGID.
                if self.proc.poll() is None:
                    self.proc.terminate()
                    self.proc.wait(timeout=3)
        for t in self.threads:
            t.join(timeout=1)
        if self.stderr is not None:
            self.stderr.close()
        self.socket_path.unlink(missing_ok=True)

    def __enter__(self):
        return self.start()

    def __exit__(self, *_):
        self.close()
