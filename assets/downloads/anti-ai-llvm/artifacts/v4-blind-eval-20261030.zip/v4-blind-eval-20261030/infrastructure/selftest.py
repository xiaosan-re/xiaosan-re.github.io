import json, pathlib, tempfile
from isolation import run
from broker import Broker
PYTHON='/Volumes/workdata/work/rev/anti_rev/o-mvll/experiments/analysis-complexity/build/venv/bin/python'
with tempfile.TemporaryDirectory(prefix='blind-isolation-') as temp:
 w=pathlib.Path(temp)/'work';w.mkdir();(w/'target.so').write_bytes(b'ELF test')
 secret=pathlib.Path(temp)/'secret';secret.write_text('HOST_SECRET')
 code=w/'probe.py';code.write_text('''import pathlib,socket,subprocess,json\nr={}\nfor k,f in [('host',lambda:pathlib.Path(%r).read_text()),('network',lambda:socket.create_connection(('1.1.1.1',443),timeout=1)),('process',lambda:subprocess.check_output(['/bin/ps','-axo','pid,command']))]:\n try:f();r[k]='FAIL_ALLOWED'\n except Exception:r[k]='DENIED'\npathlib.Path('ok').write_text('worker-write')\nr['own_read']=pathlib.Path('target.so').read_bytes().decode()\nprint(json.dumps(r))\n'''%str(secret))
 r=run(w,PYTHON,[PYTHON,'-I',str(code)])
 assert r['returncode']==0,r
 data=json.loads(r['stdout']);assert all(data[k]=='DENIED' for k in ['host','network','process']),data
 assert (w/'ok').read_text()=='worker-write'
 b=Broker({'workdir':str(w),'audit_log':str(pathlib.Path(temp)/'audit'),'submission':str(pathlib.Path(temp)/'submission'),'track':'S_static','python':PYTHON,'max_calls':3})
 for path in ['../secret','/etc/passwd']:
  try:b.path(path);raise AssertionError('escape permitted')
  except ValueError:pass
 (w/'link').symlink_to(secret)
 try:b.path('link');raise AssertionError('symlink permitted')
 except ValueError:pass
 try:b.call('files',{'action':'write','path':'target.so','text':'x'});raise AssertionError('static overwrite')
 except ValueError:pass
 b.call('submit',{'source':'uint32_t entry(uint32_t a,uint32_t b,uint32_t c,uint32_t d){return 0;}'})
 assert pathlib.Path(temp,'submission').is_file()
 b.call('files',{'action':'list'})
 try:b.call('files',{'action':'list'});raise AssertionError('budget unenforced')
 except TimeoutError:pass
 print(json.dumps({'sandbox':data,'path_escape':'DENIED','static_write':'DENIED','call_budget':'ENFORCED','submission':'PRIVATE_STORAGE'}))
