#!/usr/bin/env python3
"""Unprivileged MCP stdio-to-fixed-controller-socket transport, no dispatch."""
import argparse
import socket
import sys
import threading


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--socket', required=True)
    args = parser.parse_args()
    conn = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    conn.connect(args.socket)

    def responses():
        try:
            while True:
                data = conn.recv(65536)
                if not data:
                    return
                sys.stdout.buffer.write(data)
                sys.stdout.buffer.flush()
        except OSError:
            return

    thread = threading.Thread(target=responses, daemon=True)
    thread.start()
    try:
        for line in sys.stdin.buffer:
            conn.sendall(line)
    finally:
        try:
            conn.shutdown(socket.SHUT_WR)
        except OSError:
            pass
        thread.join(timeout=2)
        conn.close()


if __name__ == '__main__':
    main()
