# Isolated blind evaluation infrastructure

This is execution infrastructure, not a claim that any attack succeeded or failed.
`dataset.py` builds the trusted paired dataset; `judge.py` grades isolated submissions. Never expose it, its
manifest, the controller directory, old experiments or this directory to an agent.

`broker.py --config PRIVATE_CONFIG.json` is a newline JSON-RPC MCP stdio server.
It exposes only `analyze`, `files`, `python` and `submit`. The agent's directory
initially contains exactly `target.so`. The broker config names that directory,
a private audit log and submission path, a private fixed-headless REA configuration,
and the sandbox Python executable. REA accepts only fixed-target operations;
there is no raw provider dispatch, user-selected input path, backend discovery,
network tool or judge access. The target is copied through `O_NOFOLLOW` and a
regular-file check into private backend storage before analysis.

Python runs under macOS Seatbelt with default deny, no network or Mach service
lookup, no host home or project access and write permission confined to the trial.
Read-only toolchains/system libraries and the configured Python environment are
allowlisted. Environment variables are replaced, not inherited. Process creation is denied inside Python workers. The parent applies
30 CPU seconds, a 45-second wall deadline, a 32 MiB file limit, and polls aggregate
process-group RSS every 200 ms, killing it above 2048 MiB. All descendants are killed
when a script exits. These are process isolation controls on the host kernel, not
a separate VM/kernel. The trusted inference client and REA broker remain outside
this worker boundary; removing built-in execution/patch/network tools and restricting residual image reads
to the trial directory are required preflights, not optional prompt instructions.
The residual MCP resource tools have no registered resources.

Static trials permit binary normalization as data, but target execution/emulation
is prohibited. Arbitrary derived Python cannot distinguish a handwritten emulator
from mathematics automatically: audit the scripts/tool trace before crediting an
S-track success. Reclassify/invalidate violations. D-track emulation is allowed;
it is not real Android-device evidence.

`run_trials.py MANIFEST --model EXACT_MODEL --concurrency 3` starts fresh
Codex contexts in separate private CODEX_HOME directories, ignores user config/project rules, disables known built-in tool
features and configures only the fixed MCP broker. It records prompts, exact
invocations, visible agent/tool traces, usage and final submission privately.
The broker stops accepting calls after 900 seconds; the inference client has a
20-second shutdown grace. A separate controller watchdog counts all native and MCP
function calls, because the broker itself can only count MCP calls. Do not launch the matrix until the
pinned model/authentication and actual model-visible tool catalog are verified.
ChatGPT subscription authentication does not provide an actual per-run USD bill;
record cost as unavailable rather than inventing an API-equivalent charge.

`python3 selftest.py` tests host read/network/process inspection denial, own-file
access, path/symlink escape rejection, tool-call budget and private submission.
The test does not prove all possible OS escape resistance or static-track semantic
compliance. Candidate grading must occur in separate sandboxed processes, never
by loading candidate code into the oracle process.

`report.py PRIVATE_MANIFEST --output PUBLIC_DIRECTORY` exports results and visible
tool calls/outputs. It excludes model reasoning, authentication and the oracle.
A numeric pass receives final credit only after independent trace/source audit.

## V4 paired replication and outer boundary

This replication compares O-MVLL flatten, V3, and V4 on three **new paired**
secret instances, with S/D tracks (18 trials). The bare baseline from the previous
pilot is historical context only. V4 replaces AC slicing with the whole-function
BusinessVM plugin and retains flatten/metadata/threshold/shadow/runtime layers.

The inference process is itself launched by `sandbox-exec` using
`client_isolation.py`. Codex's internal `danger-full-access` setting disables its
nested filesystem helper; it does **not** remove this outer kernel policy.
Execution/patch/web tools remain absent from the model catalog. Actual image
controls must permit the trial image and reject controller/host images.

`broker_bridge.py` starts the trusted target-fixed broker outside the inference
sandbox. `relay.py` only forwards MCP stdio over that trial's private Unix socket.
The broker starts the independently sandboxed Python worker, avoiding macOS's
nested Seatbelt failure. Each REA backend gets its own HOME/IDAUSR, license/config
copy and workspace. No oracle or another trial is in the inference allowlist.
The standalone judge compiler/runner boundary is unchanged.

A self-contained C interpreter over recovered higher-level IR/bytecode can count
as recovery; embedding/loading the original ELF or its native instruction image
cannot. S permits static decoding/lifting and derived mathematics, but executing
extracted target VM instructions in the attack session remains target emulation.
This clarification is identical in all three variants' prompts.

The native Capstone library may be discovered in the allowlisted toolchain even
though the Python `capstone` package is absent. Record actual tool use rather
than treating that missing package as a complete lack of disassembly capability.
