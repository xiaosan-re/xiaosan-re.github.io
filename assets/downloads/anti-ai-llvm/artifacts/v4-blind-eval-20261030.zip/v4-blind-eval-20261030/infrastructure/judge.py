#!/usr/bin/env python3
"""Trusted hidden oracle; submitted C runs only in a separate Seatbelt process."""
import argparse, importlib.util, json, os, pathlib, resource, select, shutil, signal, subprocess, tempfile, time, threading
HERE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('blind_dataset',HERE/'dataset.py');dataset=importlib.util.module_from_spec(spec);spec.loader.exec_module(dataset)
WRAPPER='''#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
uint32_t recovered(uint32_t,uint32_t,uint32_t,uint32_t);
int main(void){ unsigned u,q,t,k; while(scanf("%u %u %u %u",&u,&q,&t,&k)==4){ ualarm(250000,0); uint32_t r=recovered(u,q,t,k); ualarm(0,0); printf("%u\\n",r); fflush(stdout); } return 0; }
'''

def profile(work,write):
 reads=['/opt/homebrew','/usr','/bin','/System','/Library/Developer/CommandLineTools','/Applications/Xcode.app/Contents/Developer','/Library/Apple','/private/var/db/dyld',str(work)]
 lines=['(version 1)','(deny default)','(allow process-exec process-fork)','(allow sysctl-read)','(allow file-read-metadata)','(allow file-read* (literal "/"))','(allow file-read* '+' '.join('(subpath '+json.dumps(p)+')' for p in reads)+')','(allow file-read* file-write* (literal "/dev/null") (literal "/dev/urandom") (literal "/dev/random"))']
 if write:lines.append('(allow file-write* (subpath '+json.dumps(str(work))+'))')
 return '\n'.join(lines)

def limits():
 os.setsid();resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_FSIZE,(32*1024**2,32*1024**2));resource.setrlimit(resource.RLIMIT_NOFILE,(64,64));resource.setrlimit(resource.RLIMIT_CORE,(0,0))

def killgroup(proc):
 try:os.killpg(proc.pid,signal.SIGKILL)
 except (ProcessLookupError,PermissionError):
  try:proc.kill()
  except (ProcessLookupError,PermissionError):pass

def memory_watch(proc):
 stop=threading.Event();exceeded=[]
 def watch():
  while not stop.wait(0.2):
   try:
    rows=subprocess.check_output(['/bin/ps','-axo','pgid=,rss='],text=True)
    rss=sum(int(r.split()[1]) for r in rows.splitlines() if len(r.split())==2 and int(r.split()[0])==proc.pid)
    if rss>2048*1024:exceeded.append(True);killgroup(proc);return
   except (OSError,subprocess.SubprocessError):return
 thread=threading.Thread(target=watch,daemon=True);thread.start();return stop,thread,exceeded

def grade(candidate,secret,timeout=90):
 candidate=pathlib.Path(candidate)
 if candidate.is_symlink() or not candidate.is_file():return {'outcome':'INFRA_FAILURE','error':'submission missing or symlink'}
 data=candidate.read_bytes()
 if len(data)>1024**2:return {'outcome':'PARTIAL_RECOVERY','error':'submission exceeds 1MiB'}
 work=pathlib.Path(tempfile.mkdtemp(prefix='anti-rev-judge-',dir='/private/tmp'));work.chmod(0o700)
 proc=None;started=time.monotonic();result={'correct':0,'tested':0,'total':0,'outcome':'PARTIAL_RECOVERY','independence_audit':'REQUIRED: numeric recovery must be audited for embedded target/delegation before final credit','memory_limit':'process-group RSS 2048MiB watchdog every200ms'}
 try:
  (work/'submission.c').write_bytes(data);(work/'runner.c').write_text(WRAPPER)
  env={'PATH':'/usr/bin:/bin','HOME':str(work),'TMPDIR':str(work),'LANG':'C'}
  cmd=['/usr/bin/sandbox-exec','-p',profile(work,True),'/opt/homebrew/opt/llvm@21/bin/clang','-fuse-ld=/Library/Developer/CommandLineTools/usr/bin/ld','-isysroot','/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk','-O2','-std=c11',str(work/'submission.c'),str(work/'runner.c'),'-o',str(work/'runner')]
  p=subprocess.Popen(cmd,cwd=work,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=limits)
  stop,thread,mem=memory_watch(p)
  try:out,err=p.communicate(timeout=60)
  except subprocess.TimeoutExpired:killgroup(p);p.communicate();raise
  finally:stop.set();thread.join(timeout=1);killgroup(p)
  p.stderr=err
  if p.returncode:return {**result,'error':'compile_failed','compile_returncode':p.returncode,'compiler_stderr':p.stderr[-4000:].decode(errors='replace')}
  proc=subprocess.Popen(['/usr/bin/sandbox-exec','-p',profile(work,False),str(work/'runner')],cwd='/',env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,preexec_fn=limits)
  stop,thread,mem=memory_watch(proc)
  vs=dataset.vectors(secret);result['total']=len(vs);result['strata']={}
  for v in vs:
   label='valid_business' if 1<=v[1]<=100 and v[2]<=2 and v[3]==dataset.mix(v[0]^secret['key']) else 'invalid_input'
   result['strata'].setdefault(label,{'correct':0,'tested':0,'total':0})['total']+=1
  for v in vs:
   if time.monotonic()-started>timeout:result['error']='total_timeout';break
   try:proc.stdin.write((' '.join(map(str,v))+'\n').encode());proc.stdin.flush()
   except BrokenPipeError:result['error']='candidate_exited';break
   line=bytearray();deadline=time.monotonic()+0.5
   while not line.endswith(b'\n') and len(line)<128:
    ready,_,_=select.select([proc.stdout],[],[],max(0,deadline-time.monotonic()))
    if not ready:break
    chunk=os.read(proc.stdout.fileno(),1)
    if not chunk:break
    line.extend(chunk)
   if not line.endswith(b'\n'):result['error']='per_case_timeout_or_invalid_output';break
   try:value=int(line.strip());assert 0<=value<=0xffffffff
   except (ValueError,AssertionError):result['error']='invalid_output';break
   result['tested']+=1
   label='valid_business' if 1<=v[1]<=100 and v[2]<=2 and v[3]==dataset.mix(v[0]^secret['key']) else 'invalid_input'
   result['strata'][label]['tested']+=1
   if value==dataset.oracle(v,secret['key'],secret['salt']):
    result['correct']+=1;result['strata'][label]['correct']+=1
  if result['tested']==result['total'] and result['correct']==result['total']:result['outcome']='VERIFIED_RECOVERY'
  elif result['correct']:result['outcome']='PARTIAL_RECOVERY'
  result['memory_exceeded']=bool(mem);result['seconds']=round(time.monotonic()-started,3);return result
 except subprocess.TimeoutExpired:return {**result,'error':'compile_timeout'}
 finally:
  if proc is not None:
   killgroup(proc);proc.wait();stop.set();thread.join(timeout=1)
  shutil.rmtree(work)

def selftest():
 secret={'key':0x10203040,'salt':0x50607080,'judge_seed':12345}
 source=(dataset.DEMO/'demo.c').read_text().replace('demo_evaluate','recovered').replace('0xc37a91e5','0x10203040').replace('0x13579bdf','0x50607080')
 cases={'valid':source,'runtime_host_read':source+'\n#include <stdio.h>\n#include <stdlib.h>\n__attribute__((constructor)) static void check(void){FILE *f=fopen("/private/tmp/anti-rev-judge-forbidden-header.h","r");if(f)abort();}\n','wrong':'#include <stdint.h>\nuint32_t recovered(uint32_t a,uint32_t b,uint32_t c,uint32_t d){return 0;}','crash':'#include <stdint.h>\nuint32_t recovered(uint32_t a,uint32_t b,uint32_t c,uint32_t d){__builtin_trap();}','timeout':'#include <stdint.h>\nuint32_t recovered(uint32_t a,uint32_t b,uint32_t c,uint32_t d){for(;;){__asm__ volatile("");}}','host_read':'#include "/private/tmp/anti-rev-judge-forbidden-header.h"\n'}
 forbidden=pathlib.Path('/private/tmp/anti-rev-judge-forbidden-header.h');forbidden.write_text('secret\n')
 report={}
 try:
  with tempfile.TemporaryDirectory() as td:
   for name,src in cases.items():
    p=pathlib.Path(td)/'submission.c';p.write_text(src);r=grade(p,secret);report[name]=r
  assert report['valid']['outcome']=='VERIFIED_RECOVERY',report
  assert report['runtime_host_read']['outcome']=='VERIFIED_RECOVERY',report
  assert all(report[k]['outcome']!='VERIFIED_RECOVERY' for k in ['wrong','crash','timeout','host_read']),report
  assert report['host_read'].get('error')=='compile_failed',report
  print(json.dumps(report,indent=2))
 finally:forbidden.unlink(missing_ok=True)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--selftest',action='store_true');ap.add_argument('--manifest',type=pathlib.Path);ap.add_argument('--trial');ap.add_argument('--candidate',type=pathlib.Path);args=ap.parse_args()
 if args.selftest:return selftest()
 m=json.loads(args.manifest.read_text());t=next(t for t in m['trials'] if t['trial_id']==args.trial);secret=m['instances'][str(t['instance'])]['secret'];print(json.dumps(grade(args.candidate,secret),indent=2))
if __name__=='__main__':main()
