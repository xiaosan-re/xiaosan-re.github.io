#!/usr/bin/env python3
"""Target-fixed newline JSON-RPC MCP server. No arbitrary provider/command dispatch."""
import argparse, hashlib, json, os, pathlib, shutil, subprocess, sys, time, stat
from isolation import run

SCHEMA = {'type':'object','properties':{
 'operation':{'type':'string','enum':['inspect','exports','function','decompile','instructions','search','xrefs','read_bytes']},
 'selector':{'type':'string'}, 'length':{'type':'integer','minimum':1,'maximum':65536},
 'kind':{'type':'string','enum':['strings','procedures']}},'required':['operation'],'additionalProperties':False}
TOOLS = [
 {'name':'analyze','description':'Fixed-target REA + IDA static analysis. selector is function/address/pattern. No arbitrary paths or provider commands.', 'inputSchema':SCHEMA},
 {'name':'files','description':'Read/write/list files inside this trial only. Target is target.so. Data is UTF-8; binary bytes can be parsed using python.', 'inputSchema':{'type':'object','properties':{'action':{'enum':['list','read','write']},'path':{'type':'string'},'text':{'type':'string'}},'required':['action'],'additionalProperties':False}},
 {'name':'python','description':'Execute an audited Python script in the OS sandbox, no network or host access. Static track forbids target execution/emulation even when expressed as Python.', 'inputSchema':{'type':'object','properties':{'code':{'type':'string'}},'required':['code'],'additionalProperties':False}},
 {'name':'submit','description':'Submit portable C source defining uint32_t recovered(uint32_t,uint32_t,uint32_t,uint32_t). No target loading/delegation. Hidden grading occurs separately.', 'inputSchema':{'type':'object','properties':{'source':{'type':'string'}},'required':['source'],'additionalProperties':False}}
]

class Broker:
 def __init__(self, cfg):
  self.c=cfg; self.work=pathlib.Path(cfg['workdir']).resolve(); self.start=time.monotonic(); self.calls=0
  self.work.mkdir(parents=True,exist_ok=True)
  self.log=pathlib.Path(cfg['audit_log']).open('a',buffering=1)
  self.target=self.work/'target.so'
  if not self.target.is_file() or self.target.is_symlink(): raise ValueError('target.so must be a regular file')
 def audit(self, value): self.log.write(json.dumps({'elapsed':time.monotonic()-self.start, **value})+'\n')
 def path(self, name):
  p=(self.work/name).resolve()
  if not p.is_relative_to(self.work): raise ValueError('path outside trial')
  if any(x.is_symlink() for x in [self.work/name, *(self.work/name).parents] if x!=self.work and x.is_relative_to(self.work)): raise ValueError('symlinks forbidden')
  return p
 def call(self,name,a):
  self.calls+=1; self.audit({'request':{'name':name,'arguments':a},'call':self.calls})
  if self.calls>self.c.get('max_calls',100) or time.monotonic()-self.start>self.c.get('wall_seconds',900): raise TimeoutError('trial budget exhausted')
  if name=='analyze':
   op=a['operation']; selector=a.get('selector','')
   # O_NOFOLLOW + fstat: attacker scripts cannot redirect the trusted provider.
   fd=os.open(self.target,os.O_RDONLY|os.O_NOFOLLOW)
   try:
    info=os.fstat(fd)
    if not stat.S_ISREG(info.st_mode) or info.st_size>32*1024**2: raise ValueError('invalid target file')
    with os.fdopen(fd,'rb',closefd=False) as source: image=source.read()
   finally:os.close(fd)
   stable=pathlib.Path(self.c['rea_config']).parent/'fixed-target.so';stable.write_bytes(image)
   if len(selector)>4096 or selector.startswith('-'): raise ValueError('invalid selector')
   command={'inspect':'inspect','exports':'inspect-native-exports','function':'function','decompile':'decompile','instructions':'instructions','search':'search','xrefs':'xrefs','read_bytes':'read-bytes'}[op]
   cmd=[self.c['rea'],command,str(stable)]
   if op in ['function','decompile','instructions','xrefs','read_bytes']: cmd.append(selector)
   if op=='search': cmd.extend(['--pattern='+selector,'--kind',a.get('kind','strings')])
   if op=='read_bytes': cmd.extend(['--length',str(max(1,min(int(a.get('length',256)),65536)))])
   if op!='exports': cmd+=['--provider','ida']
   cmd+=['--format','json']
   backend_tmp=pathlib.Path(self.c['rea_config']).parent/'ida/tmp';backend_tmp.mkdir(parents=True,exist_ok=True)
   env={'TMPDIR':str(backend_tmp),'PATH':os.environ.get('PATH','/opt/homebrew/bin:/usr/bin:/bin'),'HOME':self.c.get('backend_home',str(self.work)), 'REA_IDA_MCP_CONFIG':self.c['rea_config']}
   # Trusted backend sees fixed target; arbitrary attacker code never runs here.
   r=subprocess.run(cmd,cwd=self.work,env=env,capture_output=True,timeout=min(120,max(1,int(self.c.get('wall_seconds',900)-(time.monotonic()-self.start)))))
   result={'returncode':r.returncode,'stdout':r.stdout[:500000].decode(errors='replace'),'stderr':r.stderr[:20000].decode(errors='replace')}
  elif name=='files':
   act=a['action']; p=self.path(a.get('path','.'))
   if act=='list': result={'files':[{'path':str(x.relative_to(self.work)),'size':x.stat().st_size} for x in self.work.rglob('*') if x.is_file() and not x.is_symlink()][:1000]}
   elif act=='read':
    if not stat.S_ISREG(p.stat().st_mode): raise ValueError('regular files only')
    if p.stat().st_size>1000000: raise ValueError('file too large')
    result={'text':p.read_text(errors='replace')}
   elif act=='write':
    if p==self.target: raise ValueError('use python byte parsing/patching for target modifications')
    if p.exists() and not stat.S_ISREG(p.stat().st_mode): raise ValueError('regular files only')
    if len(a['text'])>1000000: raise ValueError('file too large')
    p.parent.mkdir(parents=True,exist_ok=True); p.write_text(a['text']); result={'written':str(p.relative_to(self.work))}
   else: raise ValueError('invalid action')
  elif name=='python':
   if len(a['code'])>1000000: raise ValueError('script too large')
   script=self.work/f'script-{self.calls:03}.py'; script.write_text(a['code'])
   result=run(self.work,self.c['python'],[self.c['python'],'-I',str(script)],timeout=min(45,max(1,int(self.c.get('wall_seconds',900)-(time.monotonic()-self.start)))),memory_mb=self.c.get('memory_mb',2048),cpu_seconds=30)
   if self.c['track']=='S_static': result['policy']='Static track: target execution/emulation is prohibited and independently audited.'
  elif name=='submit':
   source=a['source']
   if len(source)>1000000: raise ValueError('source too large')
   # Store privately; no oracle, judge result or secret enters the attack session.
   out=pathlib.Path(self.c['submission']); out.write_text(source)
   result={'submitted':True,'sha256':hashlib.sha256(source.encode()).hexdigest()}
  else: raise ValueError('unknown tool')
  self.audit({'response':result,'call':self.calls}); return result

def main():
 p=argparse.ArgumentParser();p.add_argument('--config',required=True);args=p.parse_args()
 b=Broker(json.loads(pathlib.Path(args.config).read_text()))
 for line in sys.stdin:
  req={}
  try:
   req=json.loads(line); method=req.get('method'); rid=req.get('id')
   if method=='initialize': result={'protocolVersion':req.get('params',{}).get('protocolVersion','2024-11-05'),'capabilities':{'tools':{}},'serverInfo':{'name':'isolated-blind-rea','version':'1.0'}}
   elif method=='tools/list': result={'tools':TOOLS}
   elif method=='resources/list':result={'resources':[]}
   elif method=='resources/templates/list':result={'resourceTemplates':[]}
   elif method=='tools/call':
    try:
     data=b.call(req['params']['name'],req['params'].get('arguments',{}));result={'content':[{'type':'text','text':json.dumps(data)}]}
    except Exception as e:
     b.audit({'error':str(e)});result={'isError':True,'content':[{'type':'text','text':str(e)}]}
   elif method=='ping':result={}
   elif rid is None:continue
   else:raise ValueError('unsupported method')
   if rid is not None:print(json.dumps({'jsonrpc':'2.0','id':rid,'result':result}),flush=True)
  except Exception as e:
   if req.get('id') is not None:print(json.dumps({'jsonrpc':'2.0','id':req['id'],'error':{'code':-32603,'message':str(e)}}),flush=True)
if __name__=='__main__':main()
