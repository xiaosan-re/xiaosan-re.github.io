#include <stdint.h>

static uint32_t mix32(uint32_t x)
{
    x ^= x >> 16;
    x *= UINT32_C(0x7FEB352D);
    x ^= x >> 15;
    x *= UINT32_C(0x846CA68B);
    x ^= x >> 16;
    return x;
}

uint32_t recovered(uint32_t a, uint32_t quantity, uint32_t tier, uint32_t token)
{
    uint32_t price;

    if (quantity < 1u || quantity > 100u)
        return UINT32_C(0x80000001);
    if (tier > 2u)
        return UINT32_C(0x80000002);
    if (token != mix32(a ^ UINT32_C(0x9B05606F)))
        return UINT32_C(0x80000003);

    if (tier == 0u)
        price = 129u;
    else if (tier == 1u)
        price = 249u;
    else
        price = 399u;

    price *= quantity;
    if (quantity >= 10u)
        price = (price * 85u) / 100u;

    if ((mix32(a + UINT32_C(0x7188BDA9)) & 7u) == 3u)
        price = (price * 95u) / 100u;

    return price;
}
