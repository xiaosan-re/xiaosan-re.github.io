#include <stdint.h>

static uint32_t mix32(uint32_t x) {
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

uint32_t recovered(uint32_t a, uint32_t b, uint32_t c, uint32_t d) {
    uint32_t unit;
    uint32_t total;

    if (b == 0 || b > 100)
        return UINT32_C(0x80000001);
    if (c > 2)
        return UINT32_C(0x80000002);
    if (d != mix32(a ^ UINT32_C(0x87f7daef)))
        return UINT32_C(0x80000003);

    if (c == 0)
        unit = 129;
    else if (c == 1)
        unit = 249;
    else
        unit = 399;

    total = unit * b;
    if (b >= 10)
        total = (total * 85u) / 100u;

    if ((mix32(a + UINT32_C(0x7f70ea69)) & 7u) == 3u)
        total = (total * 95u) / 100u;

    return total;
}
