from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_PROT_ALL
from unicorn.arm64_const import UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2, UC_ARM64_REG_X3, UC_ARM64_REG_X30

BASE=0x100000
PAGE=0x1000
with open('target.so','rb') as f:
    elf=ELFFile(f)
    loads=[]
    for seg in elf.iter_segments():
        if seg['p_type']=='PT_LOAD':
            loads.append((int(seg['p_vaddr']), int(seg['p_memsz']), bytes(seg.data())))

def target(a,b,c,d):
    u=Uc(UC_ARCH_ARM64, UC_MODE_ARM)
    for va,ms,data in loads:
        lo=(BASE+va)&~(PAGE-1); hi=(BASE+va+ms+PAGE-1)&~(PAGE-1)
        try: u.mem_map(lo,hi-lo,UC_PROT_ALL)
        except: pass
        u.mem_write(BASE+va,data)
    stop=0x200000
    u.mem_map(stop,PAGE,UC_PROT_ALL)
    for reg,val in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),(a,b,c,d)):
        u.reg_write(reg,val & 0xffffffff)
    u.reg_write(UC_ARM64_REG_X30,stop)
    u.emu_start(BASE+0x2fc,stop,count=1000)
    return u.reg_read(UC_ARM64_REG_X0)&0xffffffff

def mix(x):
    x &= 0xffffffff
    x ^= x >> 16
    x = (x * 0x7feb352d) & 0xffffffff
    x ^= x >> 15
    x = (x * 0x846ca68b) & 0xffffffff
    x ^= x >> 16
    return x & 0xffffffff

def rec(a,b,c,d):
    if b < 1 or b > 100: return 0x80000001
    if c > 2: return 0x80000002
    if d != mix(a ^ 0x838d31dc): return 0x80000003
    v=(129,249,399)[c]*b
    if b>=10: v=v*85//100
    if (mix((a+0x4c55a6ee)&0xffffffff)&7)==3: v=v*95//100
    return v

cases=[]
for a,b,c in [(0,1,0),(0,9,1),(0,10,2),(1,100,2),(0xffffffff,57,1),(0x12345678,42,0)]:
    d=mix(a^0x838d31dc); cases.append((a,b,c,d,target(a,b,c,d),rec(a,b,c,d)))
for q in [0,101,0xffffffff]: cases.append((5,q,99,0,target(5,q,99,0),rec(5,q,99,0)))
cases += [(5,1,3,0,target(5,1,3,0),rec(5,1,3,0)),(5,1,0,0,target(5,1,0,0),rec(5,1,0,0))]
for row in cases: print(' '.join(f'{x:08x}' for x in row))
assert all(r[-2]==r[-1] for r in cases)
print('all matched')