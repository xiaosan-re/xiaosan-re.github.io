#include <stdint.h>

static uint32_t mix32(uint32_t x)
{
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

uint32_t recovered(uint32_t a, uint32_t b, uint32_t c, uint32_t d)
{
    uint32_t price;

    if (b < UINT32_C(1) || b > UINT32_C(100))
        return UINT32_C(0x80000001);
    if (c > UINT32_C(2))
        return UINT32_C(0x80000002);
    if (d != mix32(a ^ UINT32_C(0x9b05606f)))
        return UINT32_C(0x80000003);

    if (c == UINT32_C(0))
        price = UINT32_C(129);
    else if (c == UINT32_C(1))
        price = UINT32_C(249);
    else
        price = UINT32_C(399);

    price *= b;
    if (b >= UINT32_C(10))
        price = (price * UINT32_C(85)) / UINT32_C(100);

    if ((mix32(a + UINT32_C(0x7188bda9)) & UINT32_C(7)) == UINT32_C(3))
        price = (price * UINT32_C(95)) / UINT32_C(100);

    return price;
}
