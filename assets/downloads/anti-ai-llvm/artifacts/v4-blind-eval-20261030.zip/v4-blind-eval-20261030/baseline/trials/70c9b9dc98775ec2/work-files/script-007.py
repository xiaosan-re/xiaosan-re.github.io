from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_PROT_ALL
from unicorn.arm64_const import *
import random
BASE=0x100000; PAGE=0x1000
with open('target.so','rb') as f:
    e=ELFFile(f); loads=[(int(s['p_vaddr']),int(s['p_memsz']),bytes(s.data())) for s in e.iter_segments() if s['p_type']=='PT_LOAD']
def run(args):
    u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
    for va,n,data in loads:
        lo=(BASE+va)&-PAGE; hi=(BASE+va+n+PAGE-1)&-PAGE
        try:u.mem_map(lo,hi-lo,UC_PROT_ALL)
        except:pass
        u.mem_write(BASE+va,data)
    u.mem_map(0x200000,PAGE,UC_PROT_ALL)
    for r,v in zip((UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2,UC_ARM64_REG_X3),args):u.reg_write(r,v&0xffffffff)
    u.reg_write(UC_ARM64_REG_X30,0x200000);u.emu_start(BASE+0x2fc,0x200000,count=100)
    return u.reg_read(UC_ARM64_REG_X0)&0xffffffff
def mix(x):
    x&=0xffffffff;x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;x^=x>>16;return x&0xffffffff
def rec(a,q,t,k):
    if not 1<=q<=100:return 0x80000001
    if t>2:return 0x80000002
    if k!=mix(a^0x838d31dc):return 0x80000003
    x=(129,249,399)[t]*q
    if q>=10:x=x*85//100
    if mix((a+0x4c55a6ee)&0xffffffff)&7==3:x=x*95//100
    return x
random.seed(0xC0DEC0DE)
loyal=0
for i in range(250):
    a=random.getrandbits(32);q=random.choice([0,1,9,10,100,101,random.getrandbits(32)]);t=random.choice([0,1,2,3,random.getrandbits(32)])
    k=mix(a^0x838d31dc) if random.randrange(2) else random.getrandbits(32)
    got=run((a,q,t,k));want=rec(a,q,t,k)
    assert got==want,(i,a,q,t,k,got,want)
    loyal += int((mix((a+0x4c55a6ee)&0xffffffff)&7)==3)
print('250 randomized target-emulation comparisons matched; loyalty bucket hits:',loyal)