#include <stdint.h>

static uint32_t mix32(uint32_t x)
{
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

uint32_t recovered(uint32_t seed, uint32_t quantity,
                   uint32_t tier, uint32_t token)
{
    uint32_t unit_price;
    uint32_t total;

    if (quantity < 1 || quantity > 100)
        return UINT32_C(0x80000001);
    if (tier > 2)
        return UINT32_C(0x80000002);
    if (token != mix32(seed ^ UINT32_C(0x838d31dc)))
        return UINT32_C(0x80000003);

    if (tier == 0)
        unit_price = 129;
    else if (tier == 1)
        unit_price = 249;
    else
        unit_price = 399;

    total = unit_price * quantity;
    if (quantity >= 10)
        total = (total * 85u) / 100u;

    if ((mix32(seed + UINT32_C(0x4c55a6ee)) & 7u) == 3u)
        total = (total * 95u) / 100u;

    return total;
}
