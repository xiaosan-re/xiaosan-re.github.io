#include <stdint.h>

static uint32_t mix32(uint32_t x)
{
    x ^= x >> 16;
    x *= UINT32_C(0x7feb352d);
    x ^= x >> 15;
    x *= UINT32_C(0x846ca68b);
    x ^= x >> 16;
    return x;
}

uint32_t recovered(uint32_t customer,
                   uint32_t quantity,
                   uint32_t tier,
                   uint32_t token)
{
    uint32_t price;

    if (quantity < 1 || quantity > 100)
        return UINT32_C(0x80000001);
    if (tier > 2)
        return UINT32_C(0x80000002);
    if (token != mix32(customer ^ UINT32_C(0x838d31dc)))
        return UINT32_C(0x80000003);

    if (tier == 0)
        price = 129;
    else if (tier == 1)
        price = 249;
    else
        price = 399;

    price *= quantity;
    if (quantity >= 10)
        price = (price * 85) / 100;

    if ((mix32(customer + UINT32_C(0x4c55a6ee)) & 7) == 3)
        price = (price * 95) / 100;

    return price;
}
