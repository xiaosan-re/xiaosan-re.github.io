V4 paired replication
=====================

Primary: O-MVLL/V3/V4, 3 fresh paired secret instances x S/D =18. Supplemental matched bare baseline=6, run afterward. Full recovery requires all8592 hidden checks and a valid policy/independence audit.

omvll_flatten / S_static: 2/3 eligible; 0 excluded
omvll_flatten / D_dynamic: 3/3 eligible; 0 excluded
v3_hardened / S_static: 1/3 eligible; 0 excluded
v3_hardened / D_dynamic: 2/3 eligible; 0 excluded
v4_hardened / S_static: 2/2 eligible; 1 excluded
v4_hardened / D_dynamic: 2/3 eligible; 0 excluded

See results.json, before-after-metrics.json, per-trial sources/traces and the technical article. No authentication, oracle data or private reasoning is exported.
